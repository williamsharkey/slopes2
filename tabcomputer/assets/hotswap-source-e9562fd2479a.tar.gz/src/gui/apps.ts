/**
 * GUI apps from Debian, streamed on first use (docs/GUI.md).
 *
 * public/gui/apps.json (scripts/gui/gen-apps.py) lists, per app, the Debian
 * bookworm amd64 packages it needs to start: its ELF closure plus data
 * packages; optional dlopen'ed stacks (Mesa/LLVM, CUPS, ...) are left out.
 * Packages are content addressed by the .deb's sha256 (from Debian's signed
 * index): fetched through the server's /debian/ route, verified, kept in the
 * browser's Cache Storage under that hash (shared by every app, survives a
 * filesystem reset), and unpacked into the root filesystem. dpkg-style
 * triggers (gdk-pixbuf loaders, GSettings schemas, MIME database) then run
 * in Blink like their postinst scripts would. Apps launch as kernel
 * processes (x86-64 ELF in Blink) with DISPLAY=:0.
 */
import type { FileSystem } from '../filesystem';
import type { Kernel } from '../kernel/kernel';
import type { Process } from '../kernel/process';
import { untar, type TarEntry } from '../pkg-tar';
import { debEntriesOffThread } from './deb';
import { toolkitScaleEnv } from './display-scale';
export { arMembers, debEntries } from './deb';

export interface DebPackage { version: string; filename: string; sha256: string; size: number }
export interface GuiApp {
  description: string; toolkit: string; bin: string;
  /** The Debian package that provides the app (apt's name for it). */
  pkg?: string;
  packages: string[];
  size: number; closureSize: number; dropped: string[];
  /** Its icon, relative to the page (public/gui/icons/). */
  icon?: string;
  /** Paths deleted after unpacking: optional plug-ins whose libraries were left out. */
  remove?: string[];
  /** [link, target] symlinks a postinst would make (update-alternatives: BLAS, LAPACK; LibreOffice's registry). */
  links?: [string, string][];
  /** Settings written into the user's home (relative path: contents) before a launch, when not there yet */
  home?: Record<string, string>;
  /** Arguments every launch starts with (Audacious's Qt interface is `--qt`) */
  args?: string[];
}
/**
 * A file a postinst would generate, built by gen-apps.py (public/gui/overlay/SHA256), applied when `when` is
 * installed; with `tar`, a tar archive unpacked at `path` (e.g. symlinks).
 */
export interface Overlay {
  path: string; sha256: string; size: number; when: string; tar?: boolean;
  /** Written only when nothing is at `path` yet (a file in the user's home: GIMP's plug-in registry) */
  keep?: boolean;
}
export interface AppsManifest {
  suite: string; arch: string; mirror: string; snapshot: string;
  overlays?: Overlay[];
  /** Per font package, its font directories and the files it puts in each (pinned mtimes: pinFontDirs) */
  fontDirs?: Record<string, Record<string, string[]>>;
  packages: Record<string, DebPackage>;
  apps: Record<string, GuiApp>;
}

export interface InstallProgress {
  phase: 'fetch' | 'unpack' | 'triggers' | 'done';
  pkg?: string;
  done: number;
  total: number;
  bytes: number;
  totalBytes: number;
  /**
   * Work done, in package bytes: a package counts half once it is fetched and
   * decoded (from the network or the cache) and half once its files are
   * written, so `doneBytes / totalBytes` is the fraction of the install done.
   * Packages are decoded in parallel and written largest first; counting
   * written ones only would sit at 0 for most of the install.
   */
  doneBytes?: number;
}

export interface InstallResult {
  app: string;
  packages: number;
  /** packages that were already installed */
  skipped: number;
  /** fetched from the network vs from the browser cache */
  fetched: number;
  cached: number;
  bytes: number;
  /** fetch: waiting for downloaded and decoded packages; unpack: writing their files */
  ms: { total: number; fetch: number; unpack: number; triggers: number };
}

const STATUS = '/var/lib/shiro-gui/status.json';
const CACHE_NAME = 'tabcomputer-debs-v1';
/** Paths not worth unpacking in a browser. */
const SKIP_PATH = /^\/usr\/share\/(doc|man|info|lintian|bug|locale|gtk-doc|help)\//;
const BIN_DIRS = /^\/(usr\/)?s?bin\//;

let manifestOverride: AppsManifest | null = null;
let fetchOverride: ((pkg: DebPackage) => Promise<Uint8Array>) | null = null;

/** Tests: use this manifest / fetcher instead of the network. */
export function configureGuiApps(o: { manifest?: AppsManifest | null; fetchDeb?: ((pkg: DebPackage) => Promise<Uint8Array>) | null }): void {
  if (o.manifest !== undefined) manifestOverride = o.manifest;
  if (o.fetchDeb !== undefined) fetchOverride = o.fetchDeb;
}

let manifestPromise: Promise<AppsManifest> | null = null;

export function guiManifest(): Promise<AppsManifest> {
  if (manifestOverride) return Promise.resolve(manifestOverride);
  manifestPromise ??= fetch(new URL('gui/apps.json', baseUrl()).href).then((r) => {
    if (!r.ok) throw new Error(`gui/apps.json: HTTP ${r.status}`);
    return r.json() as Promise<AppsManifest>;
  });
  manifestPromise.catch(() => { manifestPromise = null; });
  return manifestPromise;
}

function baseUrl(): string {
  if (typeof document !== 'undefined' && document.baseURI) return document.baseURI;
  return (globalThis as { location?: { href: string } }).location?.href ?? 'http://localhost/';
}

interface Status { packages: Record<string, string>; apps: string[] }

async function readStatus(fs: FileSystem): Promise<Status> {
  try { return JSON.parse(await fs.readFile(STATUS, 'utf8') as string) as Status; } catch { return { packages: {}, apps: [] }; }
}

async function writeStatus(fs: FileSystem, s: Status): Promise<void> {
  await fs.mkdir('/var/lib/shiro-gui', { recursive: true });
  await fs.writeFile(STATUS, JSON.stringify(s, null, 1));
}

export async function isAppInstalled(fs: FileSystem, app: string): Promise<boolean> {
  if (await debianMode(fs)) {
    const a = (await guiManifest()).apps[app];
    return !!a && (await fs.exists(`/var/lib/dpkg/info/${a.pkg ?? app}.list`)) && (await fs.exists(a.bin));
  }
  const st = await readStatus(fs);
  return st.apps.includes(app);
}

/**
 * Debian mode (`debian install`, docs/DEBIAN.md): the system is a Debian
 * rootfs managed by dpkg, so apps come from its own apt instead of being
 * unpacked from this manifest (whose bookworm libraries would replace the
 * system's).
 */
export async function debianMode(fs: FileSystem): Promise<boolean> {
  try { return !!(await (await import('../debian/rootfs')).installedRootfs(fs)); } catch { return false; }
}

/** Install with the system's apt (Debian mode); `log` gets apt's output lines. */
async function installWithApt(fs: FileSystem, kernel: Kernel, name: string, app: GuiApp, log: (s: string) => void): Promise<InstallResult> {
  const t0 = Date.now();
  const pkg = app.pkg ?? name;
  const { BufferFile } = await import('../kernel/fd');
  // `sudo` is Shiro's builtin (uid 0 for apt); a bare name reaches it through the kernel's builtin loader
  const run = async (cmd: string) => {
    const out = new BufferFile(null);
    // apt's output as it comes (the launch placeholder shows the last line); whole lines only
    const dec = new TextDecoder();
    let pending = '';
    out.onData = (d) => {
      const parts = (pending + dec.decode(d, { stream: true })).split('\n');
      pending = parts.pop() ?? '';
      for (const line of parts) { const l = line.split('\r').pop()!.trimEnd(); if (l) log(l); }
    };
    const argv = cmd.split(' ');
    const p = kernel.spawn({ path: argv[0], argv, cwd: '/', env: appEnv({ DEBIAN_FRONTEND: 'noninteractive' }), fds: { 0: new BufferFile(''), 1: out, 2: out } });
    const st = await exitOf(kernel, p);
    if (pending.trim()) log(pending.trim());
    return st;
  };
  // lists may be empty right after `debian install`
  const hasLists = (await fs.readdir('/var/lib/apt/lists').catch(() => [] as string[])).some((f) => f.endsWith('_Packages'));
  if (!hasLists && await run('sudo apt-get update') !== 0) throw new Error('apt-get update failed');
  if (await run(`sudo apt-get install -y --no-install-recommends ${pkg}`) !== 0) throw new Error(`apt-get install ${pkg} failed`);
  const ms = Date.now() - t0;
  return { app: name, packages: 1, skipped: 0, fetched: 0, cached: 0, bytes: 0, ms: { total: ms, fetch: 0, unpack: ms, triggers: 0 } };
}

// ── fetching ──

async function sha256Hex(b: Uint8Array): Promise<string> {
  const d = new Uint8Array(await crypto.subtle.digest('SHA-256', b as BufferSource));
  return Array.from(d, (x) => x.toString(16).padStart(2, '0')).join('');
}

async function openCache(): Promise<Cache | null> {
  try { return typeof caches !== 'undefined' ? await caches.open(CACHE_NAME) : null; } catch { return null; }
}

/** A .deb by content hash: Cache Storage first, else the server's /debian/ route. */
async function getDeb(p: DebPackage, cache: Cache | null): Promise<{ data: Uint8Array; cached: boolean }> {
  return getBlob(p.sha256, p.size, `debian/${p.filename}`, cache, fetchOverride ? () => fetchOverride!(p) : null);
}

/** Bytes by sha256: Cache Storage, else `url` (or `fetcher`), verified and cached. */
async function getBlob(sha256: string, size: number, url: string, cache: Cache | null, fetcher: (() => Promise<Uint8Array>) | null): Promise<{ data: Uint8Array; cached: boolean }> {
  const p = { sha256, size, filename: url };
  const key = new URL(`sha256/${p.sha256}`, baseUrl()).href;
  if (cache) {
    const hit = await cache.match(key).catch(() => undefined);
    if (hit) {
      const data = new Uint8Array(await hit.arrayBuffer());
      if (data.length === p.size) return { data, cached: true };
    }
  }
  let data: Uint8Array;
  if (fetcher) data = await fetcher();
  else {
    const r = await fetch(new URL(url, baseUrl()).href);
    if (!r.ok) throw new Error(`${p.filename}: HTTP ${r.status}`);
    data = new Uint8Array(await r.arrayBuffer());
  }
  const h = await sha256Hex(data);
  if (h !== p.sha256) throw new Error(`${p.filename}: sha256 mismatch (got ${h})`);
  if (cache) await cache.put(key, new Response(data as BodyInit, { headers: { 'content-type': 'application/vnd.debian.binary-package' } })).catch(() => {});
  return { data, cached: false };
}

// ── unpacking ──

async function unpack(fs: FileSystem, entries: TarEntry[], ownBins: Set<string>): Promise<number> {
  let files = 0;
  for (const e of entries) {
    let path = '/' + e.path.replace(/^\.?\/+/, '').replace(/\/+$/, '');
    if (path === '/' || SKIP_PATH.test(path + '/')) continue;
    // Never replace Shiro's own commands (and their /usr/bin shims) with a library package's helper
    if (BIN_DIRS.test(path) && !ownBins.has(path) && e.type !== 'dir' && (await fs.exists(path).catch(() => false))) continue;
    if (e.type === 'dir') { await fs.mkdir(path, { recursive: true }).catch(() => {}); continue; }
    const dir = path.slice(0, path.lastIndexOf('/')) || '/';
    await fs.mkdir(dir, { recursive: true }).catch(() => {});
    if (e.type === 'symlink') {
      try { await fs.unlink(path); } catch { /* none */ }
      await fs.symlink(e.linkname, path).catch(() => {});
    } else {
      // with the package's file time, as dpkg does (GIMP asks a plug-in again when its time isn't the one in
      // pluginrc, and the registry that ships with it was made from these times)
      await fs.writeFile(path, e.data, { mode: e.mode & 0o7777, times: e.mtime ? { mtime: e.mtime * 1000 } : undefined });
    }
    files++;
  }
  return files;
}

// ── triggers ──

/**
 * postinst-like steps: `argv` runs when a package just unpacked put files in
 * `dir`, unless all of them are `covered` (packages whose result ships as an
 * overlay: gen-apps.py).
 */
const TRIGGERS: { dir: string; argv?: string[]; run?: (fs: FileSystem) => Promise<unknown>; covered?: string[] }[] = [
  {
    dir: '/usr/lib/x86_64-linux-gnu/gdk-pixbuf-2.0/2.10.0/loaders/',
    argv: ['/usr/lib/x86_64-linux-gnu/gdk-pixbuf-2.0/gdk-pixbuf-query-loaders', '--update-cache'],
    covered: ['libgdk-pixbuf-2.0-0', 'librsvg2-common'],
  },
  { dir: '/usr/share/glib-2.0/schemas/', argv: ['/usr/bin/glib-compile-schemas', '/usr/share/glib-2.0/schemas'] },
  // gtk-update-icon-cache, written here (icon-cache.ts): without it GTK stats all of hicolor at every start
  { dir: '/usr/share/icons/hicolor/', run: async (fs) => (await import('./icon-cache')).updateIconCache(fs, '/usr/share/icons/hicolor') },
];

/**
 * Fontconfig's caches (shipped as overlays in /var/cache/fontconfig, made by
 * Debian's fontconfig: gen-apps.py) hold the mtime of the font directory they
 * describe, and fontconfig rescans a directory whose mtime differs (~1.9 s of a
 * GTK app's first start). So a font directory gets this fixed mtime, the one
 * the caches were made with, when it holds exactly its package's files; with
 * other files in it (a second package's) it keeps its real mtime and
 * fontconfig rescans it, as it would without the cache.
 */
export const FONT_DIR_MTIME_MS = Date.UTC(2023, 0, 1);

async function pinFontDirs(fs: FileSystem, m: AppsManifest, installed: string[]): Promise<void> {
  for (const pkg of installed) {
    for (const [dir, files] of Object.entries(m.fontDirs?.[pkg] ?? {})) {
      const have = await fs.readdir(dir).catch(() => null);
      if (!have || have.length !== files.length || !files.every((f) => have.includes(f))) continue;
      await fs.utimes(dir, FONT_DIR_MTIME_MS, FONT_DIR_MTIME_MS, { atime: 0, mtime: 0 }).catch(() => {});
    }
  }
}

/** The triggers a package's files set off. */
function triggersOf(pkg: string, entries: TarEntry[]): Set<number> {
  const out = new Set<number>();
  TRIGGERS.forEach((t, i) => {
    if (t.covered?.includes(pkg)) return;
    if (entries.some((e) => e.type !== 'dir' && ('/' + e.path.replace(/^\.?\/+/, '')).startsWith(t.dir))) out.add(i);
  });
  return out;
}

async function runTriggers(fs: FileSystem, kernel: Kernel, which: Set<number>, log: (s: string) => void): Promise<void> {
  // (XDG base directories: apps that mkdir only their own subdirectory need them, like galculator)
  for (const d of ['/var/cache/fontconfig', '/tmp/.X11-unix', '/tmp/runtime-user', '/home/user/.cache', '/home/user/.config', '/home/user/.local/share']) await fs.mkdir(d, { recursive: true }).catch(() => {});
  await fs.chmod('/tmp/runtime-user', 0o700).catch(() => {});
  // independent of each other: each is its own Blink worker
  await Promise.all([...which].map(async (i) => {
    const t = TRIGGERS[i];
    const t0 = Date.now();
    if (t.run) {
      await t.run(fs).then(() => log(`trigger ${t.dir}: ${Date.now() - t0} ms`), (e) => log(`trigger ${t.dir}: ${(e as Error).message}`));
      return;
    }
    if (!t.argv || !(await fs.exists(t.argv[0]).catch(() => false))) return;
    const status = await runQuiet(kernel, t.argv, {});
    log(`trigger ${t.argv[0].split('/').pop()}: status ${status >> 8} in ${Date.now() - t0} ms`);
  }));
}

/**
 * A process's wait status, with the process reaped. What the page starts is a
 * child of init, which nothing waits for: a quit app stayed in the process
 * table as a zombie (`ps`, Activity) until the kernel's 30-second sweep (#118).
 */
export async function exitOf(kernel: Kernel, p: { pid: number; wait(): Promise<number> }): Promise<number> {
  const st = await p.wait();
  await kernel.waitpid(p.pid, 1 /* WNOHANG */).catch(() => undefined);
  return st;
}

async function runQuiet(kernel: Kernel, argv: string[], env: Record<string, string>): Promise<number> {
  const { BufferFile } = await import('../kernel/fd');
  const out = new BufferFile(null);
  const p = kernel.spawn({ path: argv[0], argv, cwd: '/', env: { ...appEnv(), ...env }, fds: { 0: new BufferFile(''), 1: out, 2: out } });
  return exitOf(kernel, p);
}

/** Environment GUI apps start with. */
export function appEnv(extra: Record<string, string> = {}): Record<string, string> {
  return {
    ...toolkitScaleEnv(),
    DISPLAY: ':0', HOME: '/home/user', USER: 'user', LANG: 'C.UTF-8', PATH: '/usr/local/bin:/usr/bin:/bin',
    XDG_RUNTIME_DIR: '/tmp/runtime-user', NO_AT_BRIDGE: '1', GTK_A11Y: 'none',
    // no session bus: fail fast instead of GDBus autolaunch
    DBUS_SESSION_BUS_ADDRESS: 'unix:path=/run/no-session-bus',
    // OpenSSL's default CA paths are the openssl package's symlinks (not shipped): use the bundle (an overlay)
    SSL_CERT_FILE: '/etc/ssl/certs/ca-certificates.crt',
    ...extra,
  };
}

/**
 * Per-toolkit environment. Empty since Blink patch 0029 (SSE compares): GTK 3
 * spun after mapping its window before it, with and without the JIT.
 */
export function toolkitEnv(app: GuiApp): Record<string, string> {
  void app;
  return {};
}

// ── install & launch ──

const installing = new Map<string, Promise<InstallResult>>();
const watchers = new Map<string, Set<(p: InstallProgress) => void>>();

/** Install `name` (or join the install in progress); `onProgress` hears it either way. */
export function installApp(fs: FileSystem, kernel: Kernel, name: string, onProgress?: (p: InstallProgress) => void, log: (s: string) => void = () => {}): Promise<InstallResult> {
  const off = onProgress ? watchInstall(name, onProgress) : () => {};
  let p = installing.get(name);
  if (!p) {
    const notify = (pr: InstallProgress) => { for (const cb of watchers.get(name) ?? []) cb(pr); };
    p = doInstall(fs, kernel, name, notify, log).finally(() => installing.delete(name));
    installing.set(name, p);
  }
  return p.finally(off);
}

/** Progress of `name`'s installs (from any caller); returns unsubscribe. */
export function watchInstall(name: string, cb: (p: InstallProgress) => void): () => void {
  let set = watchers.get(name);
  if (!set) watchers.set(name, set = new Set());
  set.add(cb);
  return () => { set.delete(cb); };
}

/** The install of `name` in progress, if any. */
export function installInProgress(name: string): Promise<InstallResult> | undefined {
  return installing.get(name);
}

/** What installing `name` would download now: packages not yet installed, and their size. */
export async function pendingDownload(fs: FileSystem, name: string): Promise<{ packages: number; bytes: number }> {
  const m = await guiManifest();
  const app = m.apps[name];
  if (!app) return { packages: 0, bytes: 0 };
  const status = await readStatus(fs);
  const want = app.packages.filter((n) => status.packages[n] !== m.packages[n].version);
  return { packages: want.length, bytes: want.reduce((a, n) => a + m.packages[n].size, 0) };
}

async function doInstall(fs: FileSystem, kernel: Kernel, name: string, onProgress: ((p: InstallProgress) => void) | undefined, log: (s: string) => void): Promise<InstallResult> {
  const t0 = Date.now();
  const m = await guiManifest();
  const app = m.apps[name];
  if (!app) throw new Error(`no GUI app named ${name}`);
  if (await debianMode(fs)) return installWithApt(fs, kernel, name, app, log);
  const status = await readStatus(fs);
  // largest first: decoding (xz in JavaScript) is the long pole, so the big ones start at once
  const want = app.packages.filter((n) => status.packages[n] !== m.packages[n].version).sort((a, b) => m.packages[b].size - m.packages[a].size);
  const totalBytes = want.reduce((a, n) => a + m.packages[n].size, 0);
  const res: InstallResult = { app: name, packages: app.packages.length, skipped: app.packages.length - want.length, fetched: 0, cached: 0, bytes: 0, ms: { total: 0, fetch: 0, unpack: 0, triggers: 0 } };
  const cache = await openCache();
  const ownBins = new Set([app.bin]);
  const triggers = new Set<number>();
  let done = 0;
  let readyBytes = 0, writtenBytes = 0;
  const report = (phase: InstallProgress['phase'], pkg?: string) => onProgress?.({ phase, pkg, done, total: want.length, bytes: res.bytes, totalBytes, doneBytes: (readyBytes + writtenBytes) / 2 });
  // Fetch with a few requests in flight and decode each .deb (workers) as it
  // arrives; write the files in that order
  const ready = new Map<string, Promise<{ entries: TarEntry[]; size: number; cached: boolean }>>();
  let next = 0;
  const startMore = () => {
    while (next < want.length && ready.size < 16) {
      const n = want[next++];
      ready.set(n, getDeb(m.packages[n], cache).then(async ({ data, cached }) => {
        const size = data.length; // (the decoder takes the buffer)
        const entries = await debEntriesOffThread(data);
        readyBytes += m.packages[n].size;
        report('fetch', n);
        return { size, cached, entries };
      }));
    }
  };
  startMore();
  // (__guiNoKeptOverlays: scripts/gui/make-pluginrc.mjs wants GIMP to write its registry itself)
  const noKept = !!(globalThis as { __guiNoKeptOverlays?: boolean }).__guiNoKeptOverlays;
  const overlays = (m.overlays ?? []).filter((o) => want.includes(o.when) && !(o.keep && noKept)).map((o) => [o, getBlob(o.sha256, o.size, `gui/overlay/${o.sha256}`, cache, fetchOverride ? () => fetchOverride!({ version: '', filename: `gui/overlay/${o.sha256}`, sha256: o.sha256, size: o.size }) : null)] as const);
  for (const [, blob] of overlays) blob.catch(() => {}); // awaited after the packages
  for (const n of want) {
    const tw = Date.now();
    const { entries, size, cached } = await ready.get(n)!;
    res.ms.fetch += Date.now() - tw;
    if (cached) res.cached++; else { res.fetched++; res.bytes += size; }
    ready.delete(n);
    startMore();
    report('fetch', n);
    const tu = Date.now();
    await unpack(fs, entries, ownBins);
    for (const i of triggersOf(n, entries)) triggers.add(i);
    res.ms.unpack += Date.now() - tu;
    status.packages[n] = m.packages[n].version;
    done++;
    writtenBytes += m.packages[n].size;
    report('unpack', n);
  }
  for (const path of app.remove ?? []) await fs.rm(path, { recursive: true }).catch(() => {});
  for (const [link, target] of app.links ?? []) {
    if (await fs.exists(link).catch(() => false)) continue;
    await fs.mkdir(link.slice(0, link.lastIndexOf('/')), { recursive: true }).catch(() => {});
    await fs.symlink(target, link).catch(() => {});
  }
  for (const [o, blob] of overlays) {
    const { data } = await blob;
    if (o.tar) { await unpack(fs, untar(data), ownBins); continue; }
    if (o.keep && (await fs.exists(o.path).catch(() => false))) continue;
    await fs.mkdir(o.path.slice(0, o.path.lastIndexOf('/')), { recursive: true }).catch(() => {});
    await fs.writeFile(o.path, data);
  }
  await pinFontDirs(fs, m, want);
  const tt = Date.now();
  report('triggers');
  await runTriggers(fs, kernel, triggers, log);
  res.ms.triggers = Date.now() - tt;
  if (!status.apps.includes(name)) status.apps.push(name);
  await writeStatus(fs, status);
  res.ms.total = Date.now() - t0;
  report('done');
  (globalThis as { __guiInstall?: InstallResult }).__guiInstall = res;
  return res;
}

/** The text hook for a toolkit (scripts/gui/text-hook/): GTK 2/3 through cairo and GDK, Qt 5 Widgets through QPainter */
const TEXT_HOOKS: Record<string, string> = { gtk2: 'libshiro-text-hook.so', gtk3: 'libshiro-text-hook.so', qt5: 'libshiro-qt-text-hook.so' };

/**
 * DOM-text mode (docs/DOM-RENDERING.md): GTK apps load libshiro-text-hook.so,
 * which tells Xshiro the text they draw (scripts/gui/text-hook/).
 */
const SESSION_BUS = 'unix:path=/tmp/runtime-user/bus';
const buses = new WeakMap<Kernel, Promise<string | null>>();

/**
 * The session bus apps share (Debian's dbus-daemon, the manifest's
 * `dbus-session`), started with the first app: single-instance checks
 * (LXImage-Qt), settings and portals look for one. Its address, or null when
 * it can't run (then apps get the unreachable default and fail fast).
 */
function sessionBus(kernel: Kernel, m: AppsManifest): Promise<string | null> {
  if (!m.apps['dbus-session'] || !kernel.fs) return Promise.resolve(null);
  let p = buses.get(kernel);
  if (!p) {
    p = startSessionBus(kernel, m.apps['dbus-session'].bin).catch(() => null);
    buses.set(kernel, p);
    // gone (or never came up): the next launch tries again
    void p.then((a) => { if (!a) buses.delete(kernel); });
  }
  return p;
}

async function startSessionBus(kernel: Kernel, bin: string): Promise<string | null> {
  const fs = kernel.fs as FileSystem;
  if (!(await isAppInstalled(fs, 'dbus-session'))) await installApp(fs, kernel, 'dbus-session');
  // libdbus needs a machine id
  if (!(await fs.exists('/etc/machine-id').catch(() => false))) {
    const id = Array.from(crypto.getRandomValues(new Uint8Array(16)), (b) => b.toString(16).padStart(2, '0')).join('') + '\n';
    await fs.writeFile('/etc/machine-id', id).catch(() => {});
  }
  await fs.mkdir('/tmp/runtime-user', { recursive: true }).catch(() => {});
  const sock = SESSION_BUS.slice('unix:path='.length);
  if (await fs.exists(sock).catch(() => false)) await fs.unlink(sock).catch(() => {});
  const { BufferFile } = await import('../kernel/fd');
  const p = kernel.spawn({
    path: bin, argv: ['dbus-daemon', '--session', '--nofork', '--nopidfile', `--address=${SESSION_BUS}`], cwd: '/',
    env: appEnv(), fds: { 0: new BufferFile(''), 1: new BufferFile(null), 2: new BufferFile(null) },
  });
  let exited = false;
  void exitOf(kernel, p).then(() => { exited = true; buses.delete(kernel); });
  for (let t = 0; t < 15000 && !exited; t += 100) {
    if (await fs.exists(sock).catch(() => false)) return SESSION_BUS;
    await new Promise((r) => setTimeout(r, 100));
  }
  return null;
}

async function writeHomeDefaults(kernel: Kernel, files: Record<string, string>): Promise<void> {
  const fs = kernel.fs as FileSystem | undefined;
  if (!fs) return;
  for (const [rel, text] of Object.entries(files)) {
    const path = `/home/user/${rel}`;
    if (await fs.exists(path).catch(() => true)) continue;
    await fs.mkdir(path.slice(0, path.lastIndexOf('/')), { recursive: true }).catch(() => {});
    await fs.writeFile(path, text).catch(() => {});
  }
}

async function textHookEnv(kernel: Kernel, app: GuiApp): Promise<Record<string, string>> {
  const name = TEXT_HOOKS[app.toolkit];
  if (!name || !kernel.fs) return {};
  if ((await import('../x11/dom-text')).domTextMode() === 'pixels') return {};
  const path = `/usr/lib/shiro/${name}`;
  return (await shipLib(kernel.fs as FileSystem, name, path)) ? { LD_PRELOAD: path } : {};
}

/** glvnd loads vendor libraries by name from the library path */
const GLX_VENDOR_LIB = 'libGLX_tabcomputer.so.0';

/**
 * Fast GL (docs/research/GL.md): while glshiro serves GL (Xshiro advertises
 * GLX), apps that link libglvnd get its vendor library libGLX_tabcomputer
 * and pick it by name. Otherwise nothing changes: no GLX, Mesa's software
 * paths or none.
 */
export async function glEnv(kernel: Kernel, app: GuiApp): Promise<Record<string, string>> {
  if (!kernel.fs || !(app.packages ?? []).includes('libglx0')) return {};
  const { glxEnabled, GLX_VENDOR_NAME } = await import('../x11/glx');
  if (!glxEnabled()) return {};
  const ok = await shipLib(kernel.fs as FileSystem, GLX_VENDOR_LIB, `/usr/lib/x86_64-linux-gnu/${GLX_VENDOR_LIB}`);
  return ok ? { __GLX_VENDOR_LIBRARY_NAME: GLX_VENDOR_NAME } : {};
}

/** Put one of public/gui/lib/'s libraries at `path` (small, HTTP-cached; rewritten when it changed). True when it's there. */
async function shipLib(fs: FileSystem, name: string, path: string): Promise<boolean> {
  try {
    const r = await fetch(new URL(`gui/lib/${name}`, baseUrl()).href);
    if (!r.ok) return await fs.exists(path).catch(() => false);
    const lib = new Uint8Array(await r.arrayBuffer());
    // not a library (a dev server's index.html for a missing file)
    if (lib[0] !== 0x7f || lib[1] !== 0x45 || lib[2] !== 0x4c || lib[3] !== 0x46) return await fs.exists(path).catch(() => false);
    const have = await fs.readFile(path).catch(() => null) as Uint8Array | null;
    if (!have || have.length !== lib.length || have.some((b, i) => b !== lib[i])) {
      await fs.mkdir(path.slice(0, path.lastIndexOf('/')), { recursive: true }).catch(() => {});
      await fs.writeFile(path, lib, { mode: 0o755 });
    }
  } catch { return false; }
  return true;
}

/** `pid` changes when a restored process ends at once and the app is started the usual way instead */
export interface LaunchedApp { pid: number; exited: Promise<number>; output: () => string }

type SnapshotModule = typeof import('./snapshot');
type Stored = import('./snapshot').StoredSnapshot;

import { lastSnapshotSize, noteSnapshotApp, noteSnapshotSize, recentSnapshotApps, snapshotsFor, snapshotsOn } from './snapshot-setting';
export { snapshotsOn };

/**
 * Apps started without the session bus while snapshots are on. An app that
 * holds a bus connection can't be snapshotted (the daemon keeps its side of
 * it: docs/research/GUI_SNAPSHOTS.md), and these work without one: they use
 * the bus to hand a second invocation's files to the running instance.
 */
const SNAPSHOT_WITHOUT_BUS = new Set(['gimp', 'inkscape', 'mousepad', 'featherpad']);

interface Plan {
  S: SnapshotModule;
  key: string;
  /** The X client number the app's snapshots use (null: taken, by another instance of it) */
  index: number | null;
  /** The stored snapshot when it is still good */
  stored: Stored | null;
  /** Why the stored one was not good (it was dropped) */
  problem: string | null;
}

/**
 * Whether this launch can use snapshots, and with what: the stored one when it
 * is still good (a stale one is dropped), the key a new one would get, and
 * the X client number the app's snapshots use.
 */
async function snapshotPlan(kernel: Kernel, m: AppsManifest, name: string, app: GuiApp, argv: string[], env: Record<string, string>, launch = true): Promise<Plan | null> {
  const fs = kernel.fs as FileSystem | undefined;
  if (!fs || typeof indexedDB === 'undefined') return null;
  try {
    if (!snapshotsFor(name) || await debianMode(fs)) return null;
    const S = await import('./snapshot');
    const { getXSession } = await import('../x11/session');
    const { server } = await getXSession(0);
    const { FIRST_RESERVED_CLIENT, LAST_CLIENT } = await import('../x11/server');
    const key = S.snapshotKey({
      app: name, argv, env, packages: app.packages.map((n) => `${n}=${m.packages[n]?.version ?? ''}`),
      screen: [server.width, server.height, server.dpi], textMode: `${server.domText}/${server.domTextRaster}`,
    });
    const index = S.clientNumberFor(name, FIRST_RESERVED_CLIENT, LAST_CLIENT);
    const free = index !== null && !server.clients.has(index);
    let stored: Stored | null = null;
    let problem: string | null = null;
    // (the index says whether it is good: the images are read only for a restore)
    const entry = free ? await S.snapshotEntry(name) : null;
    if (entry) {
      problem = await S.snapshotProblem(fs, entry, key);
      // (`launch`: a start for the person, which says why it was not a restore; a retake's look says nothing)
      if (problem) { if (launch) snapshotLog(name, { restored: false, why: problem }); await S.dropSnapshot(name); } else if (launch) stored = await S.loadSnapshot(name); else stored = { meta: entry.meta, images: [], x: new ArrayBuffer(0) };
    }
    // (another instance is running with the app's client number: this one starts the usual way, unrecorded)
    return { S, key, index: free ? index : null, stored, problem };
  } catch (e) {
    if (launch) snapshotLog(name, { restored: false, why: String((e as Error)?.message ?? e) });
    return null;
  }
}

/**
 * A restored process ended within seconds, and not cleanly: what it left. Logged
 * to the kernel log (dmesg) and kept in the profile (`restoreFailures` in
 * snapshot.ts), since the app is started again at once and its output with it.
 */
async function restoreFailure(plan: Plan, name: string, pid: number, status: number, ms: number, output: string, klogAt: number): Promise<import('./snapshot').RestoreFailure> {
  const { klog, LOG_WARNING } = await import('../kernel/klog');
  const meta = plan.stored!.meta;
  const failure: import('./snapshot').RestoreFailure = {
    app: name, at: Date.now(), status, how: plan.S.statusWords(status), ms,
    engine: plan.S.buildIds().engine, hidden: !!meta.hidden, samePid: pid === meta.procs[0].pid,
    output: output.slice(-4000),
    klog: klog.since(Math.max(klogAt, klog.firstSeq)).map((r) => r.text).slice(-40),
  };
  const last = output.trim().split('\n').filter(Boolean).slice(-3);
  klog.log(LOG_WARNING, `gui: ${name}[${pid}] restored from its snapshot ended after ${ms} ms (${failure.how}); its snapshot is dropped and the app started the usual way${last.length ? `. Its last output: ${last.join(' | ').slice(0, 400)}` : ''}`);
  plan.S.noteRestoreFailure(failure);
  return failure;
}

/** What snapshots did, newest last (`window.__guiSnapshots`: tests and the benchmark read it) */
function snapshotLog(app: string, what: Record<string, unknown>): void {
  const g = globalThis as { __guiSnapshots?: Record<string, unknown>[] };
  (g.__guiSnapshots ??= []).push({ app, at: Date.now(), ...what });
  if (g.__guiSnapshots.length > 50) g.__guiSnapshots.shift();
}

interface Prepared { m: AppsManifest; app: GuiApp; argv: string[]; env: Record<string, string>; cwd: string }

/** What a start of `name` runs: its arguments and environment (the session bus is started when it is wanted) */
async function prepare(kernel: Kernel, name: string, args: string[], env: Record<string, string>): Promise<Prepared> {
  const m = await guiManifest();
  const app = m.apps[name];
  if (!app) throw new Error(`no GUI app named ${name}`);
  if (app.home) await writeHomeDefaults(kernel, app.home);
  // Xlib keeps its parsed Compose table in ~/.compose-cache when that directory exists; without it every
  // Xlib, Xt and FLTK app parses the locale's Compose file at each start (a quarter to a third of xterm's
  // and Dillo's launch: docs/GUI_LAUNCH.md)
  await (kernel.fs as FileSystem | undefined)?.mkdir('/home/user/.compose-cache', { recursive: true }).catch(() => {});
  const withoutBus = SNAPSHOT_WITHOUT_BUS.has(name) && args.length === 0 && snapshotsFor(name);
  const bus = withoutBus ? null : await sessionBus(kernel, m);
  if (bus) env = { DBUS_SESSION_BUS_ADDRESS: bus, ...env };
  // Measurements (tests/browser/gui-launch-bench.mjs): variables for this page's launches, e.g. the engine's profile
  env = { ...env, ...((globalThis as { __guiLaunchEnv?: Record<string, string> }).__guiLaunchEnv ?? {}) };
  // argv[0]: the name for programs on the PATH, the full path for the others (LibreOffice's
  // oosplash finds soffice.bin next to argv[0])
  const argv = [/^\/usr\/(local\/)?s?bin\//.test(app.bin) ? app.bin.split('/').pop()! : app.bin, ...(app.args ?? []), ...args];
  const fullEnv = appEnv({ ...toolkitEnv(app), ...(await textHookEnv(kernel, app)), ...(await glEnv(kernel, app)), ...env });
  return { m, app, argv, env: fullEnv, cwd: '/home/user' };
}

/** Apps the person has running (started here, not yet exited): no hidden start of one of these */
const runningApps = new Map<string, number>();

/** Start an installed app as a background kernel process. */
export async function launchApp(kernel: Kernel, name: string, args: string[] = [], env: Record<string, string> = {}, opts: { onOutput?: (text: string) => void } = {}): Promise<LaunchedApp> {
  // (a hidden start in the background ends now: the person's app gets the machine, and Geany's
  // second instance would hand over to the hidden one)
  if (snapshotsOn()) await (await retakesReady(kernel))?.userLaunch(name);
  const { m, app, argv, env: fullEnv, cwd } = await prepare(kernel, name, args, env);
  const { BufferFile } = await import('../kernel/fd');
  // its windows belong to this app on the desktop, whatever their WM_CLASS
  const instance = app.bin.split('/').pop()!.toLowerCase().replace(/-\d+(\.\d+)*$/, '');
  const ids = await import('../x11/app-ids');
  if (instance !== name) ids.appIdAliases.set(instance, name);
  ids.setParentPid((pid) => kernel.procs.get(pid)?.ppid);
  const out = new BufferFile(null);
  if (opts.onOutput) {
    const dec = new TextDecoder();
    out.onData = (d) => { try { opts.onOutput!(dec.decode(d, { stream: true })); } catch { /* a listener's problem */ } };
  }
  // Snapshots (src/gui/snapshot.ts): a plain start of the app is restored from the image its
  // last start left, when nothing it was made from has changed
  const plan = args.length === 0 ? await snapshotPlan(kernel, m, name, app, argv, fullEnv) : null;
  if (plan) noteSnapshotApp(name);
  let p: Process | null = null;
  const restoredPids: number[] = [];
  let restoredAt = 0;
  // (where the kernel log was when the restore began: a restore that ends at once reports what it logged)
  let klogAt = 0;
  if (plan?.stored) {
    const t0 = Date.now();
    try {
      klogAt = (await import('../kernel/klog')).klog.lastSeq;
      // (its windows name the pid it had then)
      if (!kernel.procs.has(plan.stored.meta.procs[0].pid) && !ids.pidAppIds.has(plan.stored.meta.procs[0].pid)) { ids.pidAppIds.set(plan.stored.meta.procs[0].pid, name); restoredPids.push(plan.stored.meta.procs[0].pid); }
      const r = await plan.S.restoreSnapshot(kernel, plan.stored, { stdin: new BufferFile(''), output: out });
      p = r.proc;
      snapshotLog(name, { restored: true, ms: Date.now() - t0, x: r.ms.x, image: r.ms.image, bytes: plan.stored.meta.sizes, pid: p.pid, samePid: p.pid === plan.stored.meta.procs[0].pid, hidden: !!plan.stored.meta.hidden });
      restoredAt = t0;
      // (tests: a restored process that dies as an image that doesn't run would)
      if ((globalThis as { __guiSnapshotKillRestored?: boolean }).__guiSnapshotKillRestored) kernel.kill(p.pid, 6 /* SIGABRT */);
    } catch (e) {
      for (const pid of restoredPids.splice(0)) ids.pidAppIds.delete(pid);
      snapshotLog(name, { restored: false, why: String((e as Error)?.message ?? e) });
      await plan.S.dropSnapshot(name);
    }
  }
  if (!p) {
    p = kernel.spawn({ path: app.bin, argv, cwd, env: fullEnv, fds: { 0: new BufferFile(''), 1: out, 2: out } });
    if (plan && plan.index !== null) {
      // its first start: keep its X requests and the files it opens, and its image once it is up and quiet
      const proc = p;
      proc.data.openLog = new Set<string>();
      proc.data.openWritten = new Set<string>();
      const { recordXClient } = await import('../x11/display');
      const { S, key } = plan;
      const watch = S.snapshotWhenQuiet(kernel, name, proc, recordXClient(proc.pid, plan.index), key, { argv, env: fullEnv, cwd, output: out });
      void watch.done.then((r) => {
        delete proc.data.openLog; delete proc.data.openWritten;
        S.setSkip(name, key, r.ok || !r.never ? null : r.why ?? '');
        if (r.ok && r.meta) noteSnapshotSize(name, r.meta.sizes.image);
        snapshotLog(name, r.ok ? { taken: true, ms: r.ms, bytes: r.meta?.sizes, dropped: r.dropped } : { taken: false, why: r.why });
      });
    }
  }
  const first = p;
  ids.pidAppIds.set(first.pid, name);
  runningApps.set(name, (runningApps.get(name) ?? 0) + 1);
  const launched: LaunchedApp = { pid: first.pid, output: () => out.text(), exited: Promise.resolve(0) };
  launched.exited = (async () => {
    let st = await exitOf(kernel, first);
    // An image that doesn't run (it ends within seconds, and not by a clean exit) is dropped, and none is
    // taken in the background until something it was made from changes (the next start the person makes
    // keeps a new one). The person asked for the app: it is started the usual way now
    if (restoredAt && plan && st !== 0 && Date.now() - restoredAt < 5000) {
      const why = `the restored process ended at once (${st})`;
      // What it left, kept past this page (tabcomputer#142): its status, what it wrote, the kernel log
      const failure = await restoreFailure(plan, name, first.pid, st, Date.now() - restoredAt, out.text(), klogAt);
      snapshotLog(name, { restored: false, why, how: failure.how, output: failure.output.slice(-2000), klog: failure.klog });
      await plan.S.dropSnapshot(name);
      plan.S.setSkip(name, plan.key, why);
      ids.pidAppIds.delete(first.pid);
      for (const old of restoredPids.splice(0)) ids.pidAppIds.delete(old);
      const again = kernel.spawn({ path: app.bin, argv, cwd, env: fullEnv, fds: { 0: new BufferFile(''), 1: out, 2: out } });
      ids.pidAppIds.set(again.pid, name);
      launched.pid = again.pid;
      st = await exitOf(kernel, again);
    }
    return st;
  })().finally(() => {
    ids.pidAppIds.delete(launched.pid);
    for (const old of restoredPids) ids.pidAppIds.delete(old);
    const n = (runningApps.get(name) ?? 1) - 1;
    if (n > 0) runningApps.set(name, n); else runningApps.delete(name);
    // It may have saved its settings as it quit: then its snapshot is taken again, in the background
    if (snapshotsFor(name)) void retakesReady(kernel).then((q) => q?.request(name));
  });
  (globalThis as { __guiLast?: LaunchedApp }).__guiLast = launched;
  return launched;
}

// ── retakes: a snapshot taken again from a start nobody sees (retake.ts) ──

type Queue = import('./retake').RetakeQueue;
let queue: Queue | null | undefined;
let queueLoad: Promise<void> | null = null;
let lastInput = 0;

/** Every process of `pid`'s family, each after its parent */
function familyPids(kernel: Kernel, pid: number): number[] {
  const out = [pid];
  for (let i = 0; i < out.length; i++) for (const p of kernel.procs.values()) if (p.ppid === out[i] && !out.includes(p.pid)) out.push(p.pid);
  return out;
}

/**
 * Why `name` needs a new snapshot now, or null: it has a good one, can't
 * have one, or is running (a second instance would be handed the first's
 * files, and its client number is taken).
 */
async function retakeNeeded(kernel: Kernel, name: string): Promise<string | null> {
  const fs = kernel.fs as FileSystem | undefined;
  if (!fs || runningApps.has(name) || installing.has(name)) return null;
  if (!snapshotsFor(name) || !(await isAppInstalled(fs, name).catch(() => false)) || await debianMode(fs)) return null;
  const { m, app, argv, env } = await prepare(kernel, name, [], {});
  // (snapshotPlan drops an outdated one)
  const plan = await snapshotPlan(kernel, m, name, app, argv, env, false);
  if (!plan || plan.index === null || plan.stored) return null;
  if (plan.S.skipReason(name, plan.key)) return null;
  return plan.problem ?? 'it has none';
}

/**
 * The same question without starting anything (the display, the session
 * bus): for the look after a page load. True unless the stored snapshot is
 * known good as far as the build, the engine, the screen, its age and its
 * files go, or the app is known not to take one on this build.
 */
async function mayNeedRetake(kernel: Kernel, name: string): Promise<boolean> {
  const fs = kernel.fs as FileSystem | undefined;
  if (!fs || runningApps.has(name) || !snapshotsFor(name)) return false;
  const S = await import('./snapshot');
  if (S.skippedOnThisBuild(name)) return false;
  const entry = await S.snapshotEntry(name);
  if (!entry) return true;
  const ids = S.buildIds();
  let made: { build?: string; engine?: string; screen?: number[] } = {};
  try { made = JSON.parse(entry.meta.key) as typeof made; } catch { return true; }
  if (made.build !== ids.build || made.engine !== ids.engine) return true;
  // (the screen the display will have: the desktop's work area in device pixels, src/x11/session.ts)
  try {
    const host = await (await import('./window-host')).getWindowHost();
    const size = host.desktopSize();
    const screen = [size.width, size.height, Math.round(96 * (host.scale ?? 1))];
    if (JSON.stringify(made.screen) !== JSON.stringify(screen)) return true;
  } catch { /* no host: the launch decides */ }
  return (await S.snapshotProblem(fs, entry, entry.meta.key)) !== null;
}

/**
 * Start `name` with nothing of it shown, keep its snapshot once it is quiet,
 * and end it. Its processes are killed, not asked to quit: an app that is
 * asked saves its settings, which is what outdated the last snapshot.
 */
async function takeHidden(kernel: Kernel, name: string, signal: AbortSignal, onGone: () => void): Promise<import('./retake').RetakeResult> {
  const t0 = Date.now();
  const { m, app, argv, env, cwd } = await prepare(kernel, name, [], {});
  const plan = await snapshotPlan(kernel, m, name, app, argv, env, false);
  if (!plan || plan.index === null) return { ok: false, never: true, why: 'no snapshot can be taken now' };
  if (plan.stored) return { ok: true, ms: 0, bytes: plan.stored.meta.sizes };
  if (signal.aborted) return { ok: false, cancelled: true, why: String(signal.reason ?? 'cancelled') };
  const { BufferFile } = await import('../kernel/fd');
  const { recordXClient, forgetHidden } = await import('../x11/display');
  const { getXSession } = await import('../x11/session');
  const { server } = await getXSession(0);
  const out = new BufferFile(null);
  const proc = kernel.spawn({ path: app.bin, argv, cwd, env, fds: { 0: new BufferFile(''), 1: out, 2: out } });
  proc.data.openLog = new Set<string>();
  proc.data.openWritten = new Set<string>();
  proc.data.hiddenStart = true;
  const pids = new Set<number>([proc.pid]);
  const { S, key } = plan;
  let cancelled = '';
  const watch = S.snapshotWhenQuiet(kernel, name, proc, recordXClient(proc.pid, plan.index, undefined, true), key, { argv, env, cwd, output: out, hidden: true, cancelled: () => !!cancelled });
  // Ended at once when the person needs the machine: asked to (an app being started, the page hidden),
  // or a key or button pressed in a GUI app. Its processes go now; a snapshot being packed is not kept
  const input0 = server.inputCount;
  const killAll = () => {
    for (const pid of familyPids(kernel, proc.pid)) pids.add(pid);
    for (const pid of [...pids].reverse()) { try { kernel.kill(pid, 9 /* SIGKILL */); } catch { /* gone */ } }
  };
  const gone = async () => {
    await exitOf(kernel, proc).catch(() => undefined);
    // (its X client goes when its socket closes: the next start of the app needs its client number)
    for (let i = 0; i < 100 && server.clients.has(plan.index!); i++) await new Promise((res) => setTimeout(res, 20));
  };
  const end = (why: string) => { if (!cancelled) { cancelled = why; watch.cancel(); killAll(); void gone().then(onGone); } };
  const onAbort = () => end(String(signal.reason ?? 'cancelled'));
  signal.addEventListener('abort', onAbort);
  const onHide = () => { if (typeof document !== 'undefined' && document.visibilityState === 'hidden') end('the page was hidden'); };
  if (typeof document !== 'undefined') document.addEventListener('visibilitychange', onHide);
  const poll = setInterval(() => {
    for (const pid of familyPids(kernel, proc.pid)) pids.add(pid);
    if (server.inputCount !== input0) end('a GUI app was being used');
  }, 100);
  let r: import('./snapshot').TakeResult;
  try {
    r = await watch.done;
  } finally {
    clearInterval(poll);
    signal.removeEventListener('abort', onAbort);
    if (typeof document !== 'undefined') document.removeEventListener('visibilitychange', onHide);
    delete proc.data.openLog; delete proc.data.openWritten;
    killAll();
    await gone();
    for (const pid of pids) forgetHidden(pid);
    onGone();
  }
  if (cancelled) return { ok: false, cancelled: true, why: cancelled };
  if (!r.ok) {
    if (r.never) S.setSkip(name, key, r.why ?? '');
    return { ok: false, never: r.never, why: r.why };
  }
  // The start itself must not have outdated it (an app that writes, each time it starts, something
  // it reads): then a retake after every quit would never give a restore
  const entry = await S.snapshotEntry(name);
  const problem = entry ? await S.snapshotProblem(kernel.fs as FileSystem, entry, key) : 'it was dropped for space';
  if (problem) {
    await S.dropSnapshot(name);
    S.setSkip(name, key, `outdated by its own start: ${problem}`);
    return { ok: false, never: true, why: `outdated by its own start: ${problem}` };
  }
  S.setSkip(name, key, null);
  if (r.meta) noteSnapshotSize(name, r.meta.sizes.image);
  return { ok: true, ms: Date.now() - t0, bytes: r.meta?.sizes };
}

/** The page's retake queue (null where there is none: no document, or not loaded yet) */
function retakes(kernel: Kernel): Queue | null {
  if (queue !== undefined) return queue;
  if (typeof document === 'undefined' || typeof indexedDB === 'undefined') return queue = null;
  queue = null;
  queueLoad ??= (async () => {
    const R = await import('./retake');
    const { isSafeMode } = await import('../safe-mode');
    const { isGuest } = await import('../guest');
    lastInput = Date.now();
    const note = () => { lastInput = Date.now(); };
    for (const ev of ['keydown', 'pointerdown', 'wheel'] as const) window.addEventListener(ev, note, { capture: true, passive: true });
    const launching = () => {
      const d = (globalThis as { __shiroDesktop?: { launches?: { list(): { active: boolean }[] } } }).__shiroDesktop;
      return installing.size > 0 || !!d?.launches?.list().some((l) => l.active);
    };
    const q = new R.RetakeQueue({
      now: () => Date.now(),
      state: () => ({ on: snapshotsOn(), safe: isSafeMode(), guest: isGuest(), hidden: document.visibilityState === 'hidden', launching: launching() }),
      lastInput: () => lastInput,
      // (not on a machine too small for a hidden start of this app: retake.ts retakeFits)
      needs: async (app) => (R.retakeFits((navigator as { deviceMemory?: number }).deviceMemory, lastSnapshotSize(app)) ? retakeNeeded(kernel, app).catch(() => null) : null),
      take: (app, signal, onGone) => takeHidden(kernel, app, signal, onGone),
      log: snapshotLog,
      timer: (cb, ms) => setTimeout(cb, ms),
      idle: (cb) => {
        const ric = (globalThis as { requestIdleCallback?: (cb: () => void, opts?: { timeout: number }) => unknown }).requestIdleCallback;
        if (ric) ric(cb, { timeout: 5000 }); else setTimeout(cb, 0);
      },
    });
    queue = q;
    (globalThis as { __guiRetakes?: Queue }).__guiRetakes = q;
  })().catch(() => { queue = null; });
  return queue;
}

/** The queue, once it is there (launchApp's own callers don't wait for it: a quit's request is made when it is) */
async function retakesReady(kernel: Kernel): Promise<Queue | null> {
  retakes(kernel);
  await queueLoad;
  return queue ?? null;
}

/**
 * Once after the page has loaded (main.ts): the apps started in the last
 * week whose snapshot is gone or no longer good (another build or engine, a
 * changed setting, too old) are taken again when the tab is idle. A tab that
 * started no GUI app this week starts nothing for this, not even the display.
 */
export async function retakeOutdatedSnapshots(kernel: Kernel): Promise<string[]> {
  if (!snapshotsOn() || typeof indexedDB === 'undefined') return [];
  const R = await import('./retake');
  const asked: string[] = [];
  for (const app of recentSnapshotApps(R.RECENT_MS).slice(0, R.BOOT_APPS)) {
    if (!(await mayNeedRetake(kernel, app).catch(() => false))) continue;
    const q = await retakesReady(kernel);
    if (!q) break;
    // (asked as of the page's load: the wait is for the person's input, not for a quit)
    q.request(app, 0);
    asked.push(app);
  }
  return asked;
}
