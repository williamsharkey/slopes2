import type { Command, CommandContext } from './index';

/**
 * Debian mode (docs/DEBIAN.md):
 *   debian install [--base URL] [-v]
 *                                 stream Debian's root filesystem into this machine
 *                                 (-v: each overlay change)
 *   debian status                 what is installed, fetched and overlaid
 *   debian prefetch [PKG...]      fetch packages' files now (default: apt, dpkg, bash, coreutils)
 * and the overlay switch:
 *   shiro-alternatives --list | --display NAME | --set NAME shiro|debian | --auto NAME|all
 */

const PREFETCH_DEFAULT = ['libc6', 'bash', 'coreutils', 'dpkg', 'apt', 'libapt-pkg7.0', 'libstdc++6', 'dash', 'tar', 'gzip', 'sqv', 'debianutils'];

async function enableDebianMode(ctx: CommandContext): Promise<void> {
  const { DEBIAN_ENV } = await import('../debian/rootfs');
  for (const [k, v] of Object.entries(DEBIAN_ENV)) ctx.shell.env[k] ??= v;
  const { enableDebianShadows } = await import('../debian/overlay');
  await enableDebianShadows(ctx.fs, (n) => !!ctx.shell.commands.get(n));
}

export const debianCmd: Command = {
  name: 'debian',
  description: 'Install and manage the streamed Debian system',
  async exec(ctx) {
    const [sub, ...rest] = ctx.args;
    const rootfs = await import('../debian/rootfs');
    const out = (s: string) => { ctx.stdout += s + '\n'; };
    if (sub === 'install' || sub === 'init') {
      const already = await rootfs.installedRootfs(ctx.fs);
      if (already && !rest.includes('--force')) {
        // Make sure this shell is in Debian mode (loader, shadows, env) all the same
        rootfs.attachRootfsLoader(ctx.fs, { [already.id]: already.base });
        await rootfs.writeEngineWorkarounds(ctx.fs);
        await enableDebianMode(ctx);
        out(`Debian ${already.version} is already installed (${already.id}); --force reinstalls the base files.`);
        return 0;
      }
      // Debian grows to hundreds of MB (apt lists, packages): keep it from eviction
      void import('../storage').then(m => m.requestPersistentStorage('debian install', true));
      const bi = rest.indexOf('--base');
      const base = bi >= 0 ? rest[bi + 1] : undefined;
      const r = await rootfs.installRootfs(ctx.fs, { base, progress: (m) => out(m) });
      const { applyDefaults, overlayReport } = await import('../debian/overlay');
      await enableDebianMode(ctx);
      const changed = await applyDefaults(ctx.fs);
      await ctx.fs.sync();
      out(`Installed ${r.entries} paths in ${r.ms} ms; file contents are fetched on first use.`);
      for (const l of overlayReport(changed, rest.includes('-v') || rest.includes('--verbose'))) out(l);
      if (r.moved.length) out(`  moved into Debian's directories: ${r.moved.join(', ')}`);
      out(`Try: apt install <package>`);
      return 0;
    }
    if (sub === 'status' || !sub) {
      const st = await rootfs.installedRootfs(ctx.fs);
      if (!st) {
        out('Debian is not installed. `debian install` streams it in (nothing is downloaded until a file is read).');
        return sub ? 1 : 0;
      }
      const s = rootfs.rootfsStats;
      out(`Debian ${st.version} (${st.suite}, ${st.arch}), snapshot ${st.snapshot}, rootfs ${st.id}`);
      out(`  base: ${st.packages} packages, ${st.entries} paths, ${(st.bytes / 1e6).toFixed(1)} MB (${(st.chunkBytes / 1e6).toFixed(1)} MB compressed in ${st.chunks} chunks)`);
      out(`  installed ${new Date(st.installedAt).toISOString()} from ${st.base}`);
      out(`  this session: ${s.chunksFetched} chunks fetched (${(s.chunkBytesFetched / 1e6).toFixed(1)} MB), ${s.chunksFromCache} from the browser cache, ${s.filesMaterialized} files filled`);
      try {
        const est = await (navigator as any)?.storage?.estimate?.();
        if (est?.usage) out(`  browser storage used: ${(est.usage / 1e6).toFixed(1)} MB of ${(est.quota / 1e6).toFixed(0)} MB`);
      } catch { /* no storage API */ }
      return 0;
    }
    if (sub === 'prefetch') {
      const pkgs = rest.length ? rest : PREFETCH_DEFAULT;
      const paths: string[] = [];
      for (const p of pkgs) {
        const list = await ctx.fs.readFile(`/var/lib/dpkg/info/${p}.list`, 'utf8').catch(() => ctx.fs.readFile(`/var/lib/dpkg/info/${p}:amd64.list`, 'utf8').catch(() => '')) as string;
        for (const f of list.split('\n')) if (f) paths.push(f);
      }
      const files: string[] = [];
      for (const p of paths) { try { if ((await ctx.fs.lstat(p)).type === 'file') files.push(p); } catch { /* excluded */ } }
      const t = Date.now();
      const n = await rootfs.prefetchPaths(ctx.fs, files);
      out(`prefetched ${n} files of ${pkgs.length} packages in ${Date.now() - t} ms`);
      return 0;
    }
    ctx.stderr += `usage: debian install [--base URL] [-v] | status | prefetch [PKG...]\n`;
    return 2;
  },
};

export const shiroAlternativesCmd: Command = {
  name: 'tabcomputer-alternatives',
  description: "Choose tabcomputer's or Debian's implementation of a program",
  async exec(ctx) {
    const ov = await import('../debian/overlay');
    const a = ctx.args;
    const out = (s: string) => { ctx.stdout += s + '\n'; };
    // Without Debian every program is tabcomputer's: the table only means something once it is installed
    const { ROOTFS_STATE } = await import('../debian/rootfs');
    const debianSystem = await ctx.fs.exists(ROOTFS_STATE).catch(() => false);
    const describe = (st: Awaited<ReturnType<typeof ov.programState>>) => {
      const name = st.path;
      const ours = `tabcomputer (${st.policy?.command ?? name.slice(name.lastIndexOf('/') + 1)})`;
      if (!debianSystem) return `${name}\t${ours}`;
      const who = st.current === 'shiro' ? ours : 'debian';
      const mode = st.manual ? 'manual' : 'auto';
      const dflt = st.policy ? `, default ${st.policy.default === 'shiro' ? 'tabcomputer' : st.policy.default}` : '';
      const inst = st.debianInstalled ? '' : ' [Debian package not installed]';
      return `${name}\t${who}\t(${mode}${dflt})${inst}`;
    };
    try {
      if (!a.length || a[0] === '--list' || a[0] === '--get-selections') {
        if (!debianSystem) out('Debian is not installed: every program below is tabcomputer\'s. `debian install` adds Debian\'s, then this chooses per program.');
        const divs = await ov.readDiversions(ctx.fs);
        const paths = new Set(Object.keys(ov.POLICY));
        for (const d of divs) if (d.by === ':' && d.to === d.from + '.debian') paths.add(d.from);
        for (const p of [...paths].sort()) out(describe(await ov.programState(ctx.fs, p, divs)));
        return 0;
      }
      if (a[0] === '--display' || a[0] === '--query') {
        const p = ov.overlayPath(a[1] ?? '');
        if (!p) throw new Error('--display needs a name');
        const st = await ov.programState(ctx.fs, p);
        out(describe(st));
        if (st.policy?.why) out(`  ${st.policy.why}`);
        if (st.diversion) out(`  dpkg: diversion of ${st.diversion.from} to ${st.diversion.to} by ${st.diversion.by === ':' ? 'local' : st.diversion.by}`);
        return 0;
      }
      if (a[0] === '--set') {
        const p = ov.overlayPath(a[1] ?? '');
        const side = a[2] === 'tabcomputer' ? 'shiro' : a[2]; // 'shiro' is the old name, still accepted
        if (!p || (side !== 'shiro' && side !== 'debian')) throw new Error('usage: --set NAME tabcomputer|debian');
        if (side === 'shiro' && !ov.POLICY[p] && !ctx.shell.commands.get(p.slice(p.lastIndexOf('/') + 1))) throw new Error(`tabcomputer has no ${p.slice(p.lastIndexOf('/') + 1)}`);
        out(await ov.setSide(ctx.fs, p, side, { manual: true }));
        return 0;
      }
      if (a[0] === '--auto') {
        if (a[1] === 'all' || a[1] === '--new') {
          for (const c of await ov.applyDefaults(ctx.fs)) out(c);
          return 0;
        }
        const p = ov.overlayPath(a[1] ?? '');
        if (!p || !ov.POLICY[p]) throw new Error(`no default policy for ${a[1]}`);
        const choices = JSON.parse(await ctx.fs.readFile('/var/lib/shiro/alternatives.json', 'utf8').catch(() => '{}') as string);
        delete choices[p];
        await ctx.fs.writeFile('/var/lib/shiro/alternatives.json', JSON.stringify(choices, null, 2) + '\n');
        const changed = await ov.applyDefaults(ctx.fs, [p]);
        out(changed.length ? changed.join('\n') : `${p}: ${ov.POLICY[p].default} (auto)`);
        return 0;
      }
      ctx.stderr += 'usage: tabcomputer-alternatives --list | --display NAME | --set NAME tabcomputer|debian | --auto NAME|all\n';
      return 2;
    } catch (e: any) {
      ctx.stderr += `tabcomputer-alternatives: ${e?.message ?? e}\n`;
      return 1;
    }
  },
};

/** dpkg-preconfigure that skips the work under DEBIAN_FRONTEND=noninteractive (src/debian/preconfigure.ts). */
export const shiroPreconfigureCmd: Command = {
  name: 'shiro-dpkg-preconfigure',
  description: 'dpkg-preconfigure, a no-op under DEBIAN_FRONTEND=noninteractive',
  // Run from Shiro's shell (the stub's interpreter as a builtin): args are [script, ...its args]
  async exec(ctx) {
    const [script = '/usr/sbin/dpkg-preconfigure', ...args] = ctx.args;
    if (ctx.env.DEBIAN_FRONTEND === 'noninteractive') return 0;
    const q = (a: string) => `'${a.replace(/'/g, `'\\''`)}'`;
    return ctx.shell.fork().executeWithStdin([script + '.debian', ...args].map(q).join(' '), ctx.stdin,
      (t) => { ctx.stdout += t; }, (t) => { ctx.stderr += t; });
  },
  async program(proc, kernel) {
    const { preconfigureProgram } = await import('../debian/preconfigure');
    return preconfigureProgram(proc, kernel);
  },
};

/** apt and apt-get with recovery from an install that stopped part-way (src/debian/apt-guard.ts). */
export const shiroAptCmd: Command = {
  name: 'shiro-apt',
  description: "Debian's apt, recovering an interrupted dpkg first",
  // Run from Shiro's shell (the stub's interpreter as a builtin): args are [script, ...its args]
  async exec(ctx) {
    const [script = '/usr/bin/apt-get', ...args] = ctx.args;
    const q = (a: string) => `'${a.replace(/'/g, `'\\''`)}'`;
    let printed = '';
    const out = (t: string) => { printed += t; if (ctx.streamStdout) ctx.streamStdout(t); else ctx.stdout += t; };
    const err = (t: string) => { printed += t; if (ctx.streamStderr) ctx.streamStderr(t); else ctx.stderr += t; };
    const { aptGuard, aptWantsRoot } = await import('../debian/apt-guard');
    // One person uses this machine: install, remove, update and upgrade run as
    // root without `sudo`, as `apt` does before Debian mode (#133)
    const asRoot = (ctx.shell.uid ?? 1000) !== 0 && aptWantsRoot(args);
    const sh = () => {
      const child = ctx.shell.fork();
      if (asRoot) {
        child.uid = 0;
        // (as sudo: dpkg looks for ldconfig and start-stop-daemon on PATH)
        Object.assign(child.env, {
          USER: 'root', LOGNAME: 'root', HOME: '/root',
          PATH: '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin' + (child.env.PATH ? ':' + child.env.PATH : ''),
        });
      }
      return child;
    };
    // `apt install NAME...` and nothing else: the layer of that set, when the
    // server has it or builds it (src/debian/package-sets.ts). Seconds instead
    // of apt's minutes under the emulator; apt does it when there is no layer.
    if ((asRoot || (ctx.shell.uid ?? 1000) === 0) && ctx.env.TABCOMPUTER_APT_LAYERS !== '0') {
      const sets = await import('../debian/package-sets');
      const names = sets.plainInstall(args);
      const missing = names ? await sets.missingPackages(ctx.fs, names) : [];
      if (names && missing.length) {
        const abort = ctx.shell.abortController ?? ctx.shell.inheritedAbort;
        const r = await sets.installPackageSet(ctx.fs, missing, {
          progress: (line) => err(line + '\n'), signal: abort?.signal,
          afterApply: async () => { await sets.afterLayer(ctx.fs, (n) => !!ctx.shell.commands.get(n)); },
        });
        if (r.ok) {
          const had = names.filter((n) => !missing.includes(n));
          if (had.length) out(`${had.join(', ')} ${had.length > 1 ? 'were' : 'was'} already installed.\n`);
          await ctx.fs.sync();
          return 0;
        }
        if (r.reason === 'stopped') return 130;
        err(`tabcomputer: ${sets.fallbackSentence(missing, r)}\n`);
      }
    }
    return aptGuard({
      script, args, uid: asRoot ? 0 : ctx.shell.uid ?? 1000, fs: ctx.fs as any,
      // argv[0] can't be set from the shell; apt and apt-get don't look at it
      // the caller's stdin goes to apt itself, not to the recovery runs
      run: (path, argv) => sh().executeWithStdin([path, ...argv.slice(1)].map(q).join(' '),
        path === script + '.debian' ? ctx.stdin : '', out, err),
      say: err,
      output: () => printed,
      // Ctrl-C or a timeout's abort: the shell stopped waiting on this builtin
      stopped: () => !!(ctx.shell.abortController ?? ctx.shell.inheritedAbort)?.signal.aborted,
    });
  },
  async program(proc, kernel) {
    const { aptGuardProgram } = await import('../debian/apt-guard');
    return aptGuardProgram(proc, kernel);
  },
};

/** apt's `store` method (decompress + hash downloaded indexes) run natively (src/debian/apt-store.ts). */
export const shiroAptStoreCmd: Command = {
  name: 'shiro-apt-store',
  description: "apt's store method (index decompression), run natively",
  async exec(ctx) {
    ctx.stderr += 'shiro-apt-store: apt runs this as /usr/lib/apt/methods/store; it speaks apt\'s method protocol on stdin/stdout\n';
    return 100;
  },
  async program(proc, kernel) {
    const { aptStoreProgram } = await import('../debian/apt-store');
    return aptStoreProgram(proc, kernel);
  },
};

/** apt's http/https transport (src/debian/apt-method.ts); apt runs it through the stub its method path holds. */
export const shiroAptMethodCmd: Command = {
  name: 'shiro-apt-method',
  description: "apt transport that fetches from the page's Debian mirror",
  async exec(ctx) {
    ctx.stderr += 'shiro-apt-method: apt runs this as /usr/lib/apt/methods/http; it speaks apt\'s method protocol on stdin/stdout\n';
    return 100;
  },
  async program(proc, kernel) {
    const { aptMethodProgram } = await import('../debian/apt-method');
    return aptMethodProgram(proc, kernel);
  },
};
