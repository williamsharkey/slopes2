/**
 * Barrel export: all Unix commands (formerly fluffycoreutils).
 * These are native Shiro Command implementations for standard Unix utilities.
 */

import type { Command } from './index';
import { lazyCommand } from '../utils/lazy-command';

import { alias } from './alias';
import { arrayHelper } from './array';
import { base64 } from './base64';
import { basename } from './basename';
import { bc } from './bc';
import { breakCmd } from './break';
import { caseCmd, esac } from './case';
import { cat } from './cat';
import { chmod } from './chmod';
import { chown } from './chown';
import { clear } from './clear';
import { column } from './column';
import { comm } from './comm';
import { continueCmd } from './continue';
import { cp } from './cp';
import { cut } from './cut';
import { declare, local, readonly, unset } from './local';
import { df } from './df';
import { dirname } from './dirname';
import { doCmd, done, until, whileCmd } from './while';
import { du } from './du';
import { echo } from './echo';
import { elif, elseCmd, fi, ifCmd, then } from './if';
import { env } from './env';
import { evalCmd } from './eval';
import { exit } from './exit';
import { expand } from './expand';
import { expr } from './expr';
import { exportCmd } from './export';
import { false as falseCmd } from './false';
import { forCmd, inCmd } from './for';
import { functionCmd } from './function';
import { file } from './file';
import { fmt } from './fmt';
import { fold } from './fold';
import { free } from './free';
import { getopts } from './getopts';
import { hash } from './hash';
import { head } from './head';
import { heredoc } from './heredoc';
import { hexdump } from './hexdump';
import { id } from './id';
import { install } from './install';
import { join } from './join';
import { less } from './less';
import { letCmd, arithmeticExpansion } from './let';
import { ls } from './ls';
import { make } from './make';
import { md5sum } from './md5sum';
import { mkdir } from './mkdir';
import { mv } from './mv';
import { nl } from './nl';
import { nohup } from './nohup';
import { paste } from './paste';
import { pkgConfig } from './pkg-config';
import { pr } from './pr';
import { printenv } from './printenv';
import { printf } from './printf';
import { processSubstitution } from './process-substitution';
import { pwd } from './pwd';
import { read } from './read';
import { readlink } from './readlink';
import { realpath } from './realpath';
import { returnCmd } from './return';
import { seq } from './seq';
import { set } from './set';
import { sha256sum } from './sha256sum';
import { sha1sumCmd, sha384sumCmd, sha512sumCmd } from './checksum';
import { shift } from './shift';
import { shrine } from './shrine';
import { sleep } from './sleep';
import { sort } from './sort';
import { stat } from './stat';
import { strings } from './strings';
import { tail } from './tail';
import { tee } from './tee';
import { test } from './posix-test';
import { time } from './time';
import { timeout } from './timeout';
import { ttyCmd, setsidCmd, scriptCmd } from './session';
import { touch } from './touch';
import { mkfifo } from './mkfifo';
import { tr } from './tr';
import { kill, trap } from './trap';
import { true as trueCmd, colon } from './true';
import { tsort } from './tsort';
import { type } from './type';
import { ulimit } from './ulimit';
import { umask } from './umask';
import { unalias } from './unalias';
import { unexpand } from './unexpand';
import { uniq } from './uniq';
import { uptime } from './uptime';
import { watch } from './watch';
import { wc } from './wc';
import { which } from './which';
import { whoami } from './whoami';
import { xargs } from './xargs';
import { yes } from './yes';
import { revCmd, tacCmd, shufCmd, cmpCmd } from './text-utils';
import { ddCmd } from './dd';
import { xxdCmd } from './xxd';
import { dcCmd } from './dc';
import { splitCmd } from './split';
import { truncateCmd } from './truncate';
import { factorCmd } from './factor';
import { cksumCmd } from './cksum';
import { sumCmd } from './sum';
import { base32Cmd } from './base32';
import { numfmtCmd } from './numfmt';
import { csplitCmd } from './csplit';
import { niceCmd, wCmd, whoCmd, usersCmd, lsofCmd } from './system-info';
import { dos2unixCmd, unix2dosCmd } from './line-endings';

// Large, less frequent commands load on first use (kept out of the boot bundle)
const awk = lazyCommand('awk', 'Pattern scanning and processing language', () => import('./awk').then(m => m.awk));
const date = lazyCommand('date', 'Display date and time', () => import('./date').then(m => m.date));
const findCmd = lazyCommand('find', 'Search for files in a directory hierarchy', () => import('./find').then(m => m.findCmd));
const od = lazyCommand('od', 'Dump files in octal and other formats', () => import('./od').then(m => m.od));
const patch = lazyCommand('patch', 'Apply a diff file to an original', () => import('./patch').then(m => m.patch));
const tar = lazyCommand('tar', 'Archive utility (GNU tar format)', () => import('./tar').then(m => m.tar));

/** All Unix commands as an array for registration. */
export const unixCommands: Command[] = [
  alias, arrayHelper, awk, base64, basename, bc, breakCmd,
  caseCmd, esac, cat, chmod, chown, clear, column, comm, continueCmd, cp, cut,
  date, declare, local, readonly, unset, df, dirname, doCmd, done, until, whileCmd,
  du, echo, elif, elseCmd, fi, ifCmd, then, env, evalCmd, exit, expand, expr,
  exportCmd, falseCmd, findCmd, forCmd, inCmd, functionCmd, file, fmt, fold, free,
  getopts, hash, head, heredoc, hexdump, id, install, join, kill, less, letCmd,
  ls, make, md5sum, mkdir, mv, nl, nohup, od, paste, patch, pkgConfig, pr,
  printenv, printf, processSubstitution, pwd, read, readlink, realpath, returnCmd,
  seq, set, sha256sum, sha1sumCmd, sha384sumCmd, sha512sumCmd, shift, shrine, sleep, sort, stat, strings, tail, tar, tee,
  test, time, timeout, touch, mkfifo, tr, trap, trueCmd, colon, tsort, type, ulimit, umask,
  unalias, unexpand, uniq, uptime, watch, wc, which, whoami, xargs, yes,
  revCmd, tacCmd, shufCmd, cmpCmd, ddCmd, xxdCmd, dcCmd, splitCmd, truncateCmd,
  factorCmd, cksumCmd, sumCmd, base32Cmd, numfmtCmd, csplitCmd,
  niceCmd, wCmd, whoCmd, usersCmd, lsofCmd, dos2unixCmd, unix2dosCmd,
  ttyCmd, setsidCmd, scriptCmd,
];

/** Arithmetic expansion helper for $(( )) syntax */
export { arithmeticExpansion };
