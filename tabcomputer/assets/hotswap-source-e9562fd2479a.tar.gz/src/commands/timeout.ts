import type { Command } from './index';
import { quoteArgsForShell, terminalForCommand } from '../shell';
import { signalNumber, signalName, TIMEOUT_EXPIRED_EVENT } from '../kernel/signals';

/** Seconds after the signal before SIGKILL when there is no -k (GNU timeout waits forever) */
const DEFAULT_KILL_AFTER = 5;

/**
 * timeout [OPTION] DURATION COMMAND [ARG]...
 * Runs COMMAND in a forked shell; if it is still running after DURATION it is
 * aborted (loops and pipelines stop at their next check) and timeout exits 124.
 */
export const timeout: Command = {
  name: "timeout",
  description: "Run a command with a time limit",
  async exec(ctx) {
    // Options come before DURATION; everything after it belongs to COMMAND
    let preserveStatus = false;
    let verbose = false;
    let signal = 'TERM';
    let killAfter: string | undefined;
    let i = 0;
    for (; i < ctx.args.length; i++) {
      const a = ctx.args[i];
      if (a === '--') { i++; break; }
      if (!a.startsWith('-') || a === '-') break;
      if (a === '--preserve-status') preserveStatus = true;
      else if (a === '-v' || a === '--verbose') verbose = true;
      else if (a === '--foreground') { /* (COMMAND keeps the tty; the signal still goes to its group) */ }
      else if (a === '-s' || a === '--signal' || a === '-k' || a === '--kill-after') {
        if (a === '-s' || a === '--signal') signal = ctx.args[i + 1] ?? signal;
        else killAfter = ctx.args[i + 1];
        i++;
      } else if (/^--(signal|kill-after)=/.test(a) || /^-[sk]./.test(a)) {
        if (/^(-s|--signal=)/.test(a)) signal = a.replace(/^(-s|--signal=)/, '');
        else killAfter = a.replace(/^(-k|--kill-after=)/, '');
      } else {
        ctx.stderr += `timeout: invalid option -- '${a}'\n`;
        return 125;
      }
    }

    const durationStr = ctx.args[i];
    const command = ctx.args.slice(i + 1);
    if (durationStr === undefined) {
      ctx.stderr += "timeout: missing operand\n";
      return 125;
    }
    const duration = parseDuration(durationStr);
    if (duration === null) {
      ctx.stderr += `timeout: invalid time interval '${durationStr}'\n`;
      return 125;
    }
    if (command.length === 0) {
      ctx.stderr += "timeout: missing operand\n";
      return 125;
    }
    const sig = signalNumber(signal);
    if (sig === undefined || sig === 0) {
      ctx.stderr += `timeout: ${signal}: invalid signal\n`;
      return 125;
    }
    const kill = killAfter === undefined ? null : parseDuration(killAfter);
    if (kill === null && killAfter !== undefined) {
      ctx.stderr += `timeout: invalid time interval '${killAfter}'\n`;
      return 125;
    }

    const child = ctx.shell.fork();
    // The child's own abort (the timeout's), chained to the shell's (Ctrl-C):
    // aborting it must not abort the shell that runs timeout
    // COMMAND's kernel programs get a process group of their own (shell-kernel.ts), as GNU
    // timeout's do: its signal goes to that group, not to a group shared with whoever runs timeout
    const own = Object.assign(new AbortController(), { ownProcessGroup: true });
    const outer = ctx.shell.abortController ?? child.inheritedAbort;
    // (with the outer abort's reason: `kill -TERM $!` of a job running timeout sends
    // COMMAND SIGTERM, not the SIGINT a reasonless abort means, #63)
    if (outer?.signal.aborted) own.abort(outer.signal.reason);
    else outer?.signal.addEventListener('abort', () => own.abort(outer.signal.reason), { once: true });
    child.inheritedAbort = own;
    // Piped or redirected: programs keep the tty for input, their stdout comes back here
    if (ctx.terminal) child.setTerminal(terminalForCommand(ctx.terminal, ctx) as any);
    child.cwd = ctx.cwd;
    // A shell running as a kernel process (an agent's `sh -c`) gives COMMAND its
    // live fd 0: reading ctx.stdin would wait for that pipe to close first
    const live = !!ctx.liveStdin && !!ctx.shell.kernelStdio;
    // (into ctx as it comes: if the shell stops waiting for timeout (Ctrl-C), what
    // COMMAND wrote before is still timeout's output)
    const sink = (s: string) => { ctx.stdout += s.replace(/\r\n/g, '\n'); };
    const errSink = (s: string) => { ctx.stderr += s.replace(/\r\n/g, '\n'); };
    let timer: ReturnType<typeof setTimeout> | undefined;
    let expired: Promise<'timeout'> | null = null;
    const arm = () => {
      expired ??= duration === 0 ? null : new Promise<'timeout'>((resolve) => {
        timer = (globalThis as any).setTimeout(() => resolve('timeout'), duration * 1000);
      });
      return expired;
    };
    // Input still to come (`< fifo`): read inside the time allowed, as COMMAND would
    // (ctx.stdin only off the live path: reading it there waits for the pipe to close)
    let input: string | undefined;
    if (!live && ctx.readFifoStdin) {
      const late = Symbol('timeout');
      const limit = arm();
      const got = await (limit ? Promise.race([ctx.readFifoStdin(), limit.then(() => late)]) : ctx.readFifoStdin());
      if (typeof got !== 'string') {
        if (verbose) ctx.stderr += `timeout: sending signal ${signalName(sig)} to command '${command[0]}'\n`;
        return preserveStatus ? 128 + sig : 124;
      }
      input = got;
    }
    const run = live
      ? child.execute(quoteArgsForShell(command), ctx.streamStdout ?? sink, ctx.streamStderr ?? errSink, false, undefined, true)
      // (`> log`: COMMAND's output goes into the file as it's written, #53)
      : child.executeWithStdin(quoteArgsForShell(command), input ?? (ctx.stdin || ''), ctx.streamStdout ?? sink, ctx.streamStderr ?? errSink);
    const limit = arm();
    const result = await (limit ? Promise.race([run, limit]) : run);
    (globalThis as any).clearTimeout(timer);

    if (result === 'timeout') {
      // The signal goes to COMMAND's programs (a TUI in raw mode ignores the
      // SIGINT a plain abort sends), and timeout waits for COMMAND to end, so
      // the terminal is the shell's again when it returns. -k sends SIGKILL
      // after its delay; without it, one a program ignores still gets
      // SIGKILL after DEFAULT_KILL_AFTER rather than holding the tty forever.
      if (verbose) ctx.stderr += `timeout: sending signal ${signalName(sig)} to command '${command[0]}'\n`;
      // (an AbortError still, for fetch and the like; shell-kernel.ts reads signal and killAfter)
      const reason = Object.assign(new DOMException('The operation was aborted.', 'AbortError'), { signal: sig, killAfter: (kill ?? DEFAULT_KILL_AFTER) * 1000 });
      // Aborted already (the shell around timeout went away, #53): abort() would do
      // nothing, so the signal goes to COMMAND's job through the expiry event
      if (own.signal.aborted) own.signal.dispatchEvent(new CustomEvent(TIMEOUT_EXPIRED_EVENT, { detail: reason }));
      else own.abort(reason);
      const status = await run;
      if (preserveStatus) return status === 130 ? 128 + sig : status; // (130: an in-page command the abort stopped)
      return 124;
    }
    return result;
  },
};

function parseDuration(str: string): number | null {
  const match = str.match(/^(\d+(?:\.\d+)?|\.\d+)(s|m|h|d)?$/);
  if (!match) return null;
  const value = parseFloat(match[1]);
  const mult = { s: 1, m: 60, h: 3600, d: 86400 }[match[2] || 's']!;
  return value * mult;
}
