import { Command, CommandContext } from './index';

/**
 * python/python3: Python interpreter via Pyodide (WebAssembly CPython)
 *
 * The \`pyodide\` command (and python/python3 under the "pyodide" python shim).
 * On a cross-origin isolated page it runs as a kernel process in a Worker
 * (src/pyodide-worker/): the tab's own files, a terminal's stdin, ^C. The
 * code below that is the older Pyodide in the page (a copy of the working
 * directory in, nothing copied back), kept for a page that can't block.
 *
 * Usage:
 *   python3 -c "print('hello')"     # one-liner
 *   python3 script.py                # run file
 *   python3                          # interactive REPL
 *   pip install numpy                # install packages via micropip
 */

import { pyodideIndexURL } from '../python/pyodide-dist';

let pyodide: any = null;
let loadPromise: Promise<any> | null = null;

async function ensurePyodide(ctx: CommandContext): Promise<any> {
  if (pyodide) return pyodide;
  if (loadPromise) return loadPromise;

  loadPromise = (async () => {
    ctx.stdout += 'Loading Python (Pyodide)... ';

    // Load Pyodide loader script via importScripts-like eval
    const base = await pyodideIndexURL();
    const loaderUrl = `${base}pyodide.mjs`;
    const mod = await import(/* @vite-ignore */ loaderUrl);
    const loadPyodide = mod.loadPyodide || mod.default?.loadPyodide;
    if (!loadPyodide) throw new Error('Failed to load Pyodide loader');

    pyodide = await loadPyodide({
      indexURL: base,
    });

    ctx.stdout += 'done.\n';
    return pyodide;
  })();

  try {
    return await loadPromise;
  } catch (err) {
    loadPromise = null;
    throw err;
  }
}

/** Mount Shiro FS files into Pyodide's virtual FS */
async function syncToNative(py: any, ctx: CommandContext, dir: string) {
  try {
    // Create /shiro mount point in Pyodide's FS
    try { py.FS.mkdir('/shiro'); } catch { /* exists */ }

    // Copy files from Shiro FS into Pyodide's in-memory FS
    const entries = await ctx.fs.readdir(dir);
    for (const entry of entries) {
      if (entry === '.git') continue;
      const fullPath = dir === '/' ? '/' + entry : dir + '/' + entry;
      const pyPath = '/shiro' + fullPath;
      try {
        const stat = await ctx.fs.stat(fullPath);
        if (stat.isDirectory()) {
          try { py.FS.mkdir(pyPath); } catch { /* exists */ }
          await syncToNative(py, ctx, fullPath);
        } else if (stat.isFile()) { // (not a named pipe: reading one waits for a writer)
          const content = await ctx.fs.readFile(fullPath);
          const dir = pyPath.split('/').slice(0, -1).join('/');
          try { py.FS.mkdirTree(dir); } catch { /* exists */ }
          if (content instanceof Uint8Array) {
            py.FS.writeFile(pyPath, content);
          } else {
            py.FS.writeFile(pyPath, content as string);
          }
        }
      } catch { /* skip unreadable files */ }
    }
  } catch { /* non-fatal */ }
}

/**
 * Fetch the packages of the Pyodide distribution that `code` imports (numpy,
 * pandas, matplotlib, ...: compiled for Pyodide, which the WASI python can't
 * load), so `pyodide -c 'import numpy'` and scripts run without a separate
 * install step. Nothing is fetched for modules already there.
 */
async function loadImports(py: any, code: string): Promise<void> {
  try { await py.loadPackagesFromImports?.(code, { messageCallback: () => {}, errorCallback: () => {} }); } catch { /* the import reports it */ }
}

/**
 * Run `code` after `setup` with sys.stdout/stderr captured, appending what it
 * printed to the command's output (also when it raises) and restoring them.
 * Exit status 1 when it raises (the traceback goes to stderr), else 0:
 * warnings on stderr are not failures.
 */
function runCaptured(py: any, ctx: CommandContext, setup: string, code: string): number {
  let failure = '';
  py.runPython(`import sys, io
_shiro_out = io.StringIO()
_shiro_err = io.StringIO()
sys.stdout = _shiro_out
sys.stderr = _shiro_err`);
  try {
    py.runPython(setup);
    py.runPython(code);
  } catch (err: any) {
    failure = String(err?.message ?? err).replace(/\n?$/, '\n');
  }
  ctx.stdout += py.runPython('_shiro_out.getvalue()');
  ctx.stderr += py.runPython('_shiro_err.getvalue()');
  py.runPython('sys.stdout = sys.__stdout__; sys.stderr = sys.__stderr__');
  ctx.stderr += failure;
  return failure ? 1 : 0;
}

export const pythonCmd: Command = {
  name: 'python',
  description: 'Python interpreter (Pyodide)',
  async exec(ctx: CommandContext) {
    // -m venv / pip / ensurepip are the CPython package's (wheels install into
    // its site-packages): fetch it once, then run the command with it
    const { pythonFrontend } = await import('../pkg-manager');
    if (pythonFrontend(ctx.args) && ctx.shell) {
      const { quoteArgsForShell } = await import('../shell');
      const out = (s: string) => { ctx.stdout += s.replace(/\r\n/g, '\n'); };
      const err = (s: string) => { ctx.stderr += s.replace(/\r\n/g, '\n'); };
      err('python3 -m venv and -m pip need the CPython package: pkg install python3\n');
      const code = await ctx.shell.execute('pkg install python3 >/dev/null', out, err);
      if (code !== 0) return code;
      return ctx.shell.execute(`/usr/bin/python3 ${quoteArgsForShell(ctx.args)}`, out, err);
    }
    // Where the page can block, Pyodide is a kernel process in a Worker with the tab's files
    // (src/pyodide-worker/); what follows is the old Pyodide in the page, for a page that can't
    const { pyodideWorkerMode } = await import('../pyodide-worker/boot');
    if (pyodideWorkerMode()) {
      const { routePython } = await import('../python/route');
      const route = await routePython(ctx.fs, ['--pyodide', ...ctx.args], { cwd: ctx.cwd, env: ctx.env, canPyodide: true, stdinIsTTY: !!ctx.terminal && !ctx.stdin });
      if (route.engine === 'pyodide') return (await import('../pyodide-worker/host')).runPyodide(ctx, route.run, 'pyodide');
      ctx.stdout += `Python ${(await import('../python/pyodide-dist')).PYODIDE_PYTHON} (Pyodide ${(await import('../python/pyodide-dist')).PYODIDE_VERSION})\n`;
      return 0;
    }
    let py: any;
    try {
      py = await ensurePyodide(ctx);
    } catch (err: any) {
      ctx.stderr += `error: failed to load Pyodide: ${err.message}\n`;
      return 1;
    }

    const args = ctx.args;

    // python3 -c "code"
    const cIdx = args.indexOf('-c');
    if (cIdx !== -1 && args[cIdx + 1]) {
      const code = args[cIdx + 1];
      await loadImports(py, code);
      return runCaptured(py, ctx, `import sys; sys.argv = ['-c', *${JSON.stringify(args.slice(cIdx + 2))}]`, code);
    }

    // python3 script.py [args...]
    const scriptArg = args.find(a => !a.startsWith('-'));
    if (scriptArg) {
      const scriptPath = ctx.fs.resolvePath(scriptArg, ctx.cwd);
      let content: string;
      try {
        content = await ctx.fs.readFile(scriptPath, 'utf8') as string;
      } catch {
        ctx.stderr += `python: can't open file '${scriptArg}': [Errno 2] No such file or directory\n`;
        return 2;
      }

      // Sync CWD to Pyodide FS
      await syncToNative(py, ctx, ctx.cwd);
      await loadImports(py, content);

      return runCaptured(py, ctx, `import sys, os
sys.argv = ${JSON.stringify([scriptArg, ...args.slice(args.indexOf(scriptArg) + 1)])}
os.chdir('/shiro${ctx.cwd}')`, content);
    }

    // Interactive REPL
    if (!ctx.terminal) {
      ctx.stderr += 'python: interactive mode requires a terminal\n';
      return 1;
    }

    const term = ctx.terminal;
    const version = py.runPython('import sys; sys.version');
    term.writeOutput(`Python ${version} (Pyodide)\r\nType "exit()" to quit.\r\n`);

    return new Promise<number>((resolve) => {
      let line = '';
      const prompt = '>>> ';
      term.writeOutput(prompt);

      term.enterRawMode((key: string) => {
        // The terminal's raw mode hands over key names ('Enter', 'Ctrl+C', ...)
        if (key === 'Enter' || key === '\r' || key === '\n') {
          term.writeOutput('\r\n');
          const input = line.trim();
          line = '';

          if (input === 'exit()' || input === 'quit()') {
            term.exitRawMode();
            resolve(0);
            return;
          }

          if (input) {
            try {
              py.runPython(`
import sys, io
_shiro_out = io.StringIO()
_shiro_err = io.StringIO()
sys.stdout = _shiro_out
sys.stderr = _shiro_err
`);
              // Use exec for statements, eval for expressions
              try {
                const result = py.runPython(`
try:
    _r = eval(${JSON.stringify(input)})
    if _r is not None:
        print(repr(_r))
except SyntaxError:
    exec(${JSON.stringify(input)})
`);
              } catch {}
              const stdout = py.runPython('_shiro_out.getvalue()');
              const stderr = py.runPython('_shiro_err.getvalue()');
              py.runPython('sys.stdout = sys.__stdout__; sys.stderr = sys.__stderr__');
              if (stdout) term.writeOutput(stdout.replace(/\n/g, '\r\n'));
              if (stderr) term.writeOutput(stderr.replace(/\n/g, '\r\n'));
            } catch (err: any) {
              term.writeOutput(err.message.replace(/\n/g, '\r\n') + '\r\n');
            }
          }

          term.writeOutput(prompt);
        } else if (key === 'Backspace' || key === '\x7f' || key === '\b') {
          if (line.length > 0) {
            line = line.slice(0, -1);
            term.writeOutput('\b \b');
          }
        } else if (key === 'Ctrl+C' || key === '\x03') {
          // Ctrl+C
          term.writeOutput('^C\r\n');
          line = '';
          term.writeOutput(prompt);
        } else if (key === 'Ctrl+D' || key === '\x04') {
          // Ctrl+D
          term.writeOutput('\r\n');
          term.exitRawMode();
          resolve(0);
        } else if (key.length === 1 && key.charCodeAt(0) >= 32) {
          line += key;
          term.writeOutput(key);
        }
      });
    });
  },
};

export const python3Cmd: Command = {
  ...pythonCmd,
  name: 'python3',
  description: 'Python 3 interpreter (Pyodide)',
};

export const pipCmd: Command = {
  name: 'pip',
  description: 'Python package manager',
  async exec(ctx: CommandContext) {
    // With the WASI python package, pip installs real wheels from PyPI
    const pip = await import('./pip');
    if (await pip.havePython(ctx.fs)) return pip.pipMain(ctx, ctx.args, await pip.pipTarget(ctx));

    const args = ctx.args;
    if (args[0] !== 'install' || !args[1]) {
      ctx.stderr += 'usage: pip install <package> [<package>...]\n';
      return 1;
    }

    let py: any;
    try {
      py = await ensurePyodide(ctx);
    } catch (err: any) {
      ctx.stderr += `error: failed to load Pyodide: ${err.message}\n`;
      return 1;
    }

    const packages = args.slice(1).filter(a => !a.startsWith('-'));
    try {
      await py.loadPackage('micropip');
      const micropip = py.pyimport('micropip');
      for (const pkg of packages) {
        ctx.stdout += `Installing ${pkg}...\n`;
        await micropip.install(pkg);
        ctx.stdout += `Successfully installed ${pkg}\n`;
      }
      return 0;
    } catch (err: any) {
      ctx.stderr += `pip: error installing packages: ${err.message}\n`;
      return 1;
    }
  },
};
