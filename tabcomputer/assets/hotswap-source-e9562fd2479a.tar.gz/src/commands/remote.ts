import { Command, CommandContext } from './index';
import { Shell } from '../shell';
import { createRemotePanel, type RemotePanel, type LogType } from '../remote-panel';
import { getShiroOrigin } from '../utils/shiro-origin';
import {
  RelayChannel, newRelayInfo, newRemoteSecret, formatRemoteCode, parseRemoteCode, registerOffer, fetchAnswer,
  RemoteProtocolError, type RelayInfo, type RemoteCode,
} from '../remote-relay';
import { workerRelay } from '../watchdog';

// LocalStorage key for persisting remote session code across page reloads
const REMOTE_CODE_KEY = 'tabcomputer-remote-code';
/** '0': don't offer the HTTPS relay (`remote start --no-relay`) */
const REMOTE_RELAY_KEY = 'tabcomputer-remote-relay';

const relayAllowed = () => { try { return localStorage.getItem(REMOTE_RELAY_KEY) !== '0'; } catch { return true; } };

// Word lists for generating memorable codes
// ~200 adjectives × ~200 nouns × 64^4 syllables = ~46 bits of entropy
const ADJECTIVES = [
  'tiny', 'fluffy', 'cozy', 'swift', 'bright', 'calm', 'happy', 'lazy', 'brave', 'clever',
  'gentle', 'fierce', 'quiet', 'loud', 'warm', 'cool', 'soft', 'bold', 'shy', 'wild',
  'sleepy', 'bouncy', 'fuzzy', 'crisp', 'fresh', 'golden', 'silver', 'ruby', 'jade', 'coral',
  'misty', 'sunny', 'stormy', 'snowy', 'rainy', 'windy', 'dusty', 'foggy', 'dewy', 'frosty',
  'sweet', 'spicy', 'salty', 'tangy', 'zesty', 'mellow', 'rich', 'light', 'dark', 'pale',
  'vivid', 'pastel', 'neon', 'matte', 'glossy', 'rustic', 'sleek', 'plush', 'silky', 'velvet',
  'cosmic', 'lunar', 'solar', 'stellar', 'astral', 'mystic', 'magic', 'dreamy', 'hazy', 'ethereal',
  'peppy', 'perky', 'chipper', 'jolly', 'merry', 'gleeful', 'blissful', 'serene', 'tranquil', 'peaceful',
  'rapid', 'speedy', 'hasty', 'nimble', 'agile', 'spry', 'lithe', 'graceful', 'elegant', 'dainty',
  'chunky', 'pudgy', 'plump', 'round', 'lanky', 'slender', 'petite', 'grand', 'mighty', 'humble',
  'ancient', 'modern', 'retro', 'vintage', 'classic', 'novel', 'young', 'elder', 'primal', 'neo',
  'azure', 'amber', 'crimson', 'emerald', 'violet', 'indigo', 'scarlet', 'teal', 'cyan', 'magenta',
  'lucky', 'plucky', 'gutsy', 'feisty', 'sassy', 'zany', 'quirky', 'funky', 'groovy', 'jazzy',
  'pixel', 'cyber', 'quantum', 'atomic', 'nano', 'mega', 'ultra', 'hyper', 'super', 'mini',
  'royal', 'noble', 'regal', 'fancy', 'posh', 'swanky', 'ritzy', 'snazzy', 'dapper', 'natty',
  'rusty', 'mossy', 'leafy', 'woody', 'earthy', 'sandy', 'rocky', 'stony', 'pebbly', 'grassy',
  'wavy', 'curly', 'spiky', 'bumpy', 'smooth', 'rough', 'jagged', 'sharp', 'blunt', 'pointy',
  'striped', 'spotted', 'dotted', 'checked', 'plain', 'ornate', 'simple', 'complex', 'basic', 'prime',
  'alpha', 'beta', 'gamma', 'delta', 'omega', 'zero', 'null', 'void', 'flux', 'core',
  'nifty', 'spiffy', 'dandy', 'keen', 'neat', 'rad', 'epic', 'ace', 'top', 'pro',
];

const NOUNS = [
  'cat', 'dog', 'fox', 'wolf', 'bear', 'deer', 'frog', 'toad', 'fish', 'bird',
  'owl', 'hawk', 'crow', 'swan', 'duck', 'goose', 'dove', 'wren', 'lark', 'finch',
  'bee', 'ant', 'moth', 'wasp', 'fly', 'bug', 'snail', 'slug', 'worm', 'spider',
  'tree', 'leaf', 'root', 'bark', 'seed', 'bloom', 'petal', 'stem', 'vine', 'moss',
  'rock', 'stone', 'gem', 'crystal', 'pearl', 'shell', 'sand', 'dust', 'clay', 'mud',
  'cloud', 'rain', 'snow', 'frost', 'hail', 'fog', 'mist', 'dew', 'storm', 'wind',
  'sun', 'moon', 'star', 'comet', 'nova', 'nebula', 'quasar', 'pulsar', 'void', 'cosmos',
  'flame', 'spark', 'ember', 'ash', 'smoke', 'steam', 'vapor', 'ice', 'blaze', 'glow',
  'wave', 'tide', 'surf', 'foam', 'reef', 'coral', 'kelp', 'algae', 'plankton', 'drift',
  'peak', 'cliff', 'cave', 'gorge', 'canyon', 'valley', 'hill', 'dune', 'mesa', 'ridge',
  'brook', 'creek', 'stream', 'river', 'lake', 'pond', 'pool', 'spring', 'well', 'falls',
  'path', 'trail', 'road', 'lane', 'bridge', 'gate', 'door', 'wall', 'tower', 'spire',
  'coin', 'key', 'lock', 'box', 'chest', 'bag', 'pouch', 'sack', 'crate', 'barrel',
  'cup', 'bowl', 'plate', 'pot', 'pan', 'jar', 'vase', 'jug', 'flask', 'bottle',
  'book', 'page', 'scroll', 'map', 'chart', 'note', 'letter', 'card', 'badge', 'seal',
  'sword', 'shield', 'helm', 'bow', 'arrow', 'spear', 'axe', 'hammer', 'staff', 'wand',
  'ring', 'chain', 'crown', 'orb', 'prism', 'cube', 'sphere', 'cone', 'pyramid', 'disc',
  'pixel', 'byte', 'bit', 'node', 'link', 'port', 'socket', 'packet', 'frame', 'block',
  'core', 'chip', 'wire', 'fuse', 'coil', 'grid', 'mesh', 'web', 'net', 'array',
  'pulse', 'beam', 'ray', 'flash', 'arc', 'bolt', 'surge', 'loop', 'cycle', 'wave',
];

// Japanese-ish syllables for the compound word (64 options = 6 bits each, 4 syllables = 24 bits)
const SYLLABLES = [
  'ka', 'ki', 'ku', 'ke', 'ko', 'sa', 'shi', 'su', 'se', 'so',
  'ta', 'chi', 'tsu', 'te', 'to', 'na', 'ni', 'nu', 'ne', 'no',
  'ha', 'hi', 'fu', 'he', 'ho', 'ma', 'mi', 'mu', 'me', 'mo',
  'ya', 'yu', 'yo', 'ra', 'ri', 'ru', 're', 'ro', 'wa', 'wo',
  'ba', 'bi', 'bu', 'be', 'bo', 'pa', 'pi', 'pu', 'pe', 'po',
  'za', 'ji', 'zu', 'ze', 'zo', 'da', 'de', 'do', 'ga', 'gi',
  'gu', 'ge', 'go', 'sha',
];

/**
 * Generate a remote code: `<id>#<secret>` (src/remote-relay.ts).
 * The id is adjective-noun-syllables ("fluffy-cloud-shimutako"): the
 * rendezvous, which the signaling server is given. The secret (130 random
 * bits) is never sent anywhere: it seals the offer, the answer and every
 * relayed message, so the server cannot read or join the session.
 */
function generateCode(): { full: string; display: string } {
  const bytes = new Uint16Array(6);
  crypto.getRandomValues(bytes);

  const adj = ADJECTIVES[bytes[0] % ADJECTIVES.length];
  const noun = NOUNS[bytes[1] % NOUNS.length];
  const syl1 = SYLLABLES[bytes[2] % SYLLABLES.length];
  const syl2 = SYLLABLES[bytes[3] % SYLLABLES.length];
  const syl3 = SYLLABLES[bytes[4] % SYLLABLES.length];
  const syl4 = SYLLABLES[bytes[5] % SYLLABLES.length];

  const compound = syl1 + syl2 + syl3 + syl4;
  return {
    full: formatRemoteCode(`${adj}-${noun}-${compound}`, newRemoteSecret()),
    display: `${adj}-${noun}`, // Safe to show on screen
  };
}

// Signaling server URL — same origin, server.mjs handles /offer and /answer routes
const SIGNALING_URL = getShiroOrigin();

/** What the session talks over: a WebRTC data channel or the HTTPS relay */
interface RemoteChannel {
  readyState: string;
  send(data: string): void;
  close(): void;
  onopen: ((ev?: any) => any) | null;
  onclose: ((ev?: any) => any) | null;
  onmessage: ((ev: any) => any) | null;
}

interface RemoteSession {
  /** The whole code, `<id>#<secret>`: stays in this tab (and the clipboard) */
  code: string;
  /** Its parts: the id is what the signaling server is given */
  parts: RemoteCode;
  /** Why signaling failed, for `remote status` */
  error?: string;
  displayCode: string;
  pc: RTCPeerConnection;
  dc: RemoteChannel | null;
  /** The relay mailbox this session's offer names (null: not offered) */
  relay: RelayInfo | null;
  transport?: 'webrtc' | 'relay';
  status: 'connecting' | 'waiting' | 'connected' | 'error';
  shadowShell: Shell | null;
  panel: RemotePanel | null;
  activityBuffer: Array<{ type: LogType; message: string }>;
  panelOpen: boolean;
}

// Store session on window for global access
declare global {
  interface Window {
    __shiroRemoteSession?: RemoteSession;
    __tabcomputer?: any;
  }
}

/**
 * Create a shadow shell for headless command execution.
 * Shares the same filesystem and commands as the main shell.
 */
function createShadowShell(): Shell {
  const { fs, commands } = window.__tabcomputer;
  return new Shell(fs, commands);
}

/**
 * Log activity to the panel if open, or buffer it for later.
 * When buffering, flips the HUD activity dot to green.
 */
function logActivity(session: RemoteSession, type: LogType, message: string) {
  if (session.panelOpen && session.panel) {
    session.panel.log(type, message);
  } else {
    session.activityBuffer.push({ type, message });
    // Notify HUD of activity
    const terminal = (window as any).__tabcomputer?.terminal;
    terminal?.updateHudRemoteActivity?.(true);
  }
}

/**
 * Open (or focus) the remote panel. Called from HUD link click.
 * Creates the panel if needed, replays buffered activity, resets the HUD dot.
 */
export function openRemotePanel(): void {
  const session = window.__shiroRemoteSession;
  if (!session) return;

  if (session.panelOpen && session.panel) {
    // Panel already open — just bring to front
    session.panel.element.style.zIndex = '2147483647';
    return;
  }

  // Create panel
  const panel = createRemotePanel(session.displayCode, `remote \u2194 ${session.displayCode}`);
  session.panel = panel;
  session.panelOpen = true;

  // Set status based on current session state
  panel.setStatus(session.status === 'connected' ? 'connected' : session.status === 'error' ? 'disconnected' : 'connecting');

  // Replay buffered activity
  for (const entry of session.activityBuffer) {
    panel.log(entry.type, entry.message);
  }
  session.activityBuffer = [];

  // Reset HUD activity dot
  const terminal = (window as any).__tabcomputer?.terminal;
  terminal?.updateHudRemoteActivity?.(false);

  // Wire panel input → data channel
  panel.onUserMessage = (text: string) => {
    if (session.dc?.readyState === 'open') {
      session.dc.send(JSON.stringify({ type: 'user_message', message: text }));
      panel.log('user', text);
    }
  };

  // Wire close button to mark panel as closed (so future activity buffers again)
  const origClose = panel.close.bind(panel);
  panel.close = () => {
    session.panelOpen = false;
    session.panel = null;
    origClose();
  };
  // Also intercept the close button click on the DOM element
  const closeBtn = panel.element.querySelector('[style*="ff5f57"]') as HTMLElement | null;
  if (closeBtn) {
    const origClick = closeBtn.onclick;
    closeBtn.onclick = (e) => {
      session.panelOpen = false;
      session.panel = null;
      if (origClick) origClick.call(closeBtn, e);
    };
    const origTouch = closeBtn.ontouchend;
    closeBtn.ontouchend = (e) => {
      session.panelOpen = false;
      session.panel = null;
      if (origTouch) origTouch.call(closeBtn, e);
    };
  }
}

/**
 * Handle incoming commands from the remote peer.
 * Uses shadow shell for exec (headless, no terminal corruption).
 */
async function handleRemoteCommand(session: RemoteSession, message: string): Promise<string> {
  try {
    const cmd = JSON.parse(message);
    const requestId = cmd.requestId; // Echo back for request/response matching

    switch (cmd.type) {
      case 'ping':
        return JSON.stringify({ type: 'pong', ts: Date.now(), requestId });

      case 'hello': {
        // MCP client identifies itself — update panel title
        const name = cmd.name || 'remote';
        if (session.panel) session.panel.setTitle(`${name} \u2194 ${session.displayCode}`);
        logActivity(session, 'info', `${name} connected`);
        return JSON.stringify({ type: 'hello_ack', requestId });
      }

      case 'exec': {
        const shell = session.shadowShell;
        if (!shell) {
          return JSON.stringify({ type: 'error', error: 'Shell not available', requestId });
        }
        logActivity(session, 'exec', `$ ${cmd.command}`);

        let stdout = '';
        let stderr = '';
        const exitCode = await shell.execute(
          cmd.command,
          (s: string) => { stdout += s; },
          (s: string) => { stderr += s; },
          false, undefined, true, // skipHistory — remote commands shouldn't pollute user history
        );

        if (stdout) logActivity(session, 'info', stdout.trimEnd());
        if (stderr) logActivity(session, 'error', stderr.trimEnd());

        return JSON.stringify({ type: 'exec_result', stdout, stderr, exitCode, requestId });
      }

      case 'read': {
        const fs = window.__tabcomputer?.fs;
        if (!fs) {
          return JSON.stringify({ type: 'error', error: 'Filesystem not available', requestId });
        }
        logActivity(session, 'read', cmd.path);
        const content = await fs.readFile(cmd.path);
        const base64 = btoa(String.fromCharCode(...content));
        return JSON.stringify({ type: 'read_result', path: cmd.path, content: base64, requestId });
      }

      case 'write': {
        const fs = window.__tabcomputer?.fs;
        if (!fs) {
          return JSON.stringify({ type: 'error', error: 'Filesystem not available', requestId });
        }
        logActivity(session, 'write', cmd.path);
        const content = Uint8Array.from(atob(cmd.content), c => c.charCodeAt(0));
        await fs.writeFile(cmd.path, content);
        return JSON.stringify({ type: 'write_result', path: cmd.path, ok: true, requestId });
      }

      case 'list': {
        const fs = window.__tabcomputer?.fs;
        if (!fs) {
          return JSON.stringify({ type: 'error', error: 'Filesystem not available', requestId });
        }
        logActivity(session, 'read', `ls ${cmd.path}`);
        const entries = await fs.readdir(cmd.path);
        return JSON.stringify({ type: 'list_result', path: cmd.path, entries, requestId });
      }

      case 'console': {
        // Bounded, filterable query of the console log captured since boot
        // (or the previous page load with previous: true). Defaults cap the reply
        // at 100 entries / 64 KB so a noisy page can't flood the peer.
        const { queryConsole } = await import('../console-log');
        const result = queryConsole({
          grep: cmd.grep, level: cmd.level, since: cmd.since, previous: !!cmd.previous,
          limit: Math.min(cmd.limit ?? 100, 5000),
          maxBytes: Math.min(cmd.maxBytes ?? 65536, 200000),
        });
        return JSON.stringify({ type: 'console_result', ...result, requestId });
      }

      case 'abort': {
        // Like Ctrl-C in every terminal (the watchdog worker handles this one
        // itself when it hosts the relay, so it works while the page is frozen)
        const { abortForeground } = await import('../watchdog');
        const hit = abortForeground('remote request');
        return JSON.stringify({ type: 'abort_result', requested: true, hit, requestId });
      }

      case 'diag': {
        // Why is the page slow or frozen: event-loop lag, long tasks, heap,
        // commands in flight, the watchdog's events (or the previous load's
        // with previous: true), processes, unsaved filesystem writes. Cheap and
        // synchronous, so it answers as soon as the page does.
        const { diagnostics } = await import('../watchdog');
        const d = diagnostics({ limit: Math.min(cmd.limit ?? 200, 1500), since: cmd.since, kind: cmd.kind, previous: !!cmd.previous });
        const tc = window.__tabcomputer as any;
        let procs: string[] = [];
        try { procs = tc?.processTable?.list().slice(0, 200).map((p: any) => `${p.pid} ${p.status} ${String(p.command).slice(0, 80)}`) ?? []; } catch { /* source threw */ }
        const pendingWrites = tc?.fs?.pendingWrites;
        // Kernel processes: syscalls in progress, sockets, pipes (kernel: false skips)
        const kernel = cmd.kernel === false ? undefined
          : (await import('../kernel-diag')).kernelDiagnostics({ grep: cmd.procGrep, limit: cmd.procLimit });
        return JSON.stringify({ type: 'diag_result', ...d, procs, pendingWrites, kernel, requestId });
      }

      case 'profile': {
        // Live profile (src/live-profile.ts): start a capture, mark, stop, read
        // it in slices ({part, offset}), so a reply stays small
        const lp = await import('../live-profile');
        const action = String(cmd.action || 'status');
        if (action === 'start') {
          logActivity(session, 'info', `profile start ${cmd.label ?? ''}`.trim());
          const meta = await lp.startProfile({ durationMs: cmd.durationMs, sampleMs: cmd.sampleMs, procGrep: cmd.procGrep, label: cmd.label });
          return JSON.stringify({ type: 'profile_result', meta, requestId });
        }
        if (action === 'mark') return JSON.stringify({ type: 'profile_result', ok: lp.markProfile(String(cmd.text ?? '')), requestId });
        if (action === 'read') {
          const slice = await lp.readProfile({ part: cmd.part, offset: cmd.offset, limit: cmd.limit, maxBytes: cmd.maxBytes });
          return JSON.stringify({ type: 'profile_result', ...(slice ?? { meta: null }), requestId });
        }
        const meta = action === 'stop' ? lp.stopProfile() : lp.profileStatus();
        const full = meta ? await lp.fullProfile() : null;
        return JSON.stringify({ type: 'profile_result', meta, summary: full ? lp.summarizeProfile(full) : [], requestId });
      }

      case 'eval': {
        logActivity(session, 'eval', cmd.code);
        const result = await eval(cmd.code);
        const resultStr = String(result);
        logActivity(session, 'info', resultStr);
        return JSON.stringify({ type: 'eval_result', result: resultStr, requestId });
      }

      case 'terminal_start': {
        // Start an interactive terminal session
        const shell = session.shadowShell;
        if (!shell) {
          return JSON.stringify({ type: 'error', error: 'Shell not available', requestId });
        }
        logActivity(session, 'info', `Terminal session started (${cmd.cols || 80}x${cmd.rows || 24})`);

        // Create a forked shell for the terminal session
        const termShell = shell.fork();
        (session as any)._termShell = termShell;
        (session as any)._termActive = true;

        // Send initial prompt
        const cwd = termShell.cwd;
        const home = termShell.env.HOME || '/home/user';
        const display = cwd.startsWith(home) ? '~' + cwd.slice(home.length) : cwd;
        const prompt = `${display}$ `;
        if (session.dc) {
          session.dc.send(JSON.stringify({ type: 'terminal_output', data: prompt, requestId }));
        }
        return JSON.stringify({ type: 'terminal_started', requestId });
      }

      case 'terminal_input': {
        // Forward keystroke to the terminal shell
        const termShell = (session as any)._termShell as Shell | undefined;
        const termActive = (session as any)._termActive as boolean;
        if (!termShell || !termActive) {
          return JSON.stringify({ type: 'error', error: 'No active terminal session', requestId });
        }

        const data = cmd.data as string;

        // Handle Enter — execute command
        if (data === '\r' || data === '\n') {
          const inputBuf = (session as any)._termInputBuf || '';
          (session as any)._termInputBuf = '';

          if (session.dc) {
            session.dc.send(JSON.stringify({ type: 'terminal_output', data: '\r\n' }));
          }

          const command = inputBuf.trim();
          if (command === 'exit') {
            (session as any)._termActive = false;
            if (session.dc) {
              session.dc.send(JSON.stringify({ type: 'terminal_end', requestId }));
            }
            return JSON.stringify({ type: 'terminal_end', requestId });
          }

          if (command) {
            logActivity(session, 'exec', `[term] $ ${command}`);
            let output = '';
            try {
              await termShell.execute(command, (s: string) => { output += s; });
            } catch (e: any) {
              output = `Error: ${e.message}\n`;
            }
            // Convert \n to \r\n for terminal display
            const converted = output.replace(/\n/g, '\r\n');
            if (converted && session.dc) {
              session.dc.send(JSON.stringify({ type: 'terminal_output', data: converted }));
            }
          }

          // Send new prompt
          const cwd2 = termShell.cwd;
          const home2 = termShell.env.HOME || '/home/user';
          const display2 = cwd2.startsWith(home2) ? '~' + cwd2.slice(home2.length) : cwd2;
          const prompt2 = `${display2}$ `;
          if (session.dc) {
            session.dc.send(JSON.stringify({ type: 'terminal_output', data: prompt2 }));
          }
          return ''; // Already sent responses via DC
        }

        // Handle backspace
        if (data === '\x7f' || data === '\b') {
          const buf = (session as any)._termInputBuf || '';
          if (buf.length > 0) {
            (session as any)._termInputBuf = buf.slice(0, -1);
            if (session.dc) {
              session.dc.send(JSON.stringify({ type: 'terminal_output', data: '\b \b' }));
            }
          }
          return '';
        }

        // Handle Ctrl+C
        if (data === '\x03') {
          (session as any)._termInputBuf = '';
          if (session.dc) {
            session.dc.send(JSON.stringify({ type: 'terminal_output', data: '^C\r\n' }));
            const cwd3 = termShell.cwd;
            const home3 = termShell.env.HOME || '/home/user';
            const display3 = cwd3.startsWith(home3) ? '~' + cwd3.slice(home3.length) : cwd3;
            session.dc.send(JSON.stringify({ type: 'terminal_output', data: `${display3}$ ` }));
          }
          return '';
        }

        // Handle Ctrl+D — end session
        if (data === '\x04') {
          (session as any)._termActive = false;
          if (session.dc) {
            session.dc.send(JSON.stringify({ type: 'terminal_end', requestId }));
          }
          return JSON.stringify({ type: 'terminal_end', requestId });
        }

        // Regular character — echo and buffer
        if (data.length === 1 && data.charCodeAt(0) >= 32) {
          (session as any)._termInputBuf = ((session as any)._termInputBuf || '') + data;
          if (session.dc) {
            session.dc.send(JSON.stringify({ type: 'terminal_output', data }));
          }
        }
        return '';
      }

      case 'terminal_end': {
        (session as any)._termActive = false;
        (session as any)._termShell = null;
        (session as any)._termInputBuf = '';
        logActivity(session, 'info', 'Terminal session ended');
        return JSON.stringify({ type: 'terminal_end_ack', requestId });
      }

      default:
        return JSON.stringify({ type: 'error', error: `Unknown command type: ${cmd.type}`, requestId });
    }
  } catch (err: any) {
    logActivity(session, 'error', err.message || String(err));
    // Note: requestId may not be available if JSON parsing failed
    return JSON.stringify({ type: 'error', error: err.message || String(err) });
  }
}

/**
 * Wire up a session with shadow shell, panel, and data channel handlers.
 */
function wireSession(session: RemoteSession, dc: RemoteChannel) {
  session.dc = dc;
  let closeFired = false;

  dc.onopen = () => {
    session.status = 'connected';
    if (session.panel) session.panel.setStatus('connected');
    logActivity(session, 'info', 'Peer connected');
    console.log('[remote] Peer connected');
  };

  dc.onclose = () => {
    // Guard against re-entrant/duplicate onclose fires
    if (closeFired) return;
    closeFired = true;
    // `remote start`/`remote stop` replaced or ended this session on purpose; its
    // close fires later, and re-registering here would kill the new session and
    // bring the old code back.
    if (window.__shiroRemoteSession !== session) return;

    console.log('[remote] Peer disconnected');
    if (session.panel) session.panel.setStatus('disconnected');
    logActivity(session, 'info', 'Peer disconnected — waiting for reconnect...');
    const savedCode = session.code;
    // Keep panel alive across reconnect
    const savedPanel = session.panel;
    const savedPanelOpen = session.panelOpen;
    const savedBuffer = session.activityBuffer;
    const savedShell = session.shadowShell;
    // Null out dc before cleanup to prevent re-entrant close
    session.dc = null;
    cleanupSession(true); // keepPanel=true
    // Re-register with same code so MCP can reconnect
    setTimeout(() => {
      if (!window.__shiroRemoteSession) {
        console.log('[remote] Re-registering for reconnection...');
        startRemoteWithCode(savedCode, undefined, savedPanel, savedShell, savedPanelOpen, savedBuffer);
      }
    }, 1000);
  };

  dc.onmessage = async (event) => {
    const response = await handleRemoteCommand(session, event.data);
    if (dc.readyState === 'open') {
      dc.send(response);
    }
  };
}

/**
 * Start a remote session - create WebRTC offer and register with signaling server
 */
async function startRemote(ctx: CommandContext): Promise<number> {
  // Auto-cleanup existing session if any
  if (window.__shiroRemoteSession) {
    ctx.stdout += 'Cleaning up existing session...\n';
    // Deactivate old panel (dim it, keep log visible) instead of closing
    window.__shiroRemoteSession.panel?.deactivate();
    window.__shiroRemoteSession.panel = null; // detach so cleanupSession won't close it
    cleanupSession();
    localStorage.removeItem(REMOTE_CODE_KEY);
    // Clear HUD if terminal available
    if (ctx.terminal) {
      (ctx.terminal as any).updateHudRemoteCode?.(null);
    }
  }

  const { full: code, display: displayCode } = generateCode();

  // Copy to clipboard immediately (before async work breaks user gesture chain)
  let clipboardCopied = false;
  try {
    await navigator.clipboard.writeText(code);
    clipboardCopied = true;
  } catch {
    // Will report failure below
  }

  // Output code IMMEDIATELY — don't wait for ICE/signaling
  if (clipboardCopied) {
    ctx.stdout += `\x1b[32mConnection code copied to clipboard!\x1b[0m\n`;
  } else {
    ctx.stdout += `\x1b[33mCouldn't copy to clipboard. Code: ${code}\x1b[0m\n`;
  }
  ctx.stdout += `Display code: \x1b[93m${displayCode}\x1b[0m\n`;
  ctx.stdout += `Run \x1b[36mremote stop\x1b[0m to end the session.\n`;

  // Update HUD to show the code (if visible)
  if (ctx.terminal) {
    (ctx.terminal as any).updateHudRemoteCode?.(displayCode);
  }

  // Create shadow shell (panel is created lazily on demand)
  const shadowShell = createShadowShell();

  // Create peer connection
  const pc = new RTCPeerConnection({
    iceServers: [
      { urls: 'stun:stun.l.google.com:19302' },
      { urls: 'stun:stun1.l.google.com:19302' },
    ],
  });

  const session: RemoteSession = {
    code,
    parts: parseRemoteCode(code),
    displayCode,
    pc,
    dc: null,
    relay: relayAllowed() ? newRelayInfo() : null,
    status: 'connecting',
    shadowShell,
    panel: null,
    activityBuffer: [{ type: 'info', message: 'Waiting for connection...' }],
    panelOpen: false,
  };

  window.__shiroRemoteSession = session;

  // Persist code immediately so auto-reconnect works after page reload
  localStorage.setItem(REMOTE_CODE_KEY, code);

  // Do WebRTC setup + signaling in the background (don't block command output)
  setupSignaling(session).catch((err) => {
    console.error(`[remote] Signaling failed: ${err.message}`);
    logActivity(session, 'error', `Signaling failed: ${err.message}`);
    session.status = 'error';
    session.error = err.message;
    // An older server would need the code itself: say so where the user is looking
    if (err instanceof RemoteProtocolError) (ctx.terminal as any)?.term?.writeln?.(`\r\n\x1b[31mremote: ${err.message}\x1b[0m`);
    if (session.panel) session.panel.setStatus('disconnected');
  });

  return 0;
}

/**
 * Setup WebRTC offer, gather ICE candidates, and register with signaling server.
 * Runs in the background so `remote start` returns instantly.
 */
async function setupSignaling(session: RemoteSession): Promise<void> {
  const pc = session.pc;

  // Create data channel and wire up handlers
  const dc = pc.createDataChannel('shiro-remote', { ordered: true });
  wireSession(session, dc);

  // Gather ICE candidates
  const iceCandidates: RTCIceCandidate[] = [];
  pc.onicecandidate = (event) => {
    if (event.candidate) {
      iceCandidates.push(event.candidate);
    }
  };

  // Create offer
  const offer = await pc.createOffer();
  await pc.setLocalDescription(offer);

  // Wait for ICE gathering to complete
  await new Promise<void>((resolve) => {
    if (pc.iceGatheringState === 'complete') {
      resolve();
    } else {
      pc.onicegatheringstatechange = () => {
        if (pc.iceGatheringState === 'complete') {
          resolve();
        }
      };
      // Timeout after 5 seconds
      setTimeout(resolve, 5000);
    }
  });

  // Register with the signaling server: the id and a sealed offer, never the secret
  await registerOffer(SIGNALING_URL, session.parts, { offer: pc.localDescription, candidates: iceCandidates, relay: session.relay });

  session.status = 'waiting';

  // Start polling for answer
  pollForAnswer(session);
}

/**
 * The peer answered with {type: 'relay'}: it can't do WebRTC (no UDP), so the
 * session talks over the server's HTTPS mailbox instead (src/remote-relay.ts).
 * The data channel is dropped quietly (its onclose would re-register the code).
 */
function switchToRelay(session: RemoteSession, v: 1 | 2 = 1) {
  const old = session.dc;
  if (old) { old.onopen = old.onclose = old.onmessage = null; old.close(); }
  session.pc.close();
  console.log('[remote] Peer asked for the HTTPS relay');
  logActivity(session, 'info', 'Peer connecting over the HTTPS relay');
  session.transport = 'relay';
  // In the watchdog worker when it runs: `diag` then answers while this page is frozen
  // Keyed by the secret part and this offer's salt (never the whole code)
  const opts = { base: SIGNALING_URL, info: { ...session.relay!, v: Math.min(v, session.relay!.v) as 1 | 2 }, secret: session.parts.secret };
  const relay = workerRelay(opts) ?? new RelayChannel({ ...opts, as: 'tab', log: (m) => console.warn(`[remote] ${m}`) });
  wireSession(session, relay);
}

/**
 * Poll signaling server for an answer from a connecting peer
 */
async function pollForAnswer(session: RemoteSession) {
  const maxAttempts = 60; // 5 minutes at 5-second intervals
  let attempts = 0;

  // The signaling server forgets offers after 5 minutes or on a restart; a
  // session still waiting for a peer registers again under the same code so the
  // code the user shared keeps working until `remote stop`.
  const renew = (why: string) => {
    if (window.__shiroRemoteSession !== session) return;
    console.log(`[remote] ${why}; registering the code again`);
    const { code, panel, shadowShell, panelOpen, activityBuffer } = session;
    session.panel = null; // keep the panel across the re-registration
    cleanupSession(true);
    startRemoteWithCode(code, undefined, panel, shadowShell, panelOpen, activityBuffer);
  };

  const poll = async () => {
    if (window.__shiroRemoteSession !== session || session.status === 'connected') {
      return;
    }

    attempts++;
    if (attempts > maxAttempts) {
      renew('Offer expired');
      return;
    }

    try {
      const data = await fetchAnswer(SIGNALING_URL, session.parts);
      if ('expired' in data) {
        renew('Signaling server forgot the offer');
        return;
      } else if ('waiting' in data) {
        // No answer yet, continue polling
      } else if ('bad' in data) {
        // From someone with the id but not the secret (or a mistyped code): take answers again
        console.warn(`[remote] Ignored an answer: ${data.bad}`);
        logActivity(session, 'error', `Ignored an answer: ${data.bad}`);
        renew('An answer did not open with this code');
        return;
      } else if (data.answer?.type === 'relay') {
        if (session.relay) {
          // The envelope version both sides speak
          switchToRelay(session, data.answer.v === 2 ? 2 : 1);
          return;
        }
        // A peer asked for the relay this session didn't offer: keep waiting
      } else if (data.answer) {
        await session.pc.setRemoteDescription(data.answer);

        // Add ICE candidates from peer
        for (const candidate of data.candidates as RTCIceCandidateInit[]) {
          await session.pc.addIceCandidate(candidate);
        }

        console.log('[remote] Received answer, establishing connection...');
        // ICE failed (a peer without UDP, or NATs that won't meet): take
        // answers again, so the peer can retry or ask for the relay
        session.pc.onconnectionstatechange = () => {
          if (session.pc.connectionState === 'failed' && session.status !== 'connected') renew('WebRTC connection failed');
        };
        return;
      }
    } catch (e) {
      if (e instanceof RemoteProtocolError) {
        // The server changed under this session (a rolling deploy): stop, don't downgrade
        console.error(`[remote] ${e.message}`);
        logActivity(session, 'error', e.message);
        session.status = 'error';
        session.error = e.message;
        return;
      }
      // Network error - continue polling (transient failure)
    }

    // Continue polling
    setTimeout(poll, 5000);
  };

  poll();
}

/**
 * Stop the current remote session
 */
function stopRemote(ctx: CommandContext): number {
  if (!window.__shiroRemoteSession) {
    ctx.stdout += 'No active remote session.\n';
    return 1;
  }

  cleanupSession();

  // Clear persisted code so it won't auto-reconnect
  localStorage.removeItem(REMOTE_CODE_KEY);

  ctx.stdout += 'Remote session stopped.\n';

  // Clear the remote code and activity dot from HUD (if visible)
  if (ctx.terminal) {
    (ctx.terminal as any).updateHudRemoteCode?.(null);
    (ctx.terminal as any).updateHudRemoteActivity?.(false);
  }

  return 0;
}

/**
 * Clean up the remote session.
 * @param keepPanel If true, don't close the panel (used during reconnect)
 */
function cleanupSession(keepPanel = false) {
  const session = window.__shiroRemoteSession;
  if (session) {
    if (session.dc) {
      session.dc.close();
    }
    session.pc.close();
    if (!keepPanel && session.panel) {
      session.panel.close();
    }
    session.shadowShell = null;
    delete window.__shiroRemoteSession;
  }
}

/**
 * Show status of current remote session
 */
function statusRemote(ctx: CommandContext): number {
  const session = window.__shiroRemoteSession;
  if (!session) {
    ctx.stdout += 'No active remote session.\n';
    ctx.stdout += 'Run \x1b[36mremote start\x1b[0m to begin.\n';
    return 0;
  }

  ctx.stdout += `Remote session status: \x1b[93m${session.status}\x1b[0m\n`;
  if (session.error) ctx.stdout += `\x1b[31m${session.error}\x1b[0m\n`;
  ctx.stdout += `Display code: \x1b[93m${session.displayCode}\x1b[0m\n`;

  if (session.dc) {
    ctx.stdout += `Data channel: \x1b[93m${session.dc.readyState}\x1b[0m\n`;
  }

  if (session.transport === 'relay') {
    ctx.stdout += `Connection: \x1b[93mHTTPS relay\x1b[0m\n`;
  } else {
    const pcState = session.pc.connectionState;
    ctx.stdout += `Connection: \x1b[93m${pcState}\x1b[0m\n`;
  }
  ctx.stdout += `HTTPS relay: ${session.relay ? 'offered' : 'off (remote start --relay to offer it)'}\n`;

  return 0;
}

export const remoteCmd: Command = {
  name: 'remote',
  description: 'Start/stop remote development session for external Claude Code access',
  async exec(ctx) {
    const subcommand = ctx.args[0] || 'status';

    switch (subcommand) {
      case 'start':
        // The relay is offered unless turned off; the choice is remembered
        if (ctx.args.includes('--no-relay')) localStorage.setItem(REMOTE_RELAY_KEY, '0');
        else if (ctx.args.includes('--relay')) localStorage.removeItem(REMOTE_RELAY_KEY);
        return startRemote(ctx);
      case 'stop':
        return stopRemote(ctx);
      case 'status':
        return statusRemote(ctx);
      default:
        ctx.stderr += `Unknown subcommand: ${subcommand}\n`;
        ctx.stdout += 'Usage: remote [start [--relay|--no-relay]|stop|status]\n';
        return 1;
    }
  },
};

/**
 * Check for persisted remote code and return it if present.
 * Used by main.ts to auto-reconnect after page reload.
 */
export function getPersistedRemoteCode(): string | null {
  return localStorage.getItem(REMOTE_CODE_KEY);
}

/**
 * Start a remote session with a specific code (for auto-reconnect).
 * Silently starts without command-line output.
 * Optionally reuses an existing panel and shell (for reconnect after disconnect).
 */
const RECONNECT_RETRIES = 8; // about 2 minutes in total
const reconnectAttempts = new Map<string, number>();

export async function startRemoteWithCode(
  code: string,
  terminal?: any,
  existingPanel?: RemotePanel | null,
  existingShell?: Shell | null,
  existingPanelOpen?: boolean,
  existingBuffer?: Array<{ type: LogType; message: string }>,
): Promise<boolean> {
  if (window.__shiroRemoteSession) {
    console.log('[remote] Session already active');
    return true;
  }

  let parts: RemoteCode;
  try { parts = parseRemoteCode(code); } catch (e: any) {
    // A code saved by a build from before protocol 3: the server could read those. Not registered again.
    console.warn(`[remote] The saved remote code was dropped: ${e.message}`);
    if (localStorage.getItem(REMOTE_CODE_KEY) === code) localStorage.removeItem(REMOTE_CODE_KEY);
    terminal?.updateHudRemoteCode?.(null);
    return false;
  }
  const displayCode = parts.id.split('-').slice(0, 2).join('-');
  console.log(`[remote] Auto-reconnecting with code: ${displayCode}`);

  // Create or reuse shadow shell (panel is lazy — only created on demand)
  const shadowShell = existingShell || createShadowShell();
  const panel = existingPanel || null;
  const panelOpen = existingPanel ? (existingPanelOpen ?? true) : false;
  const activityBuffer = existingBuffer || [];
  if (panel) {
    panel.setStatus('connecting');
  }
  if (!existingPanel) {
    activityBuffer.push({ type: 'info', message: `Session resumed: ${displayCode}` });
  }

  // Create peer connection
  const pc = new RTCPeerConnection({
    iceServers: [
      { urls: 'stun:stun.l.google.com:19302' },
      { urls: 'stun:stun1.l.google.com:19302' },
    ],
  });

  const session: RemoteSession = {
    code,
    parts,
    displayCode,
    pc,
    dc: null,
    relay: relayAllowed() ? newRelayInfo() : null,
    status: 'connecting',
    shadowShell,
    panel,
    activityBuffer,
    panelOpen,
  };

  window.__shiroRemoteSession = session;

  // Update HUD immediately (before signaling)
  if (terminal) {
    terminal.updateHudRemoteCode(displayCode);
  }

  // Create data channel and wire up handlers
  const dc = pc.createDataChannel('shiro-remote', { ordered: true });
  wireSession(session, dc);

  // Gather ICE candidates
  const iceCandidates: RTCIceCandidate[] = [];
  pc.onicecandidate = (event) => {
    if (event.candidate) {
      iceCandidates.push(event.candidate);
    }
  };

  // Create offer
  const offer = await pc.createOffer();
  await pc.setLocalDescription(offer);

  // Wait for ICE gathering
  await new Promise<void>((resolve) => {
    if (pc.iceGatheringState === 'complete') {
      resolve();
    } else {
      pc.onicegatheringstatechange = () => {
        if (pc.iceGatheringState === 'complete') {
          resolve();
        }
      };
      setTimeout(resolve, 5000);
    }
  });

  // Register with signaling server
  try {
    await registerOffer(SIGNALING_URL, parts, { offer: pc.localDescription, candidates: iceCandidates, relay: session.relay });

    session.status = 'waiting';

    // Start polling for answer
    pollForAnswer(session);

    reconnectAttempts.delete(code);
    console.log('[remote] Auto-reconnect successful, waiting for peer');
    return true;
  } catch (err: any) {
    if (err instanceof RemoteProtocolError) {
      // An older server would need the code itself: keep the session as an error, don't retry
      console.error(`[remote] ${err.message}`);
      logActivity(session, 'error', err.message);
      session.status = 'error';
      session.error = err.message;
      reconnectAttempts.delete(code);
      return false;
    }
    cleanupSession();
    // The signaling server may just be restarting (a deploy); retry a few times
    // with the same code before giving it up.
    const attempt = (reconnectAttempts.get(code) ?? 0) + 1;
    reconnectAttempts.set(code, attempt);
    if (attempt <= RECONNECT_RETRIES && localStorage.getItem(REMOTE_CODE_KEY) === code) {
      const delay = 3000 * attempt;
      console.warn(`[remote] Auto-reconnect failed (${err.message}); retrying in ${delay / 1000}s`);
      setTimeout(() => {
        if (!window.__shiroRemoteSession && localStorage.getItem(REMOTE_CODE_KEY) === code) {
          startRemoteWithCode(code, terminal, existingPanel, existingShell, existingPanelOpen, existingBuffer);
        }
      }, delay);
      return false;
    }
    console.error(`[remote] Auto-reconnect failed: ${err.message}`);
    reconnectAttempts.delete(code);
    localStorage.removeItem(REMOTE_CODE_KEY);
    return false;
  }
}
