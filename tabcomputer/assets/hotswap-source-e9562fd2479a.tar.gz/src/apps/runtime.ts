/**
 * Running apps (docs/APPS.md "Lifecycle"): one `AppInstance` per app that is
 * open in this tab. It owns the app's backend (supervisor.ts), answers its
 * page's requests (the files under `entry`, then the backend), serves its
 * tab.js channel (host.ts), and counts the views showing it: when the last
 * one closes the backend stops, unless the manifest says keepAlive.
 *
 * This is the shared core under every way of showing an app: a desktop
 * window and app mode (window.ts), `app dev`, and whatever else mounts an
 * app's frame (frame.ts) and wants its state and log (an app pane in the
 * Code app, a Studio). No DOM here beyond the browser's download.
 */
import type { AppManifest } from './manifest';
import { AppHost, type HostDeps, type RunHandle, type RunRequest } from './host';
import { resolveAllowed, normalizePath } from './access';
import { Supervisor, pickPort, type BackendState } from './supervisor';
import { firstInstallText, installProgress } from './progress';
import { AppError, appDataDir, expectedPath } from './registry';
import { appTheme } from './surface';
import { iframeServer, type VirtualResponse } from '../iframe-server';
import { PAGE_SET_TIMEOUT, PAGE_CLEAR_TIMEOUT } from '../node-compat/page-globals';
import type { FileSystem } from '../filesystem';
import type { Shell } from '../shell';

export interface AppsDeps {
  fs: FileSystem;
  shell: Shell;
  /** Stand-ins for tests */
  toolchains?: HostDeps['toolchains'];
  download?: HostDeps['download'];
  reveal?: HostDeps['reveal'];
  packages?: Packages;
}

/**
 * Installing the Debian packages a manifest's `needs` names. The one place
 * that knows how. `realPackages` asks the server for the layer of the set
 * (src/debian/package-sets.ts: seconds when someone needed the same packages
 * before, a build on the server with its progress when nobody did) and
 * installs with apt when the server has none.
 */
export interface Packages {
  /** Which of `names` are installed */
  installed(names: string[]): Promise<Record<string, boolean>>;
  /** Install them; `onLine` gets the installer's output. Resolves to the exit status. */
  install(names: string[], onLine: (line: string) => void): Promise<number>;
}

let deps: AppsDeps | null = null;
/** Called once at boot (main.ts) and by tests: the filesystem and the shell apps run on */
export function configureApps(d: AppsDeps | null): void { deps = d; }
export function appsDeps(): AppsDeps {
  if (!deps) throw new AppError('apps are not available here');
  return deps;
}
export const homeDir = (): string => appsDeps().shell.env['HOME'] || '/home/user';

/** One shell line in a process of its own, without a terminal */
export function runLine(req: RunRequest): RunHandle {
  const side = appsDeps().shell.fork();
  (side as unknown as { terminal: unknown }).terminal = null;
  side.cwd = req.cwd;
  Object.assign(side.env, req.env);
  const own = new AbortController();
  side.inheritedAbort = own;
  // (the shell writes line ends for a terminal: \r\n; a caller gets what the program wrote)
  const out = (s: string) => req.onStdout(s.replace(/\r\n/g, '\n'));
  const err = (s: string) => req.onStderr(s.replace(/\r\n/g, '\n'));
  const p = req.stdin !== undefined ? side.executeWithStdin(req.line, req.stdin, out, err) : side.execute(req.line, out, err);
  return { done: p.catch(() => 1), kill: () => own.abort() };
}

/** Hand bytes to the person's real disk: the browser's download */
export function browserDownload(name: string, bytes: Uint8Array, type: string): void {
  // An anchor that is never in the document: nothing else sees the click
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([bytes as BlobPart], { type }));
  a.download = name;
  a.click();
  PAGE_SET_TIMEOUT(() => URL.revokeObjectURL(a.href), 60_000);
}

const realToolchains: HostDeps['toolchains'] = {
  async known(names) {
    const { listToolchains } = await import('../commands/toolchain');
    const all = await listToolchains(appsDeps().fs);
    return names.filter((n) => all.some((t) => t.id === n));
  },
  async installed(sets) {
    const { listToolchains } = await import('../commands/toolchain');
    const all = await listToolchains(appsDeps().fs);
    return Object.fromEntries(sets.map((s) => [s, !!all.find((t) => t.id === s)?.installed]));
  },
  async install(set, onLine) {
    let buf = '';
    const out = (s: string) => {
      const parts = (buf + s.replace(/\r\n/g, '\n')).split('\n');
      buf = parts.pop() ?? '';
      for (const l of parts) if (l.trim()) onLine(l);
    };
    // The builtin itself, with stream writers. Through a shell line a builtin's output arrives
    // when it ends, and a first install takes minutes: the window would show nothing new until then.
    // (the set's name is one of the manifest's, checked to be a plain name)
    const side = appsDeps().shell.fork();
    (side as unknown as { terminal: unknown }).terminal = null;
    side.cwd = homeDir();
    const cmd = side.commands.get('toolchain') ?? (await import('../commands/toolchain')).toolchainCmd;
    const ctx = {
      args: ['install', set], fs: appsDeps().fs, cwd: side.cwd, env: side.env, stdin: '', stdout: '', stderr: '', shell: side,
      stdinIsTTY: false, stdoutIsTTY: false, stderrIsTTY: false, streamStdout: out, streamStderr: out,
    };
    let code: number;
    try { code = await cmd.exec(ctx); } catch (e) { out(`toolchain: ${(e as Error)?.message ?? e}\n`); code = 1; }
    // (a command that ignores the stream writers leaves its output here)
    out(ctx.stdout + ctx.stderr);
    if (buf.trim()) onLine(buf);
    return code;
  },
};

/** Lines of a stream, one call each */
function lines(onLine: (line: string) => void): { write(s: string): void; end(): void } {
  let buf = '';
  return {
    write(s) {
      const parts = (buf + s.replace(/\r\n?/g, '\n')).split('\n');
      buf = parts.pop() ?? '';
      for (const l of parts) if (l.trim()) onLine(l);
    },
    end() { if (buf.trim()) onLine(buf); buf = ''; },
  };
}

const realPackages: Packages = {
  async installed(names) {
    // dpkg's own record: a package is here when its stanza says so
    const status = String(await appsDeps().fs.readFile('/var/lib/dpkg/status', 'utf8').catch(() => ''));
    const have = new Set<string>();
    for (const stanza of status.split('\n\n')) {
      const name = /^Package: (\S+)$/m.exec(stanza)?.[1];
      if (name && /^Status: .* installed$/m.test(stanza)) have.add(name);
    }
    return Object.fromEntries(names.map((n) => [n, have.has(n)]));
  },
  async install(names, onLine) {
    const { fs } = appsDeps();
    const out = lines(onLine);
    // (the names are the manifest's, checked to be package names: no blank, no quote)
    const sh = (line: string) => runLine({ line, cwd: homeDir(), env: {}, onStdout: out.write, onStderr: out.write }).done.then((code) => { out.end(); return code; });
    const { installedRootfs } = await import('../debian/rootfs');
    if (!await installedRootfs(fs)) {
      onLine('Installing Debian first (debian install)...');
      const code = await sh('debian install');
      if (code) return code;
    }
    // The layer of exactly this set, when the server has it or builds it
    const sets = await import('../debian/package-sets');
    const shell = appsDeps().shell;
    const r = await sets.installPackageSet(fs, names, { progress: onLine, afterApply: async () => { await sets.afterLayer(fs, (n) => !!shell.commands.get(n)); } });
    if (r.ok) { await fs.sync(); return 0; }
    onLine(sets.fallbackSentence(names, r));
    const lists = await fs.readdir('/var/lib/apt/lists').catch(() => [] as string[]);
    if (!lists.some((f) => f.endsWith('_Packages'))) {
      const code = await sh('sudo apt-get update');
      if (code) return code;
    }
    // (TABCOMPUTER_APT_LAYERS=0: the question was just asked; apt itself does not ask again.
    // After `--` every word is a package name: none is read as an option)
    return sh(`sudo DEBIAN_FRONTEND=noninteractive TABCOMPUTER_APT_LAYERS=0 apt-get install -y -- ${names.join(' ')}`);
  },
};

export { appTheme };

const MIME: Record<string, string> = {
  html: 'text/html; charset=utf-8', htm: 'text/html; charset=utf-8', css: 'text/css; charset=utf-8', js: 'text/javascript; charset=utf-8', mjs: 'text/javascript; charset=utf-8',
  json: 'application/json', svg: 'image/svg+xml', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp', ico: 'image/x-icon',
  woff: 'font/woff', woff2: 'font/woff2', ttf: 'font/ttf', txt: 'text/plain; charset=utf-8', md: 'text/markdown; charset=utf-8', csv: 'text/csv; charset=utf-8',
  wasm: 'application/wasm', pdf: 'application/pdf', map: 'application/json', xml: 'application/xml', mp3: 'audio/mpeg', mp4: 'video/mp4', webm: 'video/webm',
};

/**
 * What keeps the page of an app without network access on its own origin:
 * its requests, frames and forms go nowhere else. (Sent with every HTML
 * document of the app; docs/APPS.md says what this does and does not stop.)
 */
export const NO_NETWORK_CSP = [
  "default-src 'self' data: blob: 'unsafe-inline' 'unsafe-eval'",
  "connect-src 'self' data: blob:",
  "frame-src 'self' data: blob:",
  "form-action 'self'",
].join('; ');

/** The fixed path an app's page loads the client library from */
export const TAB_JS_PATH = '/__tabcomputer/tab.js';
/** The page tabcomputer supplies for an app that has none of its own (declare.ts): one script for every such app */
export const PAGE_JS_PATH = '/__tabcomputer/page.js';
const hostScripts = new Map<string, Promise<string>>();
/** A script of public/apphost/, for pages that are not on an app origin (where the server itself serves it) */
function hostScript(name: string): Promise<string> {
  let p = hostScripts.get(name);
  if (!p) {
    p = fetch(`/apphost/${name}`, { cache: 'no-cache' }).then((r) => {
      if (!r.ok || /html/i.test(r.headers.get('content-type') ?? '')) throw new Error(`HTTP ${r.status}`);
      return r.text();
    }).catch((e) => { hostScripts.delete(name); throw e; });
    hostScripts.set(name, p);
  }
  return p;
}
export const tabJsSource = (): Promise<string> => hostScript('tab.js');
/** Tests: the library's text without a server */
export function setTabJsSource(text: string | null, name = 'tab.js'): void { if (text === null) hostScripts.delete(name); else hostScripts.set(name, Promise.resolve(text)); }

const esc = (s: string) => s.replace(/[&<>"']/g, (c) => `&#${c.charCodeAt(0)};`);
/** The supplied page's background in each appearance (page.js's --bg): its frame has this color before the page paints */
export const PAGE_BG = { light: '#fff', dark: '#1b1d29' } as const;
/**
 * The document of a declared app: its name, tab.js, and the supplied page.
 * It is written in the appearance the desktop has now, so nothing is white
 * for a moment in the dark one.
 */
export const suppliedPage = (m: AppManifest, theme: 'light' | 'dark' = 'light'): string => `<!doctype html>
<html lang="en" data-theme="${theme}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(m.name)}</title>
<style>html { background: ${PAGE_BG[theme]}; color-scheme: ${theme}; }</style>
</head>
<body>
<script src="${TAB_JS_PATH}"></script>
<script src="${PAGE_JS_PATH}"></script>
</body>
</html>
`;

export interface AppRequest { method: string; path: string; headers?: Record<string, string>; body?: Uint8Array | null }
export type InstanceEvent = 'state' | 'log' | 'views' | 'reload';

export interface AppRef {
  manifest: AppManifest;
  dir: string;
  /** Where it came from (registry.ts `source`); `dev:<dir>` for `app dev` */
  source: string;
  dev?: boolean;
}

/** Something showing the app: a window, the tab in app mode, a pane */
export interface AppView { kind: 'window' | 'become' | 'pane'; close(): void; reload?(): void; focus?(): void }

export class AppInstance {
  readonly id: string;
  manifest: AppManifest;
  readonly dir: string;
  readonly dataDir: string;
  readonly source: string;
  readonly dev: boolean;
  supervisor: Supervisor | null = null;
  host: AppHost;
  readonly views = new Set<AppView>();
  /** The page is on an origin of its own (set by the frame that shows it) */
  confined = false;
  /** Lines from the backend and the host (`app dev` prints them; a pane shows them) */
  readonly log: string[] = [];
  private listeners = new Set<(ev: InstanceEvent, text?: string) => void>();
  private prepared: Promise<void> | null = null;
  private offs: (() => void)[] = [];
  /** The window its tab.js calls act on */
  window: HostDeps['window'] = null;
  /**
   * The Studio's "Try it": what each page that loads runs with (host.ts `takeSamples`), until the
   * Studio changes the app. Not used up by the first page: one still loading when Try it reloads
   * could take it and be replaced.
   */
  samples: { path: string; rel: string }[] | true | null = null;

  constructor(ref: AppRef) {
    this.manifest = ref.manifest;
    this.id = ref.manifest.id;
    this.dir = ref.dir;
    this.source = ref.source;
    this.dev = !!ref.dev;
    this.dataDir = appDataDir(homeDir(), this.id);
    this.host = this.makeHost();
    this.makeSupervisor();
  }

  private makeHost(): AppHost {
    const d = appsDeps();
    const self = this;
    return new AppHost({ manifest: this.manifest, dir: this.dir, dataDir: this.dataDir, reviewed: this.source === 'site', get confined() { return self.confined; },
      takeSamples: () => self.samples,
    }, {
      fs: d.fs as unknown as HostDeps['fs'],
      home: homeDir(),
      run: runLine,
      download: d.download ?? browserDownload,
      toolchains: d.toolchains ?? realToolchains,
      get window() { return self.window; },
      reveal: d.reveal,
      theme: appTheme,
      log: (line) => this.say(`[tab.js] ${line}\n`),
    });
  }

  private makeSupervisor(): void {
    for (const off of this.offs) off();
    this.offs = [];
    this.supervisor?.stop();
    this.supervisor = null;
    const b = this.manifest.backend;
    if (!b) return;
    const port = b.port === 'auto' ? pickPort(this.id, (p) => iframeServer.isPortInUse(p), portsTaken()) : b.port;
    const sup = new Supervisor({
      id: this.id, start: b.start, cwd: this.dir, port, health: b.health,
      env: { APP_ID: this.id, APP_DIR: this.dir, APP_DATA: this.dataDir },
    }, {
      spawn: (line, cwd, env, onOutput) => runLine({ line, cwd, env, onStdout: onOutput, onStderr: onOutput }),
      portUp: (p) => iframeServer.isPortInUse(p),
      onPort: (cb) => iframeServer.onPortChange(cb),
      probe: async (p, path) => (await iframeServer.fetch(p, path)).status ?? 200,
      closePort: (p) => iframeServer.close(p),
      setTimeout: (fn, ms) => PAGE_SET_TIMEOUT(fn, ms),
      clearTimeout: (t) => PAGE_CLEAR_TIMEOUT(t as ReturnType<typeof setTimeout>),
    });
    this.offs.push(sup.on(() => this.emit('state')), sup.onLog((text) => this.say(text)));
    this.supervisor = sup;
  }

  /** `app dev`: the manifest changed on disk */
  setManifest(m: AppManifest): void {
    if (m.id !== this.id) throw new AppError(`the id changed from ${this.id} to ${m.id}: close the app and open it again`);
    const backendChanged = JSON.stringify(m.backend) !== JSON.stringify(this.manifest.backend);
    this.manifest = m;
    this.host = this.makeHost();
    this.prepared = null;
    if (backendChanged) this.makeSupervisor();
  }

  on(cb: (ev: InstanceEvent, text?: string) => void): () => void { this.listeners.add(cb); return () => { this.listeners.delete(cb); }; }
  private emit(ev: InstanceEvent, text?: string): void {
    for (const cb of [...this.listeners]) { try { cb(ev, text); } catch (e) { console.error('[app]', e); } }
  }

  say(text: string): void {
    if (!text) return;
    for (const l of text.replace(/\r\n/g, '\n').split('\n')) if (l.trim()) this.log.push(l);
    if (this.log.length > 500) this.log.splice(0, this.log.length - 500);
    this.emit('log', text);
  }

  get state(): BackendState | 'static' { return this.supervisor ? this.supervisor.state : 'static'; }

  /**
   * What must be there before the first start: the manifest's toolchain sets
   * (installed with `toolchain install`), its `files`, the data folder. Done
   * once per instance; `report` gets a line per step and the installer's output.
   */
  prepare(report: (stage: string, line?: string) => void = () => {}): Promise<void> {
    return this.prepared ??= this.doPrepare(report).catch((e) => { this.prepared = null; throw e; });
  }

  private async doPrepare(report: (stage: string, line?: string) => void): Promise<void> {
    const d = appsDeps();
    const home = homeDir();
    await d.fs.mkdir(this.dataDir, { recursive: true });
    const tc = d.toolchains ?? realToolchains;
    // A name in `needs` that is a toolchain set is installed as that set (a prebuilt layer); the rest are packages
    const asSets = this.manifest.needs.length ? await tc.known?.(this.manifest.needs) ?? [] : [];
    const sets = [...new Set([...this.manifest.toolchains, ...asSets])];
    const packages = this.manifest.needs.filter((n) => !asSets.includes(n));
    const marker = `${this.dataDir}/.toolchains`;
    const done = new Set(((sets.length || packages.length ? await d.fs.readFile(marker, 'utf8').catch(() => '') : '') as string).split('\n').filter(Boolean));
    const wanted = packages.filter((p) => !done.has(`package:${p}`));
    if (wanted.length) {
      const pk = d.packages ?? realPackages;
      const have = await pk.installed(wanted);
      const missing = wanted.filter((p) => !have[p]);
      if (missing.length) {
        let stage = firstInstallText(this.manifest.name);
        const said = installProgress();
        report(stage);
        this.say(`[app] ${this.id}: apt-get install ${missing.join(' ')}\n`);
        const code = await pk.install(missing, (line) => { stage = said(line) ?? stage; report(stage, line); this.say(line + '\n'); });
        if (code !== 0) throw new AppError(`${missing.join(', ')} could not be installed (exit ${code}); ${this.manifest.name} needs ${missing.length > 1 ? 'them' : 'it'}`);
      }
      for (const p of wanted) done.add(`package:${p}`);
      await d.fs.writeFile(marker, [...done].join('\n') + '\n');
    }
    if (sets.length) {
      const todo = sets.filter((s) => !done.has(s));
      if (todo.length) {
        const have = await tc.installed(todo);
        for (const set of todo) {
          if (!have[set]) {
            // The stage is a sentence for the person (progress.ts); the installer's own lines are the details
            let stage = firstInstallText(this.manifest.name);
            const said = installProgress();
            report(stage);
            this.say(`[app] ${this.id}: toolchain install ${set}\n`);
            const code = await tc.install(set, (line) => { stage = said(line) ?? stage; report(stage, line); this.say(line + '\n'); });
            if (code !== 0) throw new AppError(`toolchain install ${set} failed (exit ${code}); ${this.manifest.name} needs it`);
          }
          done.add(set);
        }
        await d.fs.writeFile(marker, [...done].join('\n') + '\n');
      }
    }
    const missing: string[] = [];
    for (const entry of this.manifest.files) {
      const { path, folder } = expectedPath(entry, this.dir, home);
      if (folder) await d.fs.mkdir(path, { recursive: true });
      else if (!await d.fs.exists(path)) missing.push(entry);
    }
    if (missing.length) throw new AppError(`${this.manifest.name} expects ${missing.join(', ')}, which ${missing.length > 1 ? 'are' : 'is'} not there`);
  }

  /** Start the backend unless it is lazy (then the first request does). True when there is nothing to wait for or it runs. */
  async startBackend(force = false): Promise<boolean> {
    if (!this.supervisor) return true;
    if (this.manifest.backend?.lazy && !force) return true;
    return this.supervisor.start();
  }

  // ── the page's requests ──

  private staticRoot(): { root: string; index: string } | null {
    const e = this.manifest.entry;
    if (!e) return null;
    if (/\.html?$/i.test(e)) {
      const at = e.lastIndexOf('/');
      return { root: at < 0 ? this.dir : `${this.dir}/${e.slice(0, at)}`, index: e.slice(at + 1) };
    }
    return { root: e === '.' ? this.dir : `${this.dir}/${e}`, index: 'index.html' };
  }

  /** The path of the page inside the app's address space */
  entryPath(): string { return '/'; }

  private async staticFile(pathname: string): Promise<VirtualResponse | null> {
    const s = this.staticRoot();
    if (!s) return null;
    const fs = appsDeps().fs;
    let file: string;
    try { file = normalizePath(s.root + pathname); } catch { return null; }
    if (file !== s.root && !file.startsWith(s.root + '/')) return null;
    // A link inside the folder is followed only while it stays in the app's folder
    let real: string;
    try { real = (await resolveAllowed(fs, [{ path: this.dir, mode: 'read' }], file, 'read')).real; } catch { return null; }
    let st = await fs.stat(real).catch(() => null);
    if (st?.isDirectory()) { real = `${real}/${file === s.root ? s.index : 'index.html'}`; st = await fs.stat(real).catch(() => null); }
    if (!st || st.isDirectory()) return null;
    const body = (await fs.readFile(real)) as Uint8Array;
    const type = MIME[real.slice(real.lastIndexOf('.') + 1).toLowerCase()] ?? 'application/octet-stream';
    return { status: 200, headers: { 'content-type': type, 'cache-control': 'no-cache' }, body };
  }

  /** Answer one request of the app's page: tab.js, a file under `entry`, else the backend. */
  async fetch(req: AppRequest): Promise<VirtualResponse> {
    const method = (req.method || 'GET').toUpperCase();
    let pathname = req.path.split('#')[0].split('?')[0] || '/';
    try { pathname = decodeURIComponent(pathname); } catch { /* served as written */ }
    let res: VirtualResponse | null = null;
    if (pathname === TAB_JS_PATH || pathname === PAGE_JS_PATH) {
      const name = pathname.slice(pathname.lastIndexOf('/') + 1);
      try { res = { status: 200, headers: { 'content-type': MIME.js, 'cache-control': 'no-cache' }, body: await hostScript(name) }; }
      catch { res = { status: 502, headers: { 'content-type': 'text/plain' }, body: `${name} could not be loaded from this site` }; }
      return res;
    }
    // An app without a page of its own: tabcomputer's, the same for every such app
    if (this.manifest.kind !== 'page' && (method === 'GET' || method === 'HEAD') && (pathname === '/' || pathname === '/index.html')) {
      return withCsp({ status: 200, headers: { 'content-type': MIME.html, 'cache-control': 'no-cache' }, body: suppliedPage(this.manifest, appTheme.get()) });
    }
    if (method === 'GET' || method === 'HEAD') res = await this.staticFile(pathname);
    if (!res && this.supervisor) {
      const up = this.supervisor.state === 'running' || await this.supervisor.start();
      if (!up) res = { status: 502, headers: { 'content-type': 'text/plain; charset=utf-8' }, body: `${this.manifest.name}'s backend is not running: ${this.supervisor.error || 'it was stopped'}` };
      else res = await iframeServer.fetch(this.supervisor.port, req.path, { method, headers: req.headers ?? {}, body: req.body ?? null });
    }
    res ??= { status: 404, headers: { 'content-type': 'text/plain; charset=utf-8' }, body: `Not found: ${pathname}` };
    return this.manifest.access.network ? res : withCsp(res);
  }

  // ── views ──

  attach(view: AppView): void {
    this.views.add(view);
    this.emit('views');
  }

  /** A view closed. The last one takes the backend with it, unless the manifest keeps it alive. */
  detach(view: AppView): void {
    if (!this.views.delete(view)) return;
    this.emit('views');
    if (this.views.size) return;
    if (this.manifest.backend?.keepAlive) return;
    this.stop();
  }

  /** Ask every view to load the page again (`app dev` after a change) */
  reload(): void {
    this.emit('reload');
    for (const v of this.views) v.reload?.();
  }

  /** Stop the backend; the views stay (and say it is stopped) */
  stopBackend(): void { this.supervisor?.stop(); }

  /** Stop the backend and forget the instance (its views are closed first by the caller) */
  stop(): void {
    this.supervisor?.stop();
    if (instances.get(this.id) === this) instances.delete(this.id);
    this.emit('state');
  }

  /** Close every view and stop (`app stop`, `app remove`) */
  close(): void {
    for (const v of [...this.views]) { try { v.close(); } catch { /* already gone */ } }
    this.views.clear();
    this.stop();
  }
}

function withCsp(res: VirtualResponse): VirtualResponse {
  const headers: Record<string, string> = {};
  for (const [k, v] of Object.entries(res.headers ?? {})) headers[k.toLowerCase()] = String(v);
  const type = headers['content-type'] ?? res.contentType ?? '';
  if (!/html|svg|xml/i.test(type)) return res;
  headers['content-security-policy'] = NO_NETWORK_CSP;
  return { ...res, headers };
}

const instances = new Map<string, AppInstance>();
const portsTaken = (): Set<number> => new Set([...instances.values()].map((i) => i.supervisor?.port ?? 0));

/** The running instance of an app, if it is open */
export const instanceOf = (id: string): AppInstance | undefined => instances.get(id);
export const runningInstances = (): AppInstance[] => [...instances.values()];

/** The instance of an app, made on first use. An instance of another folder under the same id is refused. */
export function instanceFor(ref: AppRef): AppInstance {
  const existing = instances.get(ref.manifest.id);
  if (existing) {
    if (existing.dir !== ref.dir) throw new AppError(`${ref.manifest.id} is already open from ${existing.dir}: close it first (app stop ${ref.manifest.id})`);
    return existing;
  }
  const inst = new AppInstance(ref);
  instances.set(inst.id, inst);
  return inst;
}

/** Tests: stop everything */
export function resetApps(): void {
  for (const i of [...instances.values()]) i.close();
  instances.clear();
}
