// Legacy shiro-… storage keys copied to their tabcomputer-… names, before anything reads them
// Console capture - must be first before any other code runs (bounded ring buffer)
import { toolkitScaleEnv } from './gui/display-scale';
import { queryConsole, clearConsoleLog } from './console-log';
// Freeze watchdog (event-loop lag, long tasks, commands in flight), from boot too
import { previousLoadWedge } from './watchdog';

// Old capture API, kept as a view over the bounded log (console command, clip-report)
Object.defineProperty(window, '__shiroCapturedMessages', {
  configurable: true,
  get: () => queryConsole({ limit: 100000, maxBytes: 1e9 }).entries
    .map((e) => ({ type: e.level, message: e.count > 1 ? `${e.text} (×${e.count})` : e.text, timestamp: e.t })),
});
(window as any).__shiroClearMessages = clearConsoleLog;

import '@xterm/xterm/css/xterm.css';
import { FileSystem } from './filesystem';
import { canBlock } from './kernel/channel';
import { Shell } from './shell';
import { CommandRegistry, Command } from './commands/index';
import { registry } from './registry';
import { builtinCloneHandles } from './commands/git-clone-route';
import { lazyCommand } from './utils/lazy-command';
import { pipeBytes } from './utils/stream-bytes';
import { shellBuiltins } from './commands/shell-builtins';
import { shiroCmds } from './commands/shiro-cmds';
import { grepCmd } from './commands/grep';
import { sedCmd } from './commands/sed';
import { fetchCmd, curlCmd } from './commands/fetch';
import { globCmd } from './commands/glob';
import { jsEvalCmd } from './commands/jseval/js-eval-cmd';
import './node-compat/page-globals'; // before anything can patch fetch/timers; node-compat loads lazily
import { npxCmd } from './commands/npx';
import { viCmd, exCmd } from './commands/vi';
import { sourceCmd, dotCmd } from './commands/source';
import { jobsCmd, fgCmd, bgCmd, waitCmd } from './commands/jobs';
import { testCmd } from './commands/test';
import { serveCmd, serversCmd } from './commands/serve';
import { clipReportCmd } from './commands/clip-report';
import { hudCmd } from './commands/hud';
import { faviconCmd } from './commands/favicon';
import { historyCmd } from './commands/history';
import { consoleCmd } from './commands/console';
import { watchdogCmd } from './commands/watchdog';
import { rgCmd } from './commands/rg';
import { spawnCmd } from './commands/spawn';
import { scCmd, claudeWindowCmd } from './commands/sc';
import { claudeCmd } from './commands/claude';
import { pbcopyCmd, pbpasteCmd, xclipCmd, xselCmd, wlCopyCmd } from './commands/pbcopy';
import { ensureClaudeCodeInstalled } from './claude-code-version';
import { setupCmd } from './commands/setup';
import { psCmd, killCmd } from './commands/ps';
import { htmlCmd, imgCmd } from './commands/html';
import { dougCmd } from './commands/doug';
import { becomeCmd, unbecomeCmd, getBecomeConfig, activateBecomeMode, deactivateBecomeMode } from './commands/become';
import { pageCmd } from './commands/page';
import { titleCmd } from './commands/title';

import { mkTempCmd } from './commands/mktemp';
import { tputCmd } from './commands/tput';
import { sttyCmd, resetCmd } from './commands/stty';
import { gzipCmd, gunzipCmd, zcatCmd } from './commands/gzip';
import { wgetCmd } from './commands/wget';
import { pgrepCmd, pkillCmd } from './commands/pgrep';
import { nprocCmd } from './commands/nproc';
import { syncCmd } from './commands/sync';
import { getconfCmd } from './commands/getconf';
import { iconvCmd } from './commands/iconv';
import { speakCmd } from './commands/speak';
import { listenCmd } from './commands/listen';
import { notifyCmd } from './commands/notify';
import { cameraCmd } from './commands/camera';
import { cvCmd } from './commands/cv';
import { spiritCmd } from './commands/spirit';
// wasi and pkg are lazy-loaded (pulls in ~960-line wasi-runtime.ts)
import { processTable } from './process-table';
import { createPathShims, installAlwaysShims } from './path-shims';
import { getKernel, Kernel } from './kernel/kernel';
import { hotswap } from './hotswap/swap';
import { liveModule, trackInstance } from './hotswap/live';
import { startDisplay } from './x11/display';
import { startGLServer, getGLServer } from './gl/server';
import { installNet } from './kernel/net';
import { attachKernelTty } from './kernel/pty';
import { sudoCmd } from './commands/sudo';
import { shiroAptCmd, shiroAptMethodCmd, shiroAptStoreCmd, shiroPreconfigureCmd } from './commands/debian';
import { iframeServer } from './iframe-server';
import { unixCommands } from './commands/unix';
import { ShiroTerminal } from './terminal';

import { initFaviconUpdater, initTitle } from './favicon';
import { initMobileInput } from './mobile-input';
import { initDropHandler } from './drop-handler';
import { closeSplitView } from './split-view';
import { initFileAssociations } from './file-associations';
import { setActiveTerminal } from './active-terminal';
import { initPanes } from './panes';
import { uiMode } from './ui-mode';
import { activeProfile } from './profile';
import type { Desktop } from './desktop/index';
import { installDomFs } from './dom-fs';
import { desktopCmd } from './commands/desktop';
import buildNumber from '../build-number.txt?raw';
import { seedAgentDocs } from './agent-docs';
import {
  defaultRuntimeContext,
  parseRuntimeContext,
  SHIRO_RUNTIME_CONTEXT_SESSION_KEY,
} from './seed-runtime-context';
import { getShiroOrigin } from './utils/shiro-origin';
import { logIsolationStatus } from './utils/isolation';
import { requestPersistentStorage, setActiveFileSystem, storageInfo } from './storage';
import { installNodeWorkerBoot } from './node-worker/boot';
import { bootStarted, bootFinished, bootStep, safeMode } from './safe-mode';
import { safeModeCmd } from './commands/safe-mode';
import * as agentResume from './agent-resume';

/**
 * Register a command in both the CommandRegistry (for execution) and
 * the ModuleRegistry (for hot-reload capability).
 */
function registerCommand(commands: CommandRegistry, cmd: Command, sourcePath?: string): void {
  commands.register(cmd);
  registry.register(`commands/${cmd.name}`, cmd, sourcePath);
}

/** Ask for persistent storage once this much is stored (src/storage.ts). */
const PERSIST_AFTER_BYTES = 64 << 20;

async function main() {
  console.log(`[tabcomputer] Starting... (build #${buildNumber.trim()})`);
  // Hard Restart (src/desktop/index.ts) adds ?reload= to get past the HTTP cache; drop it again
  try {
    const u = new URL(location.href);
    if (u.searchParams.has('reload')) { u.searchParams.delete('reload'); history.replaceState(history.state, '', u.toString()); }
  } catch { /* not a page */ }
  logIsolationStatus();
  // Safe mode (src/safe-mode.ts): ?safe=1, or this tab's last loads never reached the prompt
  const safe = safeMode();
  bootStarted();
  if (safe) console.warn(`[tabcomputer] safe mode: ${safe}`);

  // The desktop (src/desktop) is its own chunk: shiro.computer's terminal UI
  // never loads it, and the desktop's download overlaps IndexedDB opening
  const profile = activeProfile();
  const mode = uiMode();
  const desktopModule = mode === 'desktop' ? import('./desktop/index') : null;
  // Its fonts download alongside (the desktop appears once they have: one draw)
  if (desktopModule) {
    for (const f of ['inter-latin-wght', 'jetbrains-mono-latin-wght']) {
      const l = document.createElement('link');
      l.rel = 'preload'; l.as = 'font'; l.type = 'font/woff2'; l.crossOrigin = 'anonymous';
      l.href = `/fonts/${f}.woff2`;
      document.head.appendChild(l);
    }
  }

  // Initialize filesystem
  const fs = new FileSystem();
  fs.holdKeyIndex(); // until the first prompt (below)
  // Node can't run in a Worker here (no SharedArrayBuffer): it runs in the page, reading small files synchronously
  if (canBlock() !== 'sab') void fs.holdSmallContent();
  await fs.init();
  setActiveFileSystem(fs);
  // The banner (and Save) if the browser deletes the filesystem's IndexedDB under the page (tabcomputer#71)
  void import('./storage-lost').then(m => m.watchStorageLost(fs)).catch(e => console.warn('[fs]', e));
  // Persistent storage (no eviction under storage pressure) once the machine
  // holds a lot: Firefox asks the user, so not for a page that stores little
  fs.onBigWrite(PERSIST_AFTER_BYTES, () => void requestPersistentStorage('large write'));
  void storageInfo().then(s => { if ((s.usage ?? 0) >= PERSIST_AFTER_BYTES) void requestPersistentStorage('stored data'); });
  const runtimeContext = (() => {
    if (window.parent === window) return defaultRuntimeContext();
    try {
      return parseRuntimeContext(sessionStorage.getItem(SHIRO_RUNTIME_CONTEXT_SESSION_KEY));
    } catch {
      return defaultRuntimeContext();
    }
  })();
  // ~/AGENTS.md and ~/.claude/CLAUDE.md for coding agents (src/agent-docs.ts): kept
  // current, except where the user edited them
  for (const line of await bootStep('agent docs', () => seedAgentDocs(fs, runtimeContext)) ?? []) console.log(`[agent-docs] ${line}`);
  console.log('[tabcomputer] Filesystem initialized');

  // Initialize file associations (extension → command mappings for `open`)
  initFileAssociations();

  // Listen for seed hydration from parent (when loaded via seed snippet)
  window.addEventListener('message', async (e) => {
    // Legacy format (v1): single JSON blob
    if (e.data && e.data.type === 'shiro-seed') {
      try {
        const { fs: nodes, localStorage: storage, context } = e.data.data;
        // Decode base64 content back to Uint8Array
        const decoded = nodes.map((n: any) => ({
          ...n,
          content: n.content ? Uint8Array.from(atob(n.content), (c: string) => c.charCodeAt(0)) : null,
        }));
        await fs.importAll(decoded);
        // Restore localStorage
        if (storage) {
          for (const [key, value] of Object.entries(storage)) {
            localStorage.setItem(key, value as string);
          }
        }
        if (context) {
          try {
            sessionStorage.setItem(SHIRO_RUNTIME_CONTEXT_SESSION_KEY, JSON.stringify(context));
          } catch {}
        }
        // Reload to boot with imported state
        location.reload();
      } catch (err) {
        console.error('Seed hydration failed:', err);
      }
    }

    // New format (v2): NDJSON for incremental parsing
    if (e.data && e.data.type === 'shiro-seed-v2') {
      try {
        const { ndjson, storage, context } = e.data;
        const lines = ndjson.split('\n');
        const nodes: any[] = [];
        const BATCH_SIZE = 100;

        // Parse NDJSON incrementally
        for (let i = 0; i < lines.length; i++) {
          const line = lines[i].trim();
          if (!line) continue;

          const node = JSON.parse(line);
          nodes.push({
            ...node,
            content: node.content ? Uint8Array.from(atob(node.content), (c: string) => c.charCodeAt(0)) : null,
          });

          // Yield to browser every BATCH_SIZE entries
          if (nodes.length % BATCH_SIZE === 0) {
            await new Promise(r => setTimeout(r, 0));
          }
        }

        await fs.importAll(nodes);

        // Restore localStorage
        if (storage) {
          const storageObj = typeof storage === 'string' ? JSON.parse(storage) : storage;
          for (const [key, value] of Object.entries(storageObj)) {
            localStorage.setItem(key, value as string);
          }
        }
        if (context) {
          try {
            sessionStorage.setItem(SHIRO_RUNTIME_CONTEXT_SESSION_KEY, JSON.stringify(context));
          } catch {}
        }

        // Reload to boot with imported state
        location.reload();
      } catch (err) {
        console.error('Seed v2 hydration failed:', err);
      }
    }
  });

  if (window.parent !== window) {
    try {
      window.parent.postMessage({ type: 'shiro-seed-ready' }, '*');
    } catch {}
  }

  // Set up command registry
  const commands = new CommandRegistry();

  // Register Unix commands (standard coreutils)
  for (const cmd of unixCommands) {
    commands.register(cmd);
  }

  // Register shell builtins (cd, export, help, command, sh, bash, grep/sed/diff overrides)
  commands.registerAll(shellBuiltins);

  // Register Shiro-specific commands (rm, ln, uname, which, type, etc.)
  commands.registerAll(shiroCmds);

  // Register additional Shiro commands
  // These are registered in both CommandRegistry and ModuleRegistry for hot-reload
  // Lazy: git.ts pulls in isomorphic-git (~150 KB), reload.ts esbuild-wasm's JS API
  registerCommand(commands, lazyCommand('git', 'Version control system',
    () => import('./commands/git').then(m => m.gitCmd), { keepOverPackage: builtinCloneHandles }), 'src/commands/git.ts');
  registerCommand(commands, grepCmd, 'src/commands/grep.ts');
  registerCommand(commands, sedCmd, 'src/commands/sed.ts');
  registerCommand(commands, fetchCmd, 'src/commands/fetch.ts');
  registerCommand(commands, curlCmd, 'src/commands/fetch.ts');
  registerCommand(commands, globCmd, 'src/commands/glob.ts');
  registerCommand(commands, jsEvalCmd, 'src/commands/jseval.ts');
  // Lazy: node-compat (~150 KB) loads with the first node script
  registerCommand(commands, lazyCommand('node', 'Execute JavaScript files (browser JS VM)',
    () => import('./commands/jseval/node-cmd').then(m => m.nodeCmd)), 'src/commands/jseval.ts');
  // Lazy (out of the boot bundle): npm, upload/download/shiro, hc, remote, cw
  registerCommand(commands, lazyCommand('npm', 'Browser-native package manager for Node.js packages',
    () => import('./commands/npm').then(m => m.npmCmd)), 'src/commands/npm.ts');
  registerCommand(commands, npxCmd, 'src/commands/npx.ts');
  registerCommand(commands, lazyCommand('build', 'Bundle TypeScript/JavaScript using esbuild-wasm',
    () => import('./commands/build').then(m => m.buildCmd)), 'src/commands/build.ts');
  registerCommand(commands, viCmd, 'src/commands/vi.ts');
  registerCommand(commands, exCmd, 'src/commands/vi.ts');
  registerCommand(commands, lazyCommand('nano', 'Simple text editor (Ctrl+O save, Ctrl+X exit)',
    () => import('./commands/nano').then(m => m.nanoCmd)), 'src/commands/nano.ts');
  registerCommand(commands, lazyCommand('upload', 'Upload files from host machine into virtual filesystem',
    () => import('./commands/upload').then(m => m.uploadCmd)), 'src/commands/upload.ts');
  registerCommand(commands, lazyCommand('download', 'Download files from virtual filesystem to host machine',
    () => import('./commands/upload').then(m => m.downloadCmd)), 'src/commands/upload.ts');
  registerCommand(commands, lazyCommand('tabcomputer', 'tabcomputer configuration',
    () => import('./commands/upload').then(m => m.shiroConfigCmd)), 'src/commands/upload.ts');
  registerCommand(commands, lazyCommand('shiro', 'Old name of the tabcomputer command',
    () => import('./commands/upload').then(m => m.shiroConfigCmd)), 'src/commands/upload.ts');
  registerCommand(commands, sourceCmd, 'src/commands/source.ts');
  registerCommand(commands, dotCmd, 'src/commands/source.ts');
  registerCommand(commands, jobsCmd, 'src/commands/jobs.ts');
  registerCommand(commands, fgCmd, 'src/commands/jobs.ts');
  registerCommand(commands, bgCmd, 'src/commands/jobs.ts');
  registerCommand(commands, waitCmd, 'src/commands/jobs.ts');
  registerCommand(commands, lazyCommand('hc', 'Hypercompact - token-efficient DOM navigation',
    () => import('./commands/hc').then(m => m.hcCmd)), 'src/commands/hc.ts');
  registerCommand(commands, testCmd, 'src/commands/test.ts');
  registerCommand(commands, lazyCommand('reload', 'Hot-reload modules from virtual filesystem',
    () => import('./commands/reload').then(m => m.reloadCmd)), 'src/commands/reload.ts');
  registerCommand(commands, lazyCommand('hotswap', 'Swap core modules built from a source checkout into this tab',
    () => import('./commands/hotswap').then(m => m.hotswapCmd)), 'src/commands/hotswap.ts');
  registerCommand(commands, lazyCommand('termcast', 'Record terminal sessions in asciicast format',
    () => import('./commands/termcast').then(m => m.termcastCmd)), 'src/commands/termcast.ts');
  registerCommand(commands, serveCmd, 'src/commands/serve.ts');
  registerCommand(commands, serversCmd, 'src/commands/serve.ts');
  registerCommand(commands, lazyCommand('image', 'Manage tabcomputer images (filesystem snapshots)',
    () => import('./commands/image').then(m => m.imageCmd)), 'src/commands/image.ts');
  registerCommand(commands, clipReportCmd, 'src/commands/clip-report.ts');
  registerCommand(commands, lazyCommand('seed', 'Export tabcomputer state (seed [blob|gif|html] [subdomain])',
    () => import('./commands/seed').then(m => m.seedCmd)), 'src/commands/seed.ts');
  registerCommand(commands, lazyCommand('remote', 'Start/stop remote development session for external Claude Code access',
    () => import('./commands/remote').then(m => m.remoteCmd)), 'src/commands/remote.ts');
  registerCommand(commands, hudCmd, 'src/commands/hud.ts');
  registerCommand(commands, faviconCmd, 'src/commands/favicon.ts');
  registerCommand(commands, historyCmd, 'src/commands/history.ts');
  registerCommand(commands, consoleCmd, 'src/commands/console.ts');
  registerCommand(commands, watchdogCmd, 'src/commands/watchdog.ts');
  registerCommand(commands, rgCmd, 'src/commands/rg.ts');
  registerCommand(commands, lazyCommand('mcp', 'MCP Streamable HTTP client',
    () => import('./commands/mcp-client').then(m => m.mcpCmd)), 'src/commands/mcp-client.ts');
  registerCommand(commands, lazyCommand('group', 'Encrypted group networking',
    () => import('./commands/group').then(m => m.groupCmd)), 'src/commands/group.ts');
  registerCommand(commands, spawnCmd, 'src/commands/spawn.ts');
  registerCommand(commands, claudeCmd, 'src/commands/claude.ts');
  registerCommand(commands, pbcopyCmd, 'src/commands/pbcopy.ts');
  registerCommand(commands, xclipCmd, 'src/commands/pbcopy.ts');
  registerCommand(commands, xselCmd, 'src/commands/pbcopy.ts');
  registerCommand(commands, pbpasteCmd, 'src/commands/pbcopy.ts');
  registerCommand(commands, wlCopyCmd, 'src/commands/pbcopy.ts');
  registerCommand(commands, claudeWindowCmd, 'src/commands/sc.ts');
  registerCommand(commands, scCmd, 'src/commands/sc.ts');
  registerCommand(commands, lazyCommand('cw', 'Spawn Claude Code in a web-rendered window',
    () => import('./commands/cw').then(m => m.cwCmd)), 'src/commands/cw.ts');
  registerCommand(commands, setupCmd, 'src/commands/setup.ts');
  registerCommand(commands, psCmd, 'src/commands/ps.ts');
  registerCommand(commands, killCmd, 'src/commands/ps.ts');
  registerCommand(commands, htmlCmd, 'src/commands/html.ts');
  registerCommand(commands, imgCmd, 'src/commands/html.ts');
  registerCommand(commands, dougCmd, 'src/commands/doug.ts');
  registerCommand(commands, becomeCmd, 'src/commands/become.ts');
  registerCommand(commands, unbecomeCmd, 'src/commands/become.ts');
  registerCommand(commands, pageCmd, 'src/commands/page.ts');
  registerCommand(commands, titleCmd, 'src/commands/title.ts');
  registerCommand(commands, desktopCmd, 'src/commands/desktop.ts');

  registerCommand(commands, lazyCommand('gh', 'GitHub CLI',
    () => import('./commands/gh').then(m => m.ghCmd)), 'src/commands/gh.ts');
  registerCommand(commands, lazyCommand('x86', 'Run x86-64 ELF binaries',
    () => import('./commands/x86').then(m => m.x86Cmd)), 'src/commands/x86.ts');
  registerCommand(commands, lazyCommand('gui', 'Linux GUI apps (xterm, GTK, Qt) from Debian, streamed on first use',
    () => import('./commands/gui').then(m => m.guiCmd)), 'src/commands/gui.ts');
  registerCommand(commands, lazyCommand('xserver', 'In-page X11 display server (Xshiro): status, start, stop',
    () => import('./commands/xserver').then(m => m.xserverCmd)), 'src/commands/xserver.ts');
  registerCommand(commands, mkTempCmd, 'src/commands/mktemp.ts');
  registerCommand(commands, lazyCommand('jq', 'JSON processor',
    () => import('./commands/jq').then(m => m.jqCmd)), 'src/commands/jq.ts');
  registerCommand(commands, tputCmd, 'src/commands/tput.ts');
  registerCommand(commands, sttyCmd, 'src/commands/stty.ts');
  registerCommand(commands, resetCmd, 'src/commands/stty.ts');
  registerCommand(commands, gzipCmd, 'src/commands/gzip.ts');
  registerCommand(commands, gunzipCmd, 'src/commands/gzip.ts');
  registerCommand(commands, zcatCmd, 'src/commands/gzip.ts');
  registerCommand(commands, wgetCmd, 'src/commands/wget.ts');
  registerCommand(commands, pgrepCmd, 'src/commands/pgrep.ts');
  registerCommand(commands, pkillCmd, 'src/commands/pgrep.ts');
  registerCommand(commands, nprocCmd, 'src/commands/nproc.ts');
  registerCommand(commands, syncCmd, 'src/commands/sync.ts');
  registerCommand(commands, getconfCmd, 'src/commands/getconf.ts');
  registerCommand(commands, lazyCommand('ed', 'Line editor',
    () => import('./commands/ed').then(m => m.edCmd)), 'src/commands/ed.ts');
  registerCommand(commands, iconvCmd, 'src/commands/iconv.ts');
  registerCommand(commands, lazyCommand('zip', 'Create ZIP archives',
    () => import('./commands/zip').then(m => m.zipCmd)), 'src/commands/zip.ts');
  registerCommand(commands, lazyCommand('unzip', 'Extract ZIP archives',
    () => import('./commands/zip').then(m => m.unzipCmd)), 'src/commands/zip.ts');
  registerCommand(commands, lazyCommand('cc', 'C compiler (xcc/wcc)',
    () => import('./commands/cc').then(m => m.ccCmd)), 'src/commands/cc.ts');
  registerCommand(commands, lazyCommand('gcc', 'C compiler (alias for cc)',
    () => import('./commands/cc').then(m => m.gccCmd)), 'src/commands/cc.ts');

  // Lazy-loaded new capabilities (WASM runtimes from CDN). Pyodide python is
  // the profile's python shim; without it python3 comes from pkg/apt only.
  registerCommand(commands, lazyCommand('pyodide', 'Python interpreter (Pyodide: numpy, pandas, ... in WebAssembly)',
    () => import('./commands/python').then(m => ({ ...m.pythonCmd, name: 'pyodide' }))), 'src/commands/python.ts');
  if (activeProfile().shims.python === 'cpython') {
    for (const [name, key, desc] of [
      ['python', 'cpythonCmd', 'Python 3 interpreter (CPython)'], ['python3', 'cpython3Cmd', 'Python 3 interpreter (CPython)'],
      ['pip', 'cpipCmd', 'Python package manager'], ['pip3', 'cpip3Cmd', 'Python package manager'],
    ] as const) {
      registerCommand(commands, lazyCommand(name, desc, () => import('./commands/python-default').then(m => m[key])), 'src/commands/python-default.ts');
    }
  } else if (activeProfile().shims.python === 'pyodide') {
    registerCommand(commands, lazyCommand('python', 'Python interpreter (Pyodide)',
      () => import('./commands/python').then(m => m.pythonCmd)), 'src/commands/python.ts');
    registerCommand(commands, lazyCommand('python3', 'Python 3 interpreter (Pyodide)',
      () => import('./commands/python').then(m => m.python3Cmd)), 'src/commands/python.ts');
    registerCommand(commands, lazyCommand('pip', 'Python package manager',
      () => import('./commands/python').then(m => m.pipCmd)), 'src/commands/python.ts');
    registerCommand(commands, lazyCommand('pip3', 'Python package manager',
      () => import('./commands/python').then(m => ({ ...m.pipCmd, name: 'pip3' }))), 'src/commands/python.ts');
  }
  registerCommand(commands, lazyCommand('sqlite3', 'SQLite database engine',
    () => import('./commands/sqlite').then(m => m.sqlite3Cmd)), 'src/commands/sqlite.ts');
  registerCommand(commands, lazyCommand('finder', 'Visual file manager',
    () => import('./commands/finder').then(m => m.finderCmd)), 'src/commands/finder.ts');
  registerCommand(commands, lazyCommand('code', 'Rich code editor (CodeMirror)',
    () => import('./commands/code-editor').then(m => m.codeEditorCmd)), 'src/commands/code-editor.ts');
  registerCommand(commands, lazyCommand('monaco', 'VS Code editor (Monaco)',
    () => import('./commands/monaco-editor').then(m => m.monacoEditorCmd)), 'src/commands/monaco-editor.ts');
  registerCommand(commands, lazyCommand('mdview', 'Render markdown as formatted HTML',
    () => import('./commands/mdview').then(m => m.mdviewCmd)), 'src/commands/mdview.ts');
  registerCommand(commands, lazyCommand('builder', 'AI app builder (chat + live preview)',
    () => import('./commands/builder').then(m => m.builderCmd)), 'src/commands/builder.ts');
  registerCommand(commands, lazyCommand('ffmpeg', 'Video/audio processing (ffmpeg.wasm)',
    () => import('./commands/ffmpeg').then(m => m.ffmpegCmd)), 'src/commands/ffmpeg.ts');
  registerCommand(commands, lazyCommand('lua', 'Lua 5.4 interpreter (wasmoon)',
    () => import('./commands/lua').then(m => m.luaCmd)), 'src/commands/lua.ts');
  registerCommand(commands, lazyCommand('play', 'Auto-detect and run current project',
    () => import('./commands/play').then(m => m.playCmd)), 'src/commands/play.ts');
  registerCommand(commands, lazyCommand('psql', 'PostgreSQL database (PGlite)',
    () => import('./commands/postgres').then(m => m.psqlCmd)), 'src/commands/postgres.ts');
  registerCommand(commands, lazyCommand('convert', 'ImageMagick image conversion (magick-wasm)',
    () => import('./commands/magick').then(m => m.convertCmd)), 'src/commands/magick.ts');
  registerCommand(commands, lazyCommand('magick', 'ImageMagick (magick-wasm)',
    () => import('./commands/magick').then(m => m.magickCmd)), 'src/commands/magick.ts');
  registerCommand(commands, lazyCommand('wasi', 'Run WASM+WASI binaries',
    () => import('./commands/wasi').then(m => m.wasiCmd)), 'src/commands/wasi.ts');
  registerCommand(commands, lazyCommand('pkg', 'Package manager for WebAssembly programs',
    () => import('./commands/pkg').then(m => m.pkgCmd)), 'src/commands/pkg.ts');
  registerCommand(commands, lazyCommand('apt', 'Package manager (same as pkg)',
    () => import('./commands/pkg').then(m => m.aptCmd)), 'src/commands/pkg.ts');
  registerCommand(commands, lazyCommand('apt-get', 'Package manager (same as pkg)',
    () => import('./commands/pkg').then(m => m.aptGetCmd)), 'src/commands/pkg.ts');
  registerCommand(commands, lazyCommand('debian', 'Install and manage the streamed Debian system',
    () => import('./commands/debian').then(m => m.debianCmd)), 'src/commands/debian.ts');
  registerCommand(commands, lazyCommand('toolchain', 'Install prebuilt compilers and runtimes (C, Python, Node, Java, LaTeX, ...) in seconds',
    () => import('./commands/toolchain').then(m => m.toolchainCmd)), 'src/commands/toolchain.ts');
  registerCommand(commands, lazyCommand('tabcomputer-alternatives', "Choose tabcomputer's or Debian's implementation of a program",
    () => import('./commands/debian').then(m => m.shiroAlternativesCmd)), 'src/commands/debian.ts');
  registerCommand(commands, lazyCommand('shiro-alternatives', 'Old name of tabcomputer-alternatives',
    () => import('./commands/debian').then(m => m.shiroAlternativesCmd)), 'src/commands/debian.ts');
  registerCommand(commands, shiroAptMethodCmd, 'src/commands/debian.ts');
  registerCommand(commands, shiroAptStoreCmd, 'src/commands/debian.ts');
  registerCommand(commands, shiroPreconfigureCmd, 'src/commands/debian.ts');
  registerCommand(commands, shiroAptCmd, 'src/commands/debian.ts');
  registerCommand(commands, sudoCmd, 'src/commands/sudo.ts');
  registerCommand(commands, lazyCommand('xpkg', 'Binary (x86-64) package manager',
    () => import('./commands/xpkg').then(m => m.xpkgCmd)), 'src/commands/xpkg.ts');

  // Compression commands (lazy-loaded)
  registerCommand(commands, lazyCommand('bzip2', 'Compress files (bzip2)',
    () => import('./commands/bzip2').then(m => m.bzip2Cmd)), 'src/commands/bzip2.ts');
  registerCommand(commands, lazyCommand('bunzip2', 'Decompress bzip2 files',
    () => import('./commands/bzip2').then(m => m.bunzip2Cmd)), 'src/commands/bzip2.ts');
  registerCommand(commands, lazyCommand('xz', 'XZ compression (decompress only)',
    () => import('./commands/xz').then(m => m.xzCmd)), 'src/commands/xz.ts');
  registerCommand(commands, lazyCommand('unxz', 'Decompress XZ files',
    () => import('./commands/xz').then(m => m.unxzCmd)), 'src/commands/xz.ts');
  registerCommand(commands, lazyCommand('zstd', 'Zstandard compression (decompress only)',
    () => import('./commands/zstd').then(m => m.zstdCmd)), 'src/commands/zstd.ts');
  registerCommand(commands, lazyCommand('unzstd', 'Decompress Zstandard files',
    () => import('./commands/zstd').then(m => m.unzstdCmd)), 'src/commands/zstd.ts');
  registerCommand(commands, lazyCommand('bzcat', 'Decompress bzip2 files to stdout',
    () => import('./commands/bzip2').then(m => m.bzcatCmd)), 'src/commands/bzip2.ts');
  registerCommand(commands, lazyCommand('xzcat', 'Decompress XZ files to stdout',
    () => import('./commands/xz').then(m => m.xzcatCmd)), 'src/commands/xz.ts');
  registerCommand(commands, lazyCommand('zstdcat', 'Decompress Zstandard files to stdout',
    () => import('./commands/zstd').then(m => m.zstdcatCmd)), 'src/commands/zstd.ts');

  // Web API commands (browser-native, no CDN deps)
  registerCommand(commands, speakCmd, 'src/commands/speak.ts');
  registerCommand(commands, listenCmd, 'src/commands/listen.ts');
  registerCommand(commands, notifyCmd, 'src/commands/notify.ts');
  registerCommand(commands, cameraCmd, 'src/commands/camera.ts');
  registerCommand(commands, cvCmd, 'src/commands/cv.ts');
  registerCommand(commands, spiritCmd, 'src/commands/spirit.ts');

  // TUI commands (lazy-loaded)
  registerCommand(commands, lazyCommand('top', 'Real-time process monitor',
    () => import('./commands/top').then(m => m.topCmd)), 'src/commands/top.ts');
  registerCommand(commands, lazyCommand('man', 'Manual pages',
    () => import('./commands/man').then(m => m.manCmd)), 'src/commands/man.ts');
  registerCommand(commands, lazyCommand('tmux', 'Terminal multiplexer',
    () => import('./commands/tmux').then(m => m.tmuxCmd)), 'src/commands/tmux.ts');
  registerCommand(commands, lazyCommand('systemctl', 'Control the system service manager',
    () => import('./commands/systemctl').then(m => m.systemctlCmd)), 'src/commands/systemctl.ts');
  registerCommand(commands, lazyCommand('crontab', 'Maintain crontab files',
    () => import('./commands/cron').then(m => m.crontabCmd)), 'src/commands/cron.ts');
  registerCommand(commands, lazyCommand('journalctl', 'Query the journal',
    () => import('./commands/cron').then(m => m.journalctlCmd)), 'src/commands/cron.ts');
  registerCommand(commands, lazyCommand('dmesg', 'Print or control the kernel ring buffer',
    () => import('./commands/dmesg').then(m => m.dmesgCmd)), 'src/commands/dmesg.ts');
  registerCommand(commands, lazyCommand('ssh', 'Connect to remote tabcomputer via WebRTC',
    () => import('./commands/ssh').then(m => m.sshCmd)), 'src/commands/ssh.ts');
  registerCommand(commands, lazyCommand('envsubst', 'Substitute environment variables in stdin',
    () => import('./commands/base-utils').then(m => m.envsubstCmd)), 'src/commands/base-utils.ts');
  registerCommand(commands, lazyCommand('groups', 'Print the groups a user is in',
    () => import('./commands/base-utils').then(m => m.groupsCmd)), 'src/commands/base-utils.ts');
  registerCommand(commands, lazyCommand('locale', 'Show locale settings',
    () => import('./commands/base-utils').then(m => m.localeCmd)), 'src/commands/base-utils.ts');
  registerCommand(commands, lazyCommand('getent', 'Get entries from passwd, group, hosts',
    () => import('./commands/base-utils').then(m => m.getentCmd)), 'src/commands/base-utils.ts');
  registerCommand(commands, lazyCommand('nslookup', 'Look up a host name',
    () => import('./commands/base-utils').then(m => m.nslookupCmd)), 'src/commands/base-utils.ts');
  registerCommand(commands, lazyCommand('dig', 'Look up A/AAAA records',
    () => import('./commands/base-utils').then(m => m.digCmd)), 'src/commands/base-utils.ts');
  registerCommand(commands, lazyCommand('flock', 'Run a command holding an advisory lock',
    () => import('./commands/base-utils').then(m => m.flockCmd)), 'src/commands/base-utils.ts');
  registerCommand(commands, lazyCommand('ping', "ICMP isn't available in a browser (try curl)",
    () => import('./commands/base-utils').then(m => m.pingCmd)), 'src/commands/base-utils.ts');
  registerCommand(commands, lazyCommand('strace', "Trace a kernel program's system calls",
    () => import('./commands/base-utils').then(m => m.straceCmd)), 'src/commands/base-utils.ts');
  registerCommand(commands, lazyCommand('ipcs', 'Show System V IPC objects (message queues, shared memory, semaphores)',
    () => import('./commands/ipcs').then(m => m.ipcsCmd)), 'src/commands/ipcs.ts');
  registerCommand(commands, lazyCommand('ipcrm', 'Remove System V IPC objects (by id or key)',
    () => import('./commands/ipcs').then(m => m.ipcrmCmd)), 'src/commands/ipcs.ts');
  registerCommand(commands, safeModeCmd, 'src/commands/safe-mode.ts');
  registerCommand(commands, lazyCommand('doctor', 'Check this tab (deploy, browser, engine, network, sign-ins, storage) for a bug report',
    () => import('./commands/doctor').then(m => m.doctorCmd)), 'src/commands/doctor.ts');
  registerCommand(commands, lazyCommand('tabinfo', 'Same as doctor',
    () => import('./commands/doctor').then(m => m.tabinfoCmd)), 'src/commands/doctor.ts');
  registerCommand(commands, lazyCommand('scp', 'Copy files over WebRTC',
    () => import('./commands/scp').then(m => m.scpCmd)), 'src/commands/scp.ts');

  // Subscribe to hot-reload events to update CommandRegistry
  registry.subscribe((name, newModule, oldModule) => {
    if (name.startsWith('commands/') && newModule) {
      const cmd = newModule as Command;
      commands.register(cmd); // Re-register updates the command
      console.log(`[HotReload] Updated command: ${cmd.name}`);
    }
  });

  // Create PATH shims for builtins so programs can discover them via `which`, `execFile`, etc.
  // This is how an OS advertises its commands — the PATH mechanism, not the builtin registry.
  // PATH shims for builtins, /bin/sh, /usr/bin/env (src/path-shims.ts)
  // In Debian mode (docs/DEBIAN.md) the streamed rootfs's files load on first
  // read, Debian's programs on PATH replace builtins of the same name, and
  // the builtin shims are left out (they'd shadow /usr/bin).
  const debianBoot = import('./debian/rootfs').then(async (m) => {
    const st = await m.bootRootfs(fs);
    if (!st) { void createPathShims(fs).catch(() => {}); return; } // no Debian: nothing for commands to wait for
    await import('./debian/layers').then((l) => l.bootLayers(fs)); // toolchain layers' lazy files
    void installAlwaysShims(fs).catch(() => {}); // xdg-open, xclip, ... on PATH in Debian mode too
    const ov = await import('./debian/overlay');
    await ov.enableDebianShadows(fs, (n) => !!commands.get(n));
    for (const [k, v] of Object.entries(m.DEBIAN_ENV)) shell.env[k] ??= v;
    console.log(`[tabcomputer] Debian ${st.version} (${st.suite}) rootfs ${st.id}`);
  }).catch((e) => { console.warn('[tabcomputer] Debian boot failed:', e); void createPathShims(fs).catch(() => {}); });

  // Create shell
  const shell = new Shell(fs, commands);
  // Commands wait for Debian mode's overlay (Debian's python3, not the builtin, once installed)
  // (at most 30 s: a Debian boot that hangs mustn't hang every command)
  shell.bootGate = bootStep('Debian boot', () => debianBoot, 30000);
  // Kernel processes (worker guests, spawned builtins) run against this fs and fork this shell
  const kernel = getKernel();
  // The page's kernel, for everything that looks it up (getKernel, kernel-diag, watchdog);
  // only the page publishes it (kernel.ts getKernel, #47)
  (window as any).__tabcomputerKernel = kernel;
  kernel.attach(fs, shell);
  installNet(kernel); // socket syscalls (src/kernel/net.ts, docs/NETWORKING.md)
  // kernel.spawn() of an x86-64 ELF runs it in Blink when the page can (src/x86-engine)
  const blinkLoader = import('./x86-engine/blink').then(m => m.registerBlinkLoader(kernel));
  // TABCOMPUTER_NODE_WORKER=1: node the kernel starts (sh -c, #! scripts) runs as a guest
  // (src/node-worker; the rest of it loads only for a process with the flag)
  installNodeWorkerBoot(kernel);
  // Signals and job control for kernel processes; /dev/ptmx and /dev/pts/N
  attachKernelTty(kernel);
  // The kernel's own program hooks, so `hotswap status` can tell later additions (#47)
  void blinkLoader.catch(() => {}).then(() => import('./hotswap/leftovers')).then((m) => m.markKernelBaseline(kernel)).catch(() => {});
  // X11 display :0 (src/x11, docs/GUI.md): `Xshiro :0` listens on /tmp/.X11-unix/X0 now;
  // the server and its fonts load on the first client, windows open on the desktop
  shell.env['DISPLAY'] ??= ':0';
  // Programs that open a web page (Python's webbrowser, git web--browse) find a real tab this way
  shell.env['BROWSER'] ??= 'xdg-open';
  // HiDPI: X apps started from the shell scale like the dock's (src/gui/display-scale.ts)
  for (const [k, v] of Object.entries(toolkitScaleEnv())) shell.env[k] ??= v;
  if (!safe) {
    void startDisplay(kernel, 0).catch(e => console.warn('[Xshiro]', e));
    // GL for X apps (docs/research/GL.md): glshiro listens on /tmp/.tabcomputer-gl/0 for libGLX_tabcomputer
    void startGLServer(kernel).catch(e => console.warn('[glshiro]', e));
  }

  // Populate API keys from localStorage so `claude` CLI picks them up
  const storedAnthropicKey = localStorage.getItem('tabcomputer_anthropic_key') || localStorage.getItem('tabcomputer_api_key');
  if (storedAnthropicKey) shell.env['ANTHROPIC_API_KEY'] = storedAnthropicKey;
  const storedOpenaiKey = localStorage.getItem('tabcomputer_openai_key');
  if (storedOpenaiKey) shell.env['OPENAI_API_KEY'] = storedOpenaiKey;
  const storedGoogleKey = localStorage.getItem('tabcomputer_google_key');
  if (storedGoogleKey) shell.env['GOOGLE_API_KEY'] = storedGoogleKey;
  const storedGithubToken = localStorage.getItem('tabcomputer_github_token');
  if (storedGithubToken) shell.env['GITHUB_TOKEN'] = storedGithubToken;

  // Extra terminals (panes, desktop windows) get fresh shells with this one's env and cwd
  const makeShell = () => {
    const s = new Shell(fs, commands);
    trackInstance(s);
    Object.assign(s.env, shell.env);
    s.cwd = shell.cwd;
    return s;
  };

  // The Unix edition boots a desktop (src/desktop); shiro.computer keeps the
  // full-page terminal (src/ui-mode.ts). The desktop puts #terminal in its
  // first window before the terminal is created, so it measures its real size.
  const container = document.getElementById('terminal')!;
  let desktop: Desktop | null = null;
  if (desktopModule) {
    try {
      const { bootDesktop } = await desktopModule;
      performance.mark('shiro:desktop:start');
      desktop = bootDesktop({ fs, shell, kernel, makeShell, terminalEl: container });
    } catch (e) {
      // A chunk that fails to load leaves the full-page terminal, which always works
      console.error('[tabcomputer] desktop failed to load; using the terminal UI', e);
      document.body.classList.remove('sd-active');
    }
  }
  performance.mark('shiro:desktop:end');
  // /dom: the live page as files (docs/DESKTOP.md)
  installDomFs(fs, kernel, () => desktop?.wm ?? null);

  // Create terminal
  performance.mark('shiro:terminal:start');
  const terminal = new ShiroTerminal(container, shell);
  // The desktop removes the boot mark when it appears (one draw)
  if (!desktop) document.getElementById('boot-mark')?.remove();

  // Connect terminal to shell for interactive commands (vi, etc.)
  shell.setTerminal(terminal);
  fs.onStorageFull((full) => {
    terminal.term.writeln(full
      ? '\r\n\x1b[31mshiro: browser storage is full: writes fail with "No space left on device" until files are deleted (apt clean, rm).\x1b[0m'
      : '\r\n\x1b[32mshiro: storage is no longer full; pending writes are saved.\x1b[0m');
  });
  fs.onStorageLost((lost) => {
    terminal.term.writeln(`\r\n\x1b[31mtabcomputer: browser storage was deleted (${lost.reason}). Files not in memory read as "Input/output error"; new writes stay in memory only. Save files with the banner's button (or copy them out) before reloading. doctor shows it.\x1b[0m`);
  });
  desktop?.attachMainTerminal(terminal);
  // The profile's banner: the desktop sets its compact welcome; 'hud' keeps the full one
  if (profile.banner === 'hud') terminal.banner = undefined;
  // Debian GUI apps (xterm, GTK, Qt) in the dock, installed on first click (src/gui/apps.ts).
  // The desktop appears with them in place (holdReveal): the dock never fills in late
  if (desktop) {
    desktop.holdReveal(import('./gui/desktop-apps').then(m => m.registerGuiApps(desktop!.wm, fs, kernel)).catch(e => console.warn('[gui]', e)));
  }
  performance.mark('shiro:terminal:ready');

  // Listen for font size changes from parent (seed snippet)
  window.addEventListener('message', (e) => {
    if (e.data && e.data.type === 'shiro-fontsize') {
      terminal.term.options.fontSize = e.data.size;
      terminal.fitAddon.fit();
      return;
    }
    if (e.data && e.data.type === 'shiro-focus-terminal') {
      terminal.term.focus();
      setActiveTerminal(terminal);
    }
  });

  // Expose global for test automation and programmatic access
  (window as any).__tabcomputer = {
    fs,
    shell,
    terminal,
    runtimeContext,

    commands,
    registry, // ModuleRegistry for hot-reload
    iframeServer, // Iframe-based virtual HTTP server
    processTable, // Windowed process registry
    kernel, // Process table, fds, pipes and syscalls for worker guests (src/kernel)
    gl: getGLServer, // glshiro (src/gl/server.ts): connections and per-client command and frame counts
    desktop: desktop?.wm ?? null, // Window manager API (docs/DESKTOP.md), null in the classic UI
    uiMode: mode,
    profile, // The product profile (src/profile.ts, docs/PROFILES.md)
    agentResume, // Which agent (claude, codex) each terminal runs, and its resume command (src/agent-resume.ts)
    unbecome: deactivateBecomeMode, // Exit app mode from browser console
    closeSplit: closeSplitView, // Close split pane from browser console
    lastSeedGif: null as Uint8Array | null, // Last generated seed GIF bytes (for demos/drag)
    // Stable handles for hot-swap patches (docs/HOTSWAP.md): never depend on minified names
    hotswap, // applied swaps: .stack, .revert(all?), .confirm(id?)
    live: liveModule, // a live module's namespace by path: live('src/shell.ts')
    esbuild: <T>(fn: (e: typeof import('esbuild-wasm')) => Promise<T>) => import('./commands/build').then(m => m.withEsbuild(fn)),
    Shell, ShiroTerminal, Kernel, FileSystem,
  };
  // (migrateFrom in a swap runs on tracked instances)
  for (const o of [shell, terminal, kernel, fs]) trackInstance(o);

  // OAuth callback bridge: receive auth codes from /oauth/callback popup
  const onOAuthCallback = (event: MessageEvent) => {
    if (event.origin !== getShiroOrigin()) return;
    if (event.data?.type !== 'shiro-oauth-callback') return;
    const { code, state, params } = event.data;
    let port = event.data.port;
    // Extract port from state parameter (setup command encodes it as port_XXXXX_random)
    if (!port && state) {
      const m = state.match(/^port_(\d+)_/);
      if (m) port = m[1];
    }
    if (!port) return;
    // Reconstruct the original callback URL path with query params
    const callbackParams = new URLSearchParams();
    if (code) callbackParams.set('code', code);
    if (state) callbackParams.set('state', state);
    // Forward any extra params the provider sent
    if (params) {
      for (const [k, v] of Object.entries(params)) {
        if (k !== 'port' && !callbackParams.has(k)) callbackParams.set(k, v as string);
      }
    }
    const path = '/oauth/callback?' + callbackParams.toString();
    iframeServer.fetch(parseInt(port, 10), path).catch(() => {});
  };
  window.addEventListener('message', onOAuthCallback);
  // Under COOP the popup loses window.opener after visiting the provider, so
  // the callback page also posts here (same-origin only)
  if (typeof BroadcastChannel !== 'undefined') {
    new BroadcastChannel('shiro-oauth-callback').addEventListener('message', onOAuthCallback);
  }

  // Cleanup iframe servers on page unload (hot reload)
  window.addEventListener('beforeunload', (e) => {
    iframeServer.cleanup();
    // Leaving mid-write (e.g. during npm install) loses the unsaved files
    if (fs.pendingWrites > 0) {
      e.preventDefault();
      e.returnValue = '';
    }
  });

  // Demo mode: lightweight boot for about page iframes
  const isDemo = new URLSearchParams(location.search).get('demo') === '1';

  if (isDemo) {
    // Skip banner, HUD, mobile input, favicon — just show a clean prompt
    terminal.term.options.fontSize = 13;
    terminal.fitAddon.fit();
    // Init drop handler so seed GIF drag-and-drop works in demos
    initDropHandler(terminal, fs);
    // Signal ready
    (window as any).__shiroDemo = true;
    return;
  }

  // Pre-hide terminal if we'll enter become/IDE mode (prevents flash)
  const becomeConfig = safe ? null : getBecomeConfig();
  if (becomeConfig) {
    document.body.classList.add('become-active');
  }

  // Tiling panes: drag a corner triangle of any pane to split it (the desktop has windows and tabs instead)
  if (!desktop && !safe) initPanes(terminal, makeShell);

  // Persisted hot-swaps for this build (src/hotswap/persist.ts), before ~/.profile runs
  let hasPersistedSwaps = false;
  try { hasPersistedSwaps = !!localStorage.getItem('tabcomputer-hotswap-persisted'); } catch { /* no storage */ }
  if (hasPersistedSwaps && !safe && new URLSearchParams(location.search).get('hotswap') !== '0') {
    await bootStep('hotswap', async () => {
      // A load that froze last time is treated like safe mode: the swap may be why
      const wedge = await previousLoadWedge();
      const { restorePersisted, clearPersisted } = await import('./hotswap/persist');
      if (wedge) {
        await clearPersisted();
        console.warn(`hotswap: dropped the persisted swaps: the last load froze for ${Math.round((wedge.seenAt - wedge.since) / 1000)} s`);
        return;
      }
      for (const l of await restorePersisted()) console.warn(l);
    });
  }

  await terminal.start();
  fs.releaseKeyIndex();
  // The prompt is up: the next load of this tab is a normal one
  bootFinished();

  // Check for become mode (app mode) — restore full-screen app if configured
  if (becomeConfig) {
    const pathname = location.pathname.replace(/\/$/, '');
    const params = new URLSearchParams(location.search);

    // ?unbecome escape hatch — clear become config and show terminal
    if (params.has('unbecome')) {
      localStorage.removeItem('tabcomputer-become');
      document.body.classList.remove('become-active');
      history.replaceState({}, '', '/');
    } else if (pathname === '/' + becomeConfig.slug) {
      // Only re-enter become mode on the slug path, NOT on root /
      let startResult: number;
      startResult = await shell.execute(
          `serve "${becomeConfig.directory}" ${becomeConfig.port}`,
          () => {}, () => {},
        );
        if (startResult === 0) {
          await activateBecomeMode(becomeConfig);
        }
      if (startResult !== 0) {
        // Server failed to start — clear become config and show terminal
        localStorage.removeItem('tabcomputer-become');
        document.body.classList.remove('become-active');
        console.warn('[tabcomputer] Become mode: server failed to start, falling back to terminal');
      }
    } else {
      // Pathname doesn't match slug — show terminal (stale config)
      document.body.classList.remove('become-active');
    }
  }

  // Check for shared seed URL: /s/:id
  const seedMatch = safe ? null : location.pathname.match(/^\/s\/([a-z0-9]{4,16})$/);
  if (seedMatch) {
    const seedId = seedMatch[1];
    terminal.term.writeln(`\r\nLoading shared seed ${seedId}...`);
    try {
      const res = await fetch(`/api/seed/${seedId}`);
      if (res.ok) {
        const compressed = new Uint8Array(await res.arrayBuffer());
        const full = await pipeBytes(compressed, new DecompressionStream('gzip'));
        const envelope = JSON.parse(new TextDecoder().decode(full));

        // Hydrate filesystem
        const lines = envelope.ndjson.split('\n');
        const nodes: any[] = [];
        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed) continue;
          const node = JSON.parse(trimmed);
          nodes.push({
            ...node,
            content: node.content ? Uint8Array.from(atob(node.content), (c: string) => c.charCodeAt(0)) : null,
          });
        }
        await fs.importAll(nodes);

        // Restore localStorage
        if (envelope.storage) {
          const storageObj = typeof envelope.storage === 'string' ? JSON.parse(envelope.storage) : envelope.storage;
          for (const [key, value] of Object.entries(storageObj)) {
            localStorage.setItem(key, value as string);
          }
        }

        terminal.term.writeln(`Loaded ${envelope.files} files. Reloading...`);
        // Redirect to root so we don't re-import on reload
        setTimeout(() => { location.href = '/'; }, 500);
        return;
      } else {
        terminal.term.writeln(`Seed not found (${res.status})`);
      }
    } catch (e: any) {
      terminal.term.writeln(`Failed to load seed: ${e.message}`);
    }
  }

  // Check for GitHub import URL: /:user/:repo
  const ghMatch = safe ? null : location.pathname.match(/^\/([a-zA-Z0-9_.-]+)\/([a-zA-Z0-9_.-]+)\/?$/);
  if (ghMatch && !seedMatch) {
    const [, user, repo] = ghMatch;
    // Avoid collision with reserved paths
    const reserved = ['api', 'oauth', 'offer', 'answer', 'git-proxy', 'channel', 'assets'];
    if (!reserved.includes(user.toLowerCase())) {
      const repoUrl = `https://github.com/${user}/${repo}`;
      terminal.term.writeln(`\r\nCloning ${repoUrl}...`);
      const cloneDir = `/home/user/${repo}`;
      shell.execute(
        `git clone ${repoUrl} ${cloneDir} && cd ${cloneDir}`,
        (out: string) => terminal.term.write(out.replace(/\n/g, '\r\n')),
        (err: string) => terminal.term.write(err.replace(/\n/g, '\r\n')),
      ).then(async (code: number) => {
        if (code === 0) {
          shell.cwd = cloneDir;
          terminal.term.writeln(`\r\nCloned to ${cloneDir}`);
          // Auto-detect and run the project
          try {
            const { detectAndRun } = await import('./github-player/index');
            await detectAndRun({
              fs, shell, terminal, dir: cloneDir, repoName: repo, user,
              log: (msg) => terminal.term.writeln('\r\n' + msg),
            });
          } catch (err: any) {
            terminal.term.writeln(`\r\n\x1b[33mAuto-run failed: ${err.message}\x1b[0m`);
          }
        }
        // Replace URL to root so refresh doesn't re-clone
        history.replaceState({}, '', '/');
      });
    }
  }

  // Initialize drag-and-drop seed GIF import
  initDropHandler(terminal, fs);

  // Initialize mobile virtual keys and voice input (the desktop has its own: src/desktop/mobile.ts)
  if (!desktop) initMobileInput(terminal);

  // Initialize dynamic favicon (32x32 minimap of terminal content)
  initFaviconUpdater(terminal.term);

  // Initialize dynamic title (shows recent commands)
  // The desktop titles the tab with the product name (the profile's brand)
  if (!desktop) initTitle();

  // Auto-reconnect remote session if one was active before page reload
  // Skip only if become mode is actually active (not just config in localStorage)
  if (!safe && !document.body.classList.contains('become-active')) {
    // getPersistedRemoteCode() without loading commands/remote unless there is one
    const persistedCode = localStorage.getItem('tabcomputer-remote-code');
    if (persistedCode) {
      void import('./commands/remote').then(m => m.startRemoteWithCode(persistedCode, terminal));
    }
  }

  // Prebuilt packages installed at a build the index marks broken are
  // upgraded in the background (pkg-manager.ts upgradeBrokenPackages)
  setTimeout(() => {
    void import('./pkg-manager').then((m) => m.upgradeBrokenPackages(fs, { env: shell.env, log: (l) => console.log(`[pkg] ${l}`) }))
      .then((names) => { if (names?.length) console.log(`[pkg] upgraded known-broken packages: ${names.join(', ')}`); })
      .catch((e) => console.warn('[pkg] upgrade of known-broken packages failed:', e?.message || e));
  }, 2000);

  // Have Claude Code ready before anyone types `claude` (the profile's preinstall
  // list). Waits a few seconds so the 18 MB tarball download doesn't compete with boot.
  if (!safe && profile.preinstall.includes('claude-code')) setTimeout(() => {
    ensureClaudeCodeInstalled(fs)
      .then(() => console.log('[tabcomputer] Claude Code ready'))
      .catch((e) => console.warn('[tabcomputer] Claude Code background install failed:', e?.message || e));
  }, 3000);
  // The other preinstall names are pkg packages (ca-certificates: the CA bundle
  // native programs' TLS looks for at /etc/ssl/certs/ca-certificates.crt).
  const pkgPreinstall = safe ? [] : profile.preinstall.filter((n) => n !== 'claude-code');
  if (pkgPreinstall.length) setTimeout(() => {
    import('./pkg-manager').then((m) => m.preinstallPackages(fs, pkgPreinstall))
      .then((done) => { if (done.length) console.log(`[tabcomputer] preinstalled ${done.join(', ')}`); })
      .catch((e) => console.warn('[tabcomputer] package preinstall failed:', e?.message || e));
  }, 2000);
}

// Guard: the entry chunk is inlined into HTML AND kept as a file for lazy chunk
// imports. The browser evaluates it twice (inline script ≠ file module). The boot
// flag prevents main() from running a second time when lazy chunks load.
if (!(window as any).__shiroBooted) {
  (window as any).__shiroBooted = true;
  main().catch(console.error);
}
