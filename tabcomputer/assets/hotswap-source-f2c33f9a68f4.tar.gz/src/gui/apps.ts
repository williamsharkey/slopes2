/**
 * GUI apps from Debian, streamed on first use (docs/GUI.md).
 *
 * public/gui/apps.json (scripts/gui/gen-apps.py) lists, per app, the Debian
 * bookworm amd64 packages it needs to start: its ELF closure plus data
 * packages; optional dlopen'ed stacks (Mesa/LLVM, CUPS, ...) are left out.
 * Packages are content addressed by the .deb's sha256 (from Debian's signed
 * index): fetched through the server's /debian/ route, verified, kept in the
 * browser's Cache Storage under that hash (shared by every app, survives a
 * filesystem reset), and unpacked into the root filesystem. dpkg-style
 * triggers (gdk-pixbuf loaders, GSettings schemas, MIME database) then run
 * in Blink like their postinst scripts would. Apps launch as kernel
 * processes (x86-64 ELF in Blink) with DISPLAY=:0.
 */
import type { FileSystem } from '../filesystem';
import type { Kernel } from '../kernel/kernel';
import { untar, type TarEntry } from '../pkg-tar';
import { debEntriesOffThread } from './deb';
import { toolkitScaleEnv } from './display-scale';
export { arMembers, debEntries } from './deb';

export interface DebPackage { version: string; filename: string; sha256: string; size: number }
export interface GuiApp {
  description: string; toolkit: string; bin: string;
  /** The Debian package that provides the app (apt's name for it). */
  pkg?: string;
  packages: string[];
  size: number; closureSize: number; dropped: string[];
  /** Its icon, relative to the page (public/gui/icons/). */
  icon?: string;
  /** Paths deleted after unpacking: optional plug-ins whose libraries were left out. */
  remove?: string[];
  /** [link, target] symlinks a postinst would make (update-alternatives: BLAS, LAPACK; LibreOffice's registry). */
  links?: [string, string][];
  /** Settings written into the user's home (relative path: contents) before a launch, when not there yet */
  home?: Record<string, string>;
  /** Arguments every launch starts with (Audacious's Qt interface is `--qt`) */
  args?: string[];
}
/**
 * A file a postinst would generate, built by gen-apps.py (public/gui/overlay/SHA256), applied when `when` is
 * installed; with `tar`, a tar archive unpacked at `path` (e.g. symlinks).
 */
export interface Overlay { path: string; sha256: string; size: number; when: string; tar?: boolean }
export interface AppsManifest {
  suite: string; arch: string; mirror: string; snapshot: string;
  overlays?: Overlay[];
  /** Per font package, its font directories and the files it puts in each (pinned mtimes: pinFontDirs) */
  fontDirs?: Record<string, Record<string, string[]>>;
  packages: Record<string, DebPackage>;
  apps: Record<string, GuiApp>;
}

export interface InstallProgress {
  phase: 'fetch' | 'unpack' | 'triggers' | 'done';
  pkg?: string;
  done: number;
  total: number;
  bytes: number;
  totalBytes: number;
}

export interface InstallResult {
  app: string;
  packages: number;
  /** packages that were already installed */
  skipped: number;
  /** fetched from the network vs from the browser cache */
  fetched: number;
  cached: number;
  bytes: number;
  /** fetch: waiting for downloaded and decoded packages; unpack: writing their files */
  ms: { total: number; fetch: number; unpack: number; triggers: number };
}

const STATUS = '/var/lib/shiro-gui/status.json';
const CACHE_NAME = 'tabcomputer-debs-v1';
/** Paths not worth unpacking in a browser. */
const SKIP_PATH = /^\/usr\/share\/(doc|man|info|lintian|bug|locale|gtk-doc|help)\//;
const BIN_DIRS = /^\/(usr\/)?s?bin\//;

let manifestOverride: AppsManifest | null = null;
let fetchOverride: ((pkg: DebPackage) => Promise<Uint8Array>) | null = null;

/** Tests: use this manifest / fetcher instead of the network. */
export function configureGuiApps(o: { manifest?: AppsManifest | null; fetchDeb?: ((pkg: DebPackage) => Promise<Uint8Array>) | null }): void {
  if (o.manifest !== undefined) manifestOverride = o.manifest;
  if (o.fetchDeb !== undefined) fetchOverride = o.fetchDeb;
}

let manifestPromise: Promise<AppsManifest> | null = null;

export function guiManifest(): Promise<AppsManifest> {
  if (manifestOverride) return Promise.resolve(manifestOverride);
  manifestPromise ??= fetch(new URL('gui/apps.json', baseUrl()).href).then((r) => {
    if (!r.ok) throw new Error(`gui/apps.json: HTTP ${r.status}`);
    return r.json() as Promise<AppsManifest>;
  });
  manifestPromise.catch(() => { manifestPromise = null; });
  return manifestPromise;
}

function baseUrl(): string {
  if (typeof document !== 'undefined' && document.baseURI) return document.baseURI;
  return (globalThis as { location?: { href: string } }).location?.href ?? 'http://localhost/';
}

interface Status { packages: Record<string, string>; apps: string[] }

async function readStatus(fs: FileSystem): Promise<Status> {
  try { return JSON.parse(await fs.readFile(STATUS, 'utf8') as string) as Status; } catch { return { packages: {}, apps: [] }; }
}

async function writeStatus(fs: FileSystem, s: Status): Promise<void> {
  await fs.mkdir('/var/lib/shiro-gui', { recursive: true });
  await fs.writeFile(STATUS, JSON.stringify(s, null, 1));
}

export async function isAppInstalled(fs: FileSystem, app: string): Promise<boolean> {
  if (await debianMode(fs)) {
    const a = (await guiManifest()).apps[app];
    return !!a && (await fs.exists(`/var/lib/dpkg/info/${a.pkg ?? app}.list`)) && (await fs.exists(a.bin));
  }
  const st = await readStatus(fs);
  return st.apps.includes(app);
}

/**
 * Debian mode (`debian install`, docs/DEBIAN.md): the system is a Debian
 * rootfs managed by dpkg, so apps come from its own apt instead of being
 * unpacked from this manifest (whose bookworm libraries would replace the
 * system's).
 */
export async function debianMode(fs: FileSystem): Promise<boolean> {
  try { return !!(await (await import('../debian/rootfs')).installedRootfs(fs)); } catch { return false; }
}

/** Install with the system's apt (Debian mode); `log` gets apt's output lines. */
async function installWithApt(fs: FileSystem, kernel: Kernel, name: string, app: GuiApp, log: (s: string) => void): Promise<InstallResult> {
  const t0 = Date.now();
  const pkg = app.pkg ?? name;
  const { BufferFile } = await import('../kernel/fd');
  // `sudo` is Shiro's builtin (uid 0 for apt); a bare name reaches it through the kernel's builtin loader
  const run = async (cmd: string) => {
    const out = new BufferFile(null);
    const argv = cmd.split(' ');
    const p = kernel.spawn({ path: argv[0], argv, cwd: '/', env: appEnv({ DEBIAN_FRONTEND: 'noninteractive' }), fds: { 0: new BufferFile(''), 1: out, 2: out } });
    const st = await p.wait();
    for (const line of out.text().split('\n').filter(Boolean).slice(-6)) log(line);
    return st;
  };
  // lists may be empty right after `debian install`
  const hasLists = (await fs.readdir('/var/lib/apt/lists').catch(() => [] as string[])).some((f) => f.endsWith('_Packages'));
  if (!hasLists && await run('sudo apt-get update') !== 0) throw new Error('apt-get update failed');
  if (await run(`sudo apt-get install -y --no-install-recommends ${pkg}`) !== 0) throw new Error(`apt-get install ${pkg} failed`);
  const ms = Date.now() - t0;
  return { app: name, packages: 1, skipped: 0, fetched: 0, cached: 0, bytes: 0, ms: { total: ms, fetch: 0, unpack: ms, triggers: 0 } };
}

// ── fetching ──

async function sha256Hex(b: Uint8Array): Promise<string> {
  const d = new Uint8Array(await crypto.subtle.digest('SHA-256', b as BufferSource));
  return Array.from(d, (x) => x.toString(16).padStart(2, '0')).join('');
}

async function openCache(): Promise<Cache | null> {
  try { return typeof caches !== 'undefined' ? await caches.open(CACHE_NAME) : null; } catch { return null; }
}

/** A .deb by content hash: Cache Storage first, else the server's /debian/ route. */
async function getDeb(p: DebPackage, cache: Cache | null): Promise<{ data: Uint8Array; cached: boolean }> {
  return getBlob(p.sha256, p.size, `debian/${p.filename}`, cache, fetchOverride ? () => fetchOverride!(p) : null);
}

/** Bytes by sha256: Cache Storage, else `url` (or `fetcher`), verified and cached. */
async function getBlob(sha256: string, size: number, url: string, cache: Cache | null, fetcher: (() => Promise<Uint8Array>) | null): Promise<{ data: Uint8Array; cached: boolean }> {
  const p = { sha256, size, filename: url };
  const key = new URL(`sha256/${p.sha256}`, baseUrl()).href;
  if (cache) {
    const hit = await cache.match(key).catch(() => undefined);
    if (hit) {
      const data = new Uint8Array(await hit.arrayBuffer());
      if (data.length === p.size) return { data, cached: true };
    }
  }
  let data: Uint8Array;
  if (fetcher) data = await fetcher();
  else {
    const r = await fetch(new URL(url, baseUrl()).href);
    if (!r.ok) throw new Error(`${p.filename}: HTTP ${r.status}`);
    data = new Uint8Array(await r.arrayBuffer());
  }
  const h = await sha256Hex(data);
  if (h !== p.sha256) throw new Error(`${p.filename}: sha256 mismatch (got ${h})`);
  if (cache) await cache.put(key, new Response(data as BodyInit, { headers: { 'content-type': 'application/vnd.debian.binary-package' } })).catch(() => {});
  return { data, cached: false };
}

// ── unpacking ──

async function unpack(fs: FileSystem, entries: TarEntry[], ownBins: Set<string>): Promise<number> {
  let files = 0;
  for (const e of entries) {
    let path = '/' + e.path.replace(/^\.?\/+/, '').replace(/\/+$/, '');
    if (path === '/' || SKIP_PATH.test(path + '/')) continue;
    // Never replace Shiro's own commands (and their /usr/bin shims) with a library package's helper
    if (BIN_DIRS.test(path) && !ownBins.has(path) && e.type !== 'dir' && (await fs.exists(path).catch(() => false))) continue;
    if (e.type === 'dir') { await fs.mkdir(path, { recursive: true }).catch(() => {}); continue; }
    const dir = path.slice(0, path.lastIndexOf('/')) || '/';
    await fs.mkdir(dir, { recursive: true }).catch(() => {});
    if (e.type === 'symlink') {
      try { await fs.unlink(path); } catch { /* none */ }
      await fs.symlink(e.linkname, path).catch(() => {});
    } else {
      await fs.writeFile(path, e.data, { mode: e.mode & 0o7777 });
    }
    files++;
  }
  return files;
}

// ── triggers ──

/**
 * postinst-like steps: `argv` runs when a package just unpacked put files in
 * `dir`, unless all of them are `covered` (packages whose result ships as an
 * overlay: gen-apps.py).
 */
const TRIGGERS: { dir: string; argv?: string[]; run?: (fs: FileSystem) => Promise<unknown>; covered?: string[] }[] = [
  {
    dir: '/usr/lib/x86_64-linux-gnu/gdk-pixbuf-2.0/2.10.0/loaders/',
    argv: ['/usr/lib/x86_64-linux-gnu/gdk-pixbuf-2.0/gdk-pixbuf-query-loaders', '--update-cache'],
    covered: ['libgdk-pixbuf-2.0-0', 'librsvg2-common'],
  },
  { dir: '/usr/share/glib-2.0/schemas/', argv: ['/usr/bin/glib-compile-schemas', '/usr/share/glib-2.0/schemas'] },
  // gtk-update-icon-cache, written here (icon-cache.ts): without it GTK stats all of hicolor at every start
  { dir: '/usr/share/icons/hicolor/', run: async (fs) => (await import('./icon-cache')).updateIconCache(fs, '/usr/share/icons/hicolor') },
];

/**
 * Fontconfig's caches (shipped as overlays in /var/cache/fontconfig, made by
 * Debian's fontconfig: gen-apps.py) hold the mtime of the font directory they
 * describe, and fontconfig rescans a directory whose mtime differs (~1.9 s of a
 * GTK app's first start). So a font directory gets this fixed mtime, the one
 * the caches were made with, when it holds exactly its package's files; with
 * other files in it (a second package's) it keeps its real mtime and
 * fontconfig rescans it, as it would without the cache.
 */
export const FONT_DIR_MTIME_MS = Date.UTC(2023, 0, 1);

async function pinFontDirs(fs: FileSystem, m: AppsManifest, installed: string[]): Promise<void> {
  for (const pkg of installed) {
    for (const [dir, files] of Object.entries(m.fontDirs?.[pkg] ?? {})) {
      const have = await fs.readdir(dir).catch(() => null);
      if (!have || have.length !== files.length || !files.every((f) => have.includes(f))) continue;
      await fs.utimes(dir, FONT_DIR_MTIME_MS, FONT_DIR_MTIME_MS, { atime: 0, mtime: 0 }).catch(() => {});
    }
  }
}

/** The triggers a package's files set off. */
function triggersOf(pkg: string, entries: TarEntry[]): Set<number> {
  const out = new Set<number>();
  TRIGGERS.forEach((t, i) => {
    if (t.covered?.includes(pkg)) return;
    if (entries.some((e) => e.type !== 'dir' && ('/' + e.path.replace(/^\.?\/+/, '')).startsWith(t.dir))) out.add(i);
  });
  return out;
}

async function runTriggers(fs: FileSystem, kernel: Kernel, which: Set<number>, log: (s: string) => void): Promise<void> {
  // (XDG base directories: apps that mkdir only their own subdirectory need them, like galculator)
  for (const d of ['/var/cache/fontconfig', '/tmp/.X11-unix', '/tmp/runtime-user', '/home/user/.cache', '/home/user/.config', '/home/user/.local/share']) await fs.mkdir(d, { recursive: true }).catch(() => {});
  await fs.chmod('/tmp/runtime-user', 0o700).catch(() => {});
  // independent of each other: each is its own Blink worker
  await Promise.all([...which].map(async (i) => {
    const t = TRIGGERS[i];
    const t0 = Date.now();
    if (t.run) {
      await t.run(fs).then(() => log(`trigger ${t.dir}: ${Date.now() - t0} ms`), (e) => log(`trigger ${t.dir}: ${(e as Error).message}`));
      return;
    }
    if (!t.argv || !(await fs.exists(t.argv[0]).catch(() => false))) return;
    const status = await runQuiet(kernel, t.argv, {});
    log(`trigger ${t.argv[0].split('/').pop()}: status ${status >> 8} in ${Date.now() - t0} ms`);
  }));
}

async function runQuiet(kernel: Kernel, argv: string[], env: Record<string, string>): Promise<number> {
  const { BufferFile } = await import('../kernel/fd');
  const out = new BufferFile(null);
  const p = kernel.spawn({ path: argv[0], argv, cwd: '/', env: { ...appEnv(), ...env }, fds: { 0: new BufferFile(''), 1: out, 2: out } });
  return p.wait();
}

/** Environment GUI apps start with. */
export function appEnv(extra: Record<string, string> = {}): Record<string, string> {
  return {
    ...toolkitScaleEnv(),
    DISPLAY: ':0', HOME: '/home/user', USER: 'user', LANG: 'C.UTF-8', PATH: '/usr/local/bin:/usr/bin:/bin',
    XDG_RUNTIME_DIR: '/tmp/runtime-user', NO_AT_BRIDGE: '1', GTK_A11Y: 'none',
    // no session bus: fail fast instead of GDBus autolaunch
    DBUS_SESSION_BUS_ADDRESS: 'unix:path=/run/no-session-bus',
    // OpenSSL's default CA paths are the openssl package's symlinks (not shipped): use the bundle (an overlay)
    SSL_CERT_FILE: '/etc/ssl/certs/ca-certificates.crt',
    ...extra,
  };
}

/**
 * Per-toolkit environment. Empty since Blink patch 0029 (SSE compares): GTK 3
 * spun after mapping its window before it, with and without the JIT.
 */
export function toolkitEnv(app: GuiApp): Record<string, string> {
  void app;
  return {};
}

// ── install & launch ──

const installing = new Map<string, Promise<InstallResult>>();
const watchers = new Map<string, Set<(p: InstallProgress) => void>>();

/** Install `name` (or join the install in progress); `onProgress` hears it either way. */
export function installApp(fs: FileSystem, kernel: Kernel, name: string, onProgress?: (p: InstallProgress) => void, log: (s: string) => void = () => {}): Promise<InstallResult> {
  const off = onProgress ? watchInstall(name, onProgress) : () => {};
  let p = installing.get(name);
  if (!p) {
    const notify = (pr: InstallProgress) => { for (const cb of watchers.get(name) ?? []) cb(pr); };
    p = doInstall(fs, kernel, name, notify, log).finally(() => installing.delete(name));
    installing.set(name, p);
  }
  return p.finally(off);
}

/** Progress of `name`'s installs (from any caller); returns unsubscribe. */
export function watchInstall(name: string, cb: (p: InstallProgress) => void): () => void {
  let set = watchers.get(name);
  if (!set) watchers.set(name, set = new Set());
  set.add(cb);
  return () => { set.delete(cb); };
}

/** The install of `name` in progress, if any. */
export function installInProgress(name: string): Promise<InstallResult> | undefined {
  return installing.get(name);
}

/** What installing `name` would download now: packages not yet installed, and their size. */
export async function pendingDownload(fs: FileSystem, name: string): Promise<{ packages: number; bytes: number }> {
  const m = await guiManifest();
  const app = m.apps[name];
  if (!app) return { packages: 0, bytes: 0 };
  const status = await readStatus(fs);
  const want = app.packages.filter((n) => status.packages[n] !== m.packages[n].version);
  return { packages: want.length, bytes: want.reduce((a, n) => a + m.packages[n].size, 0) };
}

async function doInstall(fs: FileSystem, kernel: Kernel, name: string, onProgress: ((p: InstallProgress) => void) | undefined, log: (s: string) => void): Promise<InstallResult> {
  const t0 = Date.now();
  const m = await guiManifest();
  const app = m.apps[name];
  if (!app) throw new Error(`no GUI app named ${name}`);
  if (await debianMode(fs)) return installWithApt(fs, kernel, name, app, log);
  const status = await readStatus(fs);
  // largest first: decoding (xz in JavaScript) is the long pole, so the big ones start at once
  const want = app.packages.filter((n) => status.packages[n] !== m.packages[n].version).sort((a, b) => m.packages[b].size - m.packages[a].size);
  const totalBytes = want.reduce((a, n) => a + m.packages[n].size, 0);
  const res: InstallResult = { app: name, packages: app.packages.length, skipped: app.packages.length - want.length, fetched: 0, cached: 0, bytes: 0, ms: { total: 0, fetch: 0, unpack: 0, triggers: 0 } };
  const cache = await openCache();
  const ownBins = new Set([app.bin]);
  const triggers = new Set<number>();
  let done = 0;
  const report = (phase: InstallProgress['phase'], pkg?: string) => onProgress?.({ phase, pkg, done, total: want.length, bytes: res.bytes, totalBytes });
  // Fetch with a few requests in flight and decode each .deb (workers) as it
  // arrives; write the files in that order
  const ready = new Map<string, Promise<{ entries: TarEntry[]; size: number; cached: boolean }>>();
  let next = 0;
  const startMore = () => {
    while (next < want.length && ready.size < 16) {
      const n = want[next++];
      ready.set(n, getDeb(m.packages[n], cache).then(async ({ data, cached }) => ({ size: data.length, cached, entries: await debEntriesOffThread(data) })));
    }
  };
  startMore();
  const overlays = (m.overlays ?? []).filter((o) => want.includes(o.when)).map((o) => [o, getBlob(o.sha256, o.size, `gui/overlay/${o.sha256}`, cache, fetchOverride ? () => fetchOverride!({ version: '', filename: `gui/overlay/${o.sha256}`, sha256: o.sha256, size: o.size }) : null)] as const);
  for (const [, blob] of overlays) blob.catch(() => {}); // awaited after the packages
  for (const n of want) {
    const tw = Date.now();
    const { entries, size, cached } = await ready.get(n)!;
    res.ms.fetch += Date.now() - tw;
    if (cached) res.cached++; else { res.fetched++; res.bytes += size; }
    ready.delete(n);
    startMore();
    report('fetch', n);
    const tu = Date.now();
    await unpack(fs, entries, ownBins);
    for (const i of triggersOf(n, entries)) triggers.add(i);
    res.ms.unpack += Date.now() - tu;
    status.packages[n] = m.packages[n].version;
    done++;
    report('unpack', n);
  }
  for (const path of app.remove ?? []) await fs.rm(path, { recursive: true }).catch(() => {});
  for (const [link, target] of app.links ?? []) {
    if (await fs.exists(link).catch(() => false)) continue;
    await fs.mkdir(link.slice(0, link.lastIndexOf('/')), { recursive: true }).catch(() => {});
    await fs.symlink(target, link).catch(() => {});
  }
  for (const [o, blob] of overlays) {
    const { data } = await blob;
    if (o.tar) { await unpack(fs, untar(data), ownBins); continue; }
    await fs.mkdir(o.path.slice(0, o.path.lastIndexOf('/')), { recursive: true }).catch(() => {});
    await fs.writeFile(o.path, data);
  }
  await pinFontDirs(fs, m, want);
  const tt = Date.now();
  report('triggers');
  await runTriggers(fs, kernel, triggers, log);
  res.ms.triggers = Date.now() - tt;
  if (!status.apps.includes(name)) status.apps.push(name);
  await writeStatus(fs, status);
  res.ms.total = Date.now() - t0;
  report('done');
  (globalThis as { __guiInstall?: InstallResult }).__guiInstall = res;
  return res;
}

/** The text hook for a toolkit (scripts/gui/text-hook/): GTK 2/3 through cairo and GDK, Qt 5 Widgets through QPainter */
const TEXT_HOOKS: Record<string, string> = { gtk2: 'libshiro-text-hook.so', gtk3: 'libshiro-text-hook.so', qt5: 'libshiro-qt-text-hook.so' };

/**
 * DOM-text mode (docs/DOM-RENDERING.md): GTK apps load libshiro-text-hook.so,
 * which tells Xshiro the text they draw (scripts/gui/text-hook/).
 */
const SESSION_BUS = 'unix:path=/tmp/runtime-user/bus';
const buses = new WeakMap<Kernel, Promise<string | null>>();

/**
 * The session bus apps share (Debian's dbus-daemon, the manifest's
 * `dbus-session`), started with the first app: single-instance checks
 * (LXImage-Qt), settings and portals look for one. Its address, or null when
 * it can't run (then apps get the unreachable default and fail fast).
 */
function sessionBus(kernel: Kernel, m: AppsManifest): Promise<string | null> {
  if (!m.apps['dbus-session'] || !kernel.fs) return Promise.resolve(null);
  let p = buses.get(kernel);
  if (!p) {
    p = startSessionBus(kernel, m.apps['dbus-session'].bin).catch(() => null);
    buses.set(kernel, p);
    // gone (or never came up): the next launch tries again
    void p.then((a) => { if (!a) buses.delete(kernel); });
  }
  return p;
}

async function startSessionBus(kernel: Kernel, bin: string): Promise<string | null> {
  const fs = kernel.fs as FileSystem;
  if (!(await isAppInstalled(fs, 'dbus-session'))) await installApp(fs, kernel, 'dbus-session');
  // libdbus needs a machine id
  if (!(await fs.exists('/etc/machine-id').catch(() => false))) {
    const id = Array.from(crypto.getRandomValues(new Uint8Array(16)), (b) => b.toString(16).padStart(2, '0')).join('') + '\n';
    await fs.writeFile('/etc/machine-id', id).catch(() => {});
  }
  await fs.mkdir('/tmp/runtime-user', { recursive: true }).catch(() => {});
  const sock = SESSION_BUS.slice('unix:path='.length);
  if (await fs.exists(sock).catch(() => false)) await fs.unlink(sock).catch(() => {});
  const { BufferFile } = await import('../kernel/fd');
  const p = kernel.spawn({
    path: bin, argv: ['dbus-daemon', '--session', '--nofork', '--nopidfile', `--address=${SESSION_BUS}`], cwd: '/',
    env: appEnv(), fds: { 0: new BufferFile(''), 1: new BufferFile(null), 2: new BufferFile(null) },
  });
  let exited = false;
  void p.wait().then(() => { exited = true; buses.delete(kernel); });
  for (let t = 0; t < 15000 && !exited; t += 100) {
    if (await fs.exists(sock).catch(() => false)) return SESSION_BUS;
    await new Promise((r) => setTimeout(r, 100));
  }
  return null;
}

async function writeHomeDefaults(kernel: Kernel, files: Record<string, string>): Promise<void> {
  const fs = kernel.fs as FileSystem | undefined;
  if (!fs) return;
  for (const [rel, text] of Object.entries(files)) {
    const path = `/home/user/${rel}`;
    if (await fs.exists(path).catch(() => true)) continue;
    await fs.mkdir(path.slice(0, path.lastIndexOf('/')), { recursive: true }).catch(() => {});
    await fs.writeFile(path, text).catch(() => {});
  }
}

async function textHookEnv(kernel: Kernel, app: GuiApp): Promise<Record<string, string>> {
  const name = TEXT_HOOKS[app.toolkit];
  if (!name || !kernel.fs) return {};
  if ((await import('../x11/dom-text')).domTextMode() === 'pixels') return {};
  const path = `/usr/lib/shiro/${name}`;
  return (await shipLib(kernel.fs as FileSystem, name, path)) ? { LD_PRELOAD: path } : {};
}

/** glvnd loads vendor libraries by name from the library path */
const GLX_VENDOR_LIB = 'libGLX_tabcomputer.so.0';

/**
 * Fast GL (docs/research/GL.md): while glshiro serves GL (Xshiro advertises
 * GLX), apps that link libglvnd get its vendor library libGLX_tabcomputer
 * and pick it by name. Otherwise nothing changes: no GLX, Mesa's software
 * paths or none.
 */
export async function glEnv(kernel: Kernel, app: GuiApp): Promise<Record<string, string>> {
  if (!kernel.fs || !(app.packages ?? []).includes('libglx0')) return {};
  const { glxEnabled, GLX_VENDOR_NAME } = await import('../x11/glx');
  if (!glxEnabled()) return {};
  const ok = await shipLib(kernel.fs as FileSystem, GLX_VENDOR_LIB, `/usr/lib/x86_64-linux-gnu/${GLX_VENDOR_LIB}`);
  return ok ? { __GLX_VENDOR_LIBRARY_NAME: GLX_VENDOR_NAME } : {};
}

/** Put one of public/gui/lib/'s libraries at `path` (small, HTTP-cached; rewritten when it changed). True when it's there. */
async function shipLib(fs: FileSystem, name: string, path: string): Promise<boolean> {
  try {
    const r = await fetch(new URL(`gui/lib/${name}`, baseUrl()).href);
    if (!r.ok) return await fs.exists(path).catch(() => false);
    const lib = new Uint8Array(await r.arrayBuffer());
    // not a library (a dev server's index.html for a missing file)
    if (lib[0] !== 0x7f || lib[1] !== 0x45 || lib[2] !== 0x4c || lib[3] !== 0x46) return await fs.exists(path).catch(() => false);
    const have = await fs.readFile(path).catch(() => null) as Uint8Array | null;
    if (!have || have.length !== lib.length || have.some((b, i) => b !== lib[i])) {
      await fs.mkdir(path.slice(0, path.lastIndexOf('/')), { recursive: true }).catch(() => {});
      await fs.writeFile(path, lib, { mode: 0o755 });
    }
  } catch { return false; }
  return true;
}

export interface LaunchedApp { pid: number; exited: Promise<number>; output: () => string }

/** Start an installed app as a background kernel process. */
export async function launchApp(kernel: Kernel, name: string, args: string[] = [], env: Record<string, string> = {}): Promise<LaunchedApp> {
  const m = await guiManifest();
  const app = m.apps[name];
  if (!app) throw new Error(`no GUI app named ${name}`);
  const { BufferFile } = await import('../kernel/fd');
  // its windows belong to this app on the desktop, whatever their WM_CLASS
  const instance = app.bin.split('/').pop()!.toLowerCase().replace(/-\d+(\.\d+)*$/, '');
  const ids = await import('../x11/app-ids');
  if (instance !== name) ids.appIdAliases.set(instance, name);
  ids.setParentPid((pid) => kernel.procs.get(pid)?.ppid);
  if (app.home) await writeHomeDefaults(kernel, app.home);
  const bus = await sessionBus(kernel, m);
  if (bus) env = { DBUS_SESSION_BUS_ADDRESS: bus, ...env };
  const out = new BufferFile(null);
  const p = kernel.spawn({
    // argv[0]: the name for programs on the PATH, the full path for the others (LibreOffice's
    // oosplash finds soffice.bin next to argv[0])
    path: app.bin, argv: [/^\/usr\/(local\/)?s?bin\//.test(app.bin) ? app.bin.split('/').pop()! : app.bin, ...(app.args ?? []), ...args], cwd: '/home/user',
    env: appEnv({ ...toolkitEnv(app), ...(await textHookEnv(kernel, app)), ...(await glEnv(kernel, app)), ...env }), fds: { 0: new BufferFile(''), 1: out, 2: out },
  });
  ids.pidAppIds.set(p.pid, name);
  const launched = { pid: p.pid, exited: p.wait().finally(() => ids.pidAppIds.delete(p.pid)), output: () => out.text() };
  (globalThis as { __guiLast?: LaunchedApp }).__guiLast = launched;
  return launched;
}
