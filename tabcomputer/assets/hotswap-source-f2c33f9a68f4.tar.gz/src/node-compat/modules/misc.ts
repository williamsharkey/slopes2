import { encodeClone, decodeClone } from '../ipc';
import { createReadline } from './readline';
import { asyncContext } from '../async-context';
import { createQuerystringModule } from './querystring';
import { createZlibModule } from './zlib';
import { createAssertModule } from './assert';
import type { CommandContext } from '../../commands/index';

export interface MiscDeps {
  ctx: CommandContext;
  /** The script's own timers (execution.ts), for 'timers' and 'timers/promises' */
  scriptTimers?: { setTimeout: Function; clearTimeout: Function; setInterval: Function; clearInterval: Function; setImmediate: Function; clearImmediate: Function };
  FakeBuffer: any;
  fakeProcess: any;
  fakeConsole: any;
  getBuiltinModule: (name: string) => any;
  fileCache: Map<string, string>;
  moduleCache: Map<string, { exports: any }>;
  requireModule: (id: string, fromDir: string) => any;
  /** Runs a worker_threads Worker's script in its own module context on this thread. */
  startWorker?: (filename: string, options: any, worker: any) => void;
}

export function createMiscModule(name: string, deps: MiscDeps): any | null {
  const { ctx, FakeBuffer, fakeProcess, fakeConsole, getBuiltinModule, fileCache, moduleCache, requireModule } = deps;

  switch (name) {
    case 'buffer':
    case 'node:buffer': return {
      Buffer: FakeBuffer,
      Blob: typeof globalThis.Blob !== 'undefined' ? globalThis.Blob : class Blob { constructor(parts?: any[], opts?: any) {} text() { return Promise.resolve(''); } arrayBuffer() { return Promise.resolve(new ArrayBuffer(0)); } },
      File: typeof globalThis.File !== 'undefined' ? globalThis.File : class File { name = ''; constructor(parts: any[], name: string, opts?: any) { this.name = name; } },
      btoa: typeof globalThis.btoa !== 'undefined' ? globalThis.btoa : (s: string) => s,
      atob: typeof globalThis.atob !== 'undefined' ? globalThis.atob : (s: string) => s,
      constants: { MAX_LENGTH: 2147483647, MAX_STRING_LENGTH: 536870888 },
      kMaxLength: 2147483647,
      SlowBuffer: FakeBuffer,
      isUtf8: (buf: Uint8Array) => { try { new TextDecoder('utf-8', { fatal: true }).decode(buf); return true; } catch { return false; } },
      isAscii: (buf: Uint8Array) => { for (let i = 0; i < buf.length; i++) if (buf[i] > 127) return false; return true; },
    };

    case 'querystring':
    case 'node:querystring': return createQuerystringModule();

    case 'string_decoder':
    case 'node:string_decoder': {
      class StringDecoder {
        encoding: string;
        constructor(encoding = 'utf8') { this.encoding = encoding; }
        write(buf: any): string { return new TextDecoder(this.encoding).decode(buf instanceof Uint8Array ? buf : new Uint8Array(buf)); }
        end(buf?: any): string { return buf ? this.write(buf) : ''; }
      }
      return { StringDecoder };
    }

    case 'constants':
    case 'node:constants': return {
      O_RDONLY: 0, O_WRONLY: 1, O_RDWR: 2, O_CREAT: 64, O_EXCL: 128,
      O_TRUNC: 512, O_APPEND: 1024, O_DIRECTORY: 65536, O_NOFOLLOW: 131072,
      S_IFMT: 61440, S_IFREG: 32768, S_IFDIR: 16384, S_IFLNK: 40960,
      S_IRWXU: 448, S_IRUSR: 256, S_IWUSR: 128, S_IXUSR: 64,
      S_IRWXG: 56, S_IRGRP: 32, S_IWGRP: 16, S_IXGRP: 8,
      S_IRWXO: 7, S_IROTH: 4, S_IWOTH: 2, S_IXOTH: 1,
      SIGINT: 2, SIGTERM: 15, SIGKILL: 9,
    };

    case 'tty':
    case 'node:tty': return {
      // (per fd, as the shell set them up: `node x.js 2> f` has fd 1 on the tty, not fd 2)
      isatty: (fd?: number) => !!ctx.terminal && (fd === 0 ? ctx.stdinIsTTY !== false : fd === 1 ? ctx.stdoutIsTTY !== false : fd === 2 ? ctx.stderrIsTTY !== false : false),
      ReadStream: class ReadStream { constructor() {} setRawMode() { return this; } isTTY = !!ctx.terminal; },
      WriteStream: class WriteStream {
        isTTY = !!ctx.terminal;
        get columns() { return ctx.terminal ? ctx.terminal.getSize().cols : 80; }
        get rows() { return ctx.terminal ? ctx.terminal.getSize().rows : 24; }
        getColorDepth() { return ctx.terminal ? 24 : 1; }
        hasColors(count?: number) { return ctx.terminal ? (count ? count <= 16777216 : true) : false; }
        getWindowSize() { return [this.columns, this.rows]; }
        cursorTo() {}
        moveCursor() {}
        clearLine() {}
        clearScreenDown() {}
        write(data: any) { fakeProcess.stdout.write(typeof data === 'string' ? data : String(data)); }
      },
    };

    case 'zlib':
    case 'node:zlib': return createZlibModule(getBuiltinModule);

    case 'dns':
    case 'node:dns':
    case 'dns/promises':
    case 'node:dns/promises': {
      const dnsModule: any = {
        lookup: (hostname: string, opts: any, cb?: Function) => {
          if (typeof opts === 'function') { cb = opts; opts = {}; }
          cb?.(null, '127.0.0.1', 4);
        },
        resolve: (hostname: string, rrtype: any, cb?: Function) => {
          if (typeof rrtype === 'function') { cb = rrtype; rrtype = 'A'; }
          cb?.(null, ['127.0.0.1']);
        },
        resolve4: (hostname: string, cb: Function) => cb(null, ['127.0.0.1']),
        resolve6: (hostname: string, cb: Function) => cb(null, ['::1']),
        setServers: () => {},
        getServers: () => ['8.8.8.8'],
      };
      dnsModule.promises = {
        lookup: async (hostname: string) => ({ address: '127.0.0.1', family: 4 }),
        resolve: async (hostname: string) => ['127.0.0.1'],
        resolve4: async (hostname: string) => ['127.0.0.1'],
        resolve6: async (hostname: string) => ['::1'],
        setServers: () => {},
        getServers: () => ['8.8.8.8'],
      };
      return name.endsWith('/promises') ? dnsModule.promises : dnsModule;
    }

    case 'perf_hooks':
    case 'node:perf_hooks': return {
      performance: typeof performance !== 'undefined' ? performance : {
        now: () => Date.now(),
        timeOrigin: Date.now(),
        mark: () => {},
        measure: () => {},
        getEntries: () => [],
        getEntriesByName: () => [],
        getEntriesByType: () => [],
        clearMarks: () => {},
        clearMeasures: () => {},
      },
      PerformanceObserver: class PerformanceObserver {
        constructor(cb: Function) {}
        observe() {}
        disconnect() {}
      },
      monitorEventLoopDelay: () => ({
        enable: () => {},
        disable: () => {},
        percentile: () => 0,
        min: 0, max: 0, mean: 0, stddev: 0,
      }),
    };

    case 'timers':
    case 'node:timers': {
      // (the script's own: cancelled with it, as the setTimeout it calls by name)
      const t = deps.scriptTimers;
      if (t) return { setTimeout: t.setTimeout, setInterval: t.setInterval, setImmediate: t.setImmediate, clearTimeout: t.clearTimeout, clearInterval: t.clearInterval, clearImmediate: t.clearImmediate };
      return {
        setTimeout, setInterval, setImmediate: (fn: Function, ...args: any[]) => setTimeout(fn, 0, ...args),
        clearTimeout, clearInterval, clearImmediate: clearTimeout,
      };
    }

    case 'timers/promises':
    case 'node:timers/promises': {
      const st = (deps.scriptTimers?.setTimeout ?? globalThis.setTimeout) as (fn: () => void, ms?: number) => unknown;
      return {
        setTimeout: (ms: number, value?: any) => new Promise(resolve => st(() => resolve(value), ms)),
        setInterval: async function*(ms: number, value?: any) { while (true) { await new Promise<void>(r => st(r, ms)); yield value; } },
        setImmediate: (value?: any) => new Promise(resolve => st(() => resolve(value), 0)),
        scheduler: { wait: (ms: number) => new Promise<void>(r => st(r, ms)), yield: () => new Promise<void>(r => st(r, 0)) },
      };
    }

    case 'module':
    case 'node:module': {
      // As node's, the module is the Module class itself, its helpers static on it
      // (`new (require('module'))(id)`: the esm package's loader); createRequire delegates to our require
      class Module {
        id: string;
        exports: any = {};
        parent: any;
        filename: string | null = null;
        loaded = false;
        children: any[] = [];
        paths: string[] = [];
        constructor(id = '', parent?: any) { this.id = id; this.parent = parent; }
      }
      const modExport: any = Object.assign(Module, {
        // A real require for the file (a path or file: URL), resolving from its directory
        createRequire: (from: any) => {
          let f = String(from instanceof URL ? from.href : from);
          if (f.startsWith('file://')) f = decodeURIComponent(f.slice(7));
          const dir = f.endsWith('/') ? f.slice(0, -1) || '/' : f.substring(0, f.lastIndexOf('/')) || '/';
          const mk = (requireModule as any).makeRequire;
          if (mk) return mk(dir);
          const fakeReq: any = (id: string) => requireModule(id, dir);
          fakeReq.resolve = (id: string) => id;
          fakeReq.cache = (requireModule as any).cache ?? moduleCache;
          return fakeReq;
        },
        // The node_modules directories searched from a directory (pnpm's bin linking)
        _nodeModulePaths: (from: string) => {
          const out: string[] = [];
          let d = String(from).replace(/\/+$/, '') || '/';
          for (;;) {
            const base = d.slice(d.lastIndexOf('/') + 1);
            if (base !== 'node_modules') out.push(`${d === '/' ? '' : d}/node_modules`);
            if (d === '/' || !d) break;
            d = d.substring(0, d.lastIndexOf('/')) || '/';
          }
          return out;
        },
        builtinModules: [
          'assert', 'assert/strict', 'async_hooks', 'buffer', 'child_process', 'constants', 'crypto',
          'diagnostics_channel', 'dns', 'dns/promises', 'events', 'fs', 'fs/promises', 'http', 'https',
          'module', 'net', 'os', 'path', 'perf_hooks', 'process', 'querystring',
          'readline', 'stream', 'stream/consumers', 'stream/promises', 'stream/web', 'string_decoder', 'timers', 'timers/promises', 'tls',
          'tty', 'url', 'util', 'v8', 'wasi', 'worker_threads', 'zlib',
        ],
        isBuiltin: (name: string) => {
          const clean = name.startsWith('node:') ? name.slice(5) : name;
          return modExport.builtinModules.includes(clean);
        },
        _resolveFilename: (request: string, parent?: any) => {
          const mk = (requireModule as any).makeRequire;
          if (!mk) return request;
          const f = parent?.filename || parent?.id;
          const dir = typeof f === 'string' && f.startsWith('/') ? f.substring(0, f.lastIndexOf('/')) || '/' : ctx.cwd;
          return mk(dir).resolve(request);
        },
        _cache: (requireModule as any).cache ?? moduleCache,
        _extensions: (requireModule as any).extensions ?? {},
        Module,
      });
      return modExport;
    }

    case 'process':
    case 'node:process':
      return fakeProcess;

    case 'path/posix':
    case 'node:path/posix': return getBuiltinModule('path');

    case 'path/win32':
    case 'node:path/win32': return getBuiltinModule('path');

    case 'async_hooks':
    case 'node:async_hooks': {
      // AsyncLocalStorage: context propagation for async operations
      // Stores live in the page's async context (async-context.ts), carried across awaits
      class AsyncLocalStorage {
        private _enabled = true;
        constructor() { asyncContext.activate(); }
        /** A function that runs `fn` in the stores in effect now (Next's prerender) */
        static snapshot() {
          const frame = asyncContext.capture();
          return (fn: Function, ...args: any[]) => asyncContext.inFrame(frame, () => fn(...args));
        }
        /** `fn` bound to the stores in effect now */
        static bind(fn: Function) {
          const frame = asyncContext.capture();
          return function (this: unknown, ...args: any[]) { return asyncContext.inFrame(frame, () => fn.apply(this, args)); };
        }
        getStore() { return this._enabled ? asyncContext.get(this) : undefined; }
        run(store: any, fn: Function, ...args: any[]) { this._enabled = true; return asyncContext.with(this, store, () => fn(...args)); }
        enterWith(store: any) { this._enabled = true; asyncContext.enter(this, store); }
        disable() { this._enabled = false; }
        exit(fn: Function, ...args: any[]) { return asyncContext.with(this, undefined, () => fn(...args), true); }
      }
      // (the stores in effect where it was made are the ones its scope runs in)
      class AsyncResource {
        type: string;
        private _frame = asyncContext.capture();
        constructor(type: string) { this.type = type; }
        runInAsyncScope(fn: Function, thisArg?: any, ...args: any[]) { return asyncContext.inFrame(this._frame, () => fn.apply(thisArg, args)); }
        emitDestroy() { return this; }
        asyncId() { return 0; }
        triggerAsyncId() { return 0; }
        bind(fn: Function, thisArg?: any) {
          const self = this;
          return function (this: unknown, ...args: any[]) { return self.runInAsyncScope(fn, thisArg ?? this, ...args); };
        }
        static bind(fn: Function, type?: string, thisArg?: any) { return new AsyncResource(type ?? 'bound-anonymous-fn').bind(fn, thisArg); }
      }
      return {
        AsyncLocalStorage,
        AsyncResource,
        createHook: () => ({ enable: () => {}, disable: () => {} }),
        executionAsyncId: () => 0,
        triggerAsyncId: () => 0,
        executionAsyncResource: () => ({}),
      };
    }

    case 'worker_threads':
    case 'node:worker_threads': {
      // EventEmitter mixin for Worker/MessagePort
      function makeEmitter(obj: any) {
        const _events: Record<string, Function[]> = {};
        obj.on = (ev: string, fn: Function) => { (_events[ev] ??= []).push(fn); return obj; };
        obj.once = (ev: string, fn: Function) => {
          const wrapped = (...args: any[]) => { obj.off(ev, wrapped); fn(...args); };
          return obj.on(ev, wrapped);
        };
        obj.off = (ev: string, fn: Function) => { _events[ev] = (_events[ev] || []).filter(f => f !== fn); return obj; };
        obj.addListener = obj.on;
        obj.removeListener = obj.off;
        obj.removeAllListeners = (ev?: string) => { if (ev) delete _events[ev]; else Object.keys(_events).forEach(k => delete _events[k]); return obj; };
        obj.emit = (ev: string, ...args: any[]) => { (_events[ev] || []).forEach(f => { try { f(...args); } catch {} }); return !!(_events[ev]?.length); };
        obj.listeners = (ev: string) => [...(_events[ev] || [])];
        obj.listenerCount = (ev: string) => (_events[ev] || []).length;
        obj.eventNames = () => Object.keys(_events).filter(k => _events[k].length > 0);
        return obj;
      }

      class MessagePort {
        constructor() { makeEmitter(this); }
        postMessage(_value: any, _transferList?: any[]) {}
        start() {}
        close() { (this as any).emit('close'); }
        ref() { return this; }
        unref() { return this; }
        // EventEmitter methods added by makeEmitter
        on!: (ev: string, fn: Function) => this;
        once!: (ev: string, fn: Function) => this;
        off!: (ev: string, fn: Function) => this;
        addListener!: (ev: string, fn: Function) => this;
        removeListener!: (ev: string, fn: Function) => this;
        removeAllListeners!: (ev?: string) => this;
        emit!: (ev: string, ...args: any[]) => boolean;
      }

      class MessageChannel {
        port1: MessagePort;
        port2: MessagePort;
        constructor() {
          this.port1 = new MessagePort();
          this.port2 = new MessagePort();
        }
      }

      /**
       * worker.stdout / worker.stderr: what the worker writes, with { stdout: true } /
       * { stderr: true } (else it goes to this process's own). A readable's surface:
       * 'data', pipe()/unpipe() (vitest 4's threads pool pipes them to its logger), 'end'
       */
      function workerStream(owner: any) {
        const s: any = makeEmitter({ readable: true });
        const piped = new Map<any, Function>();
        s._push = (chunk: Uint8Array) => { const b = deps.FakeBuffer.from(chunk); s.emit('data', s._enc ? b.toString(s._enc) : b); };
        s._end = () => { if (s.readable) { s.readable = false; s.emit('end'); s.emit('close'); } };
        s.setEncoding = (enc: string) => { s._enc = enc; return s; };
        s.pipe = (dest: any) => {
          if (!dest || piped.has(dest)) return dest;
          const onData = (d: unknown) => { dest.write?.(d); };
          piped.set(dest, onData);
          s.on('data', onData);
          return dest;
        };
        s.unpipe = (dest?: any) => {
          for (const [d, f] of [...piped]) if (!dest || d === dest) { s.off('data', f); piped.delete(d); }
          return s;
        };
        s.pause = s.resume = s.read = () => s;
        s.destroy = () => { s._end(); return s; };
        s[Symbol.asyncIterator] = async function* () {
          const q: unknown[] = []; let done = false; let wake: (() => void) | null = null;
          s.on('data', (d: unknown) => { q.push(d); wake?.(); });
          s.on('end', () => { done = true; wake?.(); });
          while (!done || q.length) { if (q.length) yield q.shift(); else await new Promise<void>((r) => { wake = r; }); wake = null; }
        };
        owner.on('exit', () => s._end());
        return s;
      }

      let nextThreadId = 1;
      class Worker {
        threadId = nextThreadId++;
        resourceLimits = {};
        _toWorker?: (value: any) => void;
        _terminate?: () => void;
        _exited = false;
        stdout: any;
        stderr: any;
        stdin: null = null;
        constructor(filename: string | URL, options?: any) {
          makeEmitter(this);
          this.stdout = workerStream(this);
          this.stderr = workerStream(this);
          if (deps.startWorker) {
            deps.startWorker(String(filename), options ?? {}, this);
            return;
          }
          // No way to run it: only emit error if someone is listening; exit(1) for graceful degradation
          setTimeout(() => {
            if ((this as any).listenerCount('error') > 0) {
              (this as any).emit('error', new Error('Worker threads not supported in browser'));
            }
            (this as any).emit('exit', 1);
          }, 0);
        }
        postMessage(value: any, _transferList?: any[]) { this._toWorker?.(value); }
        terminate(): Promise<number> {
          this._terminate?.();
          if (!this._exited) { this._exited = true; (this as any).emit('exit', 0); }
          return Promise.resolve(0);
        }
        ref() { return this; }
        unref() { return this; }
        getHeapSnapshot() { return Promise.resolve({}); }
        // EventEmitter methods added by makeEmitter
        on!: (ev: string, fn: Function) => this;
        once!: (ev: string, fn: Function) => this;
        off!: (ev: string, fn: Function) => this;
        addListener!: (ev: string, fn: Function) => this;
        removeListener!: (ev: string, fn: Function) => this;
        removeAllListeners!: (ev?: string) => this;
        emit!: (ev: string, ...args: any[]) => boolean;
        listenerCount!: (ev: string) => number;
      }

      class BroadcastChannel {
        name: string;
        constructor(name: string) { this.name = name; makeEmitter(this); }
        postMessage(_msg: any) {}
        close() {}
        on!: (ev: string, fn: Function) => this;
        off!: (ev: string, fn: Function) => this;
      }

      const envData = new Map<string, any>();

      return {
        isMainThread: true,
        parentPort: null,
        workerData: null,
        _makeEmitter: makeEmitter,
        threadId: 0,
        resourceLimits: {},
        SHARE_ENV: Symbol('SHARE_ENV'),
        Worker,
        MessageChannel,
        MessagePort,
        BroadcastChannel,
        markAsUntransferable: (_obj: any) => {},
        moveMessagePortToContext: (port: any, _ctx: any) => port,
        receiveMessageOnPort: (_port: any) => undefined,
        setEnvironmentData: (key: any, value: any) => { envData.set(key, value); },
        getEnvironmentData: (key: any) => envData.get(key),
      };
    }

    case 'readline':
    case 'node:readline': return {
      cursorTo: (stream: any, x: number, y?: number | Function, cb?: Function) => {
        if (stream?.write) {
          let seq = `\x1b[${x + 1}G`;
          if (typeof y === 'number') seq = `\x1b[${y + 1};${x + 1}H`;
          stream.write(seq);
        }
        if (typeof y === 'function') y(); else if (cb) cb();
        return true;
      },
      clearLine: (stream: any, dir: number, cb?: Function) => {
        if (stream?.write) {
          stream.write(dir === -1 ? '\x1b[1K' : dir === 1 ? '\x1b[0K' : '\x1b[2K');
        }
        if (cb) cb();
        return true;
      },
      moveCursor: (stream: any, dx: number, dy: number, cb?: Function) => {
        if (stream?.write) {
          let seq = '';
          if (dx > 0) seq += `\x1b[${dx}C`;
          else if (dx < 0) seq += `\x1b[${-dx}D`;
          if (dy > 0) seq += `\x1b[${dy}B`;
          else if (dy < 0) seq += `\x1b[${-dy}A`;
          if (seq) stream.write(seq);
        }
        if (cb) cb();
        return true;
      },
      clearScreenDown: (stream: any, cb?: Function) => {
        if (stream?.write) stream.write('\x1b[J');
        if (cb) cb();
        return true;
      },
      // a real line reader on the input stream (readline.ts)
      ...(() => { const rl = createReadline(false); return { createInterface: rl.createInterface, Interface: rl.Interface }; })(),
      promises: createReadline(true),
      emitKeypressEvents: (stream: any) => {
        // ink calls this to enable keypress events on stdin
        // Parse raw input into keypress events, handling ANSI escape sequences
        if (stream && stream.on && !stream._keypressListenerAdded) {
          stream._keypressListenerAdded = true;
          let escBuf = '';
          stream.on('data', (data: any) => {
            const str = typeof data === 'string' ? data : new TextDecoder().decode(data);
            let i = 0;
            while (i < str.length) {
              const ch = str[i];
              const code = ch.charCodeAt(0);
              const key: any = { sequence: '', name: '', ctrl: false, meta: false, shift: false };
              if (code === 0x1b && i + 1 < str.length) {
                // Escape sequence
                const next = str[i + 1];
                if (next === '[') {
                  // CSI sequence: \x1b[...
                  let seq = '\x1b[';
                  i += 2;
                  while (i < str.length && str.charCodeAt(i) >= 0x20 && str.charCodeAt(i) <= 0x3f) { seq += str[i]; i++; }
                  if (i < str.length) { seq += str[i]; i++; }
                  key.sequence = seq;
                  const final = seq[seq.length - 1];
                  const params = seq.slice(2, -1);
                  if (final === 'A') key.name = 'up';
                  else if (final === 'B') key.name = 'down';
                  else if (final === 'C') key.name = 'right';
                  else if (final === 'D') key.name = 'left';
                  else if (final === 'H') key.name = 'home';
                  else if (final === 'F') key.name = 'end';
                  else if (final === 'Z') { key.name = 'tab'; key.shift = true; }
                  else if (final === '~') {
                    if (params === '3') key.name = 'delete';
                    else if (params === '5') key.name = 'pageup';
                    else if (params === '6') key.name = 'pagedown';
                    else if (params === '2') key.name = 'insert';
                    else key.name = 'undefined';
                  }
                  else key.name = 'undefined';
                  if (params.includes(';')) {
                    const mod = parseInt(params.split(';')[1]) - 1;
                    if (mod & 1) key.shift = true;
                    if (mod & 2) key.meta = true;
                    if (mod & 4) key.ctrl = true;
                  }
                } else if (next === 'O') {
                  // SS3 sequence: \x1bO... (function keys)
                  i += 2;
                  const fk = i < str.length ? str[i++] : '';
                  key.sequence = '\x1bO' + fk;
                  if (fk === 'P') key.name = 'f1';
                  else if (fk === 'Q') key.name = 'f2';
                  else if (fk === 'R') key.name = 'f3';
                  else if (fk === 'S') key.name = 'f4';
                  else key.name = 'undefined';
                } else {
                  // Alt+key
                  key.sequence = '\x1b' + next;
                  key.name = next.toLowerCase();
                  key.meta = true;
                  i += 2;
                }
              } else {
                key.sequence = ch;
                i++;
                if (code === 13) key.name = 'return';
                else if (code === 10) key.name = 'return';
                else if (code === 127) key.name = 'backspace';
                else if (code === 8) key.name = 'backspace';
                else if (code === 9) key.name = 'tab';
                else if (code === 32) key.name = 'space';
                else if (code < 27) { key.name = String.fromCharCode(code + 96); key.ctrl = true; }
                else key.name = ch.toLowerCase();
              }
              stream.emit('keypress', key.sequence, key);
            }
          });
        }
      },
    };

    case 'readline/promises':
    case 'node:readline/promises': {
      const rlp: any = createReadline(true);
      return rlp;
    }

    case 'diagnostics_channel':
    case 'node:diagnostics_channel': return {
      channel: (name: string) => ({ subscribe: () => {}, unsubscribe: () => {}, hasSubscribers: false }),
      hasSubscribers: () => false,
      subscribe: () => {},
      unsubscribe: () => {},
      Channel: class Channel { subscribe() {} unsubscribe() {} hasSubscribers = false; },
    };

    case 'v8':
    case 'node:v8': return {
      // Structured clone, as node's (Map, Set, Date, BigInt, typed arrays, cycles: ipc.ts's encoding),
      // after a "V" (plain JSON, the old form, still reads back). jest's haste-map cache holds
      // Maps: as JSON they came back as objects, and every run after the first failed
      serialize: (v: any) => new Uint8Array(new TextEncoder().encode('V' + JSON.stringify(encodeClone(v)))),
      deserialize: (b: any) => {
        const t = new TextDecoder().decode(b);
        return t.startsWith('V') ? decodeClone(JSON.parse(t.slice(1))) : JSON.parse(t);
      },
      getHeapStatistics: () => ({ total_heap_size: 0, used_heap_size: 0, heap_size_limit: 0 }),
      setFlagsFromString: () => {},
    };

    case 'assert':
    case 'node:assert':
      return createAssertModule((v) => getBuiltinModule('util').inspect(v)).assert;
    case 'assert/strict':
    case 'node:assert/strict':
      return getBuiltinModule('assert').strict; // one module: the same AssertionError

    case 'console':
    case 'node:console': {
      return { Console: fakeConsole.Console, default: fakeConsole.Console };
    }

    case 'util/types':
    case 'node:util/types': return (getBuiltinModule('util') as any).types;

    case 'inspector':
    case 'node:inspector': return {
      open: () => {},
      close: () => {},
      url: () => undefined,
      Session: class InspectorSession {
        connect() {}
        disconnect() {}
        post(_method: string, _params: any, cb?: Function) { cb?.(null); }
        on() { return this; }
      },
    };

    case 'vm':
    case 'node:vm': {
      const VM_CONTEXT_SYMBOL = Symbol.for('__isVMContext');

      function createContext(sandbox?: any): any {
        if (!sandbox) sandbox = {};
        Object.defineProperty(sandbox, VM_CONTEXT_SYMBOL, { value: true, enumerable: false, configurable: false });
        // The context is the script's global object: `globalThis` is the context
        // (Next's client-reference manifests assign globalThis.__RSC_MANIFEST
        // in runInNewContext and read it back from it)
        const selfNames = new Set(['globalThis']);
        return new Proxy(sandbox, {
          get(target, prop, receiver) {
            if (prop in target) return Reflect.get(target, prop, receiver);
            if (typeof prop === 'string' && selfNames.has(prop)) return receiver;
            if (typeof prop === 'string' && prop in globalThis) return (globalThis as any)[prop];
            return undefined;
          },
          has(target, prop) {
            return prop in target || prop in globalThis;
          },
          set(target, prop, value) { target[prop] = value; return true; },
        });
      }

      function isContext(obj: any): boolean {
        if (!obj || typeof obj !== 'object') return false;
        return obj[VM_CONTEXT_SYMBOL] === true;
      }

      // Script class wraps new Function for running code in contexts
      class Script {
        private _code: string;
        private _options: any;
        constructor(code: string, options?: any) {
          this._code = code;
          this._options = options || {};
        }
        runInThisContext(options?: any): any {
          // The global scope, and the value of the last expression, as node:
          // webpack's executeModule takes the function `(function (…) {…})` evaluates to
          const filename = options?.filename ?? this._options.filename;
          const code = filename ? `${this._code}\n//# sourceURL=${String(filename).replace(/\s/g, '%20')}` : this._code;
          return (0, eval)(code);
        }
        runInNewContext(sandbox?: any, options?: any): any {
          return this.runInContext(createContext(sandbox), options);
        }
        runInContext(context?: any, options?: any): any {
          if (!context) return this.runInThisContext(options);
          if (!isContext(context)) context = createContext(context);
          // Names resolve on the context first (reads and writes of its
          // properties, globalThis included), then the page's globals; the
          // value is the last expression's, as node's
          // The with-scope is the context's names except `eval` and this function's own: a context
          // with an `eval` of its own (jest's environment copies the host's globals onto it, and
          // node-compat's globalThis.eval isn't the intrinsic) made the eval below indirect, so the
          // code ran outside the context: `process is not defined` in every jest test file
          const ctx = context;
          const scope = new Proxy(ctx, {
            has: (t, p) => p !== 'eval' && p !== '__shiro_ctx' && p !== '__shiro_code' && Reflect.has(t, p),
            get: (t, p) => Reflect.get(t, p),
            set: (t, p, v) => Reflect.set(t, p, v),
          });
          const run = new Function('__shiro_ctx', '__shiro_code', 'with (__shiro_ctx) { return eval(__shiro_code); }');
          try {
            return run.call(ctx, scope, this._code);
          } catch (e) {
            // (a top-level `return`, which node refuses, has run as a function body here)
            if (!(e instanceof SyntaxError) || !/Illegal return/.test(e.message)) throw e;
            return new Function('__shiro_ctx', `with (__shiro_ctx) { return (function () {\n${this._code}\n}).call(this); }`).call(ctx, scope);
          }
        }
      }

      function createScript(code: string, options?: any): Script {
        return new Script(code, options);
      }
      function runInThisContext(code: string, options?: any): any {
        return new Script(code, options).runInThisContext(options);
      }
      function runInNewContext(code: string, sandbox?: any, options?: any): any {
        return new Script(code, options).runInNewContext(sandbox, options);
      }
      function runInContext(code: string, context: any, options?: any): any {
        return new Script(code, options).runInContext(context, options);
      }
      function compileFunction(code: string, params?: string[], options?: any): Function {
        const context = options?.parsingContext;
        if (context) {
          const ctxKeys = Object.keys(context);
          const ctxVals = ctxKeys.map(k => context[k]);
          const inner = new Function(...ctxKeys, ...(params || []), code);
          const bound = (...args: any[]) => inner(...ctxVals, ...args);
          return bound;
        }
        return new Function(...(params || []), code);
      }
      return {
        Script,
        createContext,
        createScript,
        runInThisContext,
        runInNewContext,
        runInContext,
        compileFunction,
        isContext,
      };
    }

    default: return null;
  }
}
