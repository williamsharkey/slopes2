// Iframe-Based Virtual Server
// Replaces service worker approach for better compatibility with:
// - file:// protocol (no service worker support)
// - linkedom (server-side DOM testing)
// - Simpler architecture (no MessageChannel, no SW lifecycle)

import { bytePipe, type ByteChannel } from './byte-pipe';
import { withPageTimers } from './node-compat/page-globals';
import { previewStreamsScript, installStreamProxy } from './preview-streams';

export interface VirtualRequest {
  method: string;
  path: string;
  headers?: Record<string, string>;
  /** Bytes from a preview's fetch/XHR (preview-streams.ts) */
  body?: string | Uint8Array | null;
  query?: Record<string, string>;
}

export interface VirtualResponse {
  status?: number;
  statusText?: string;
  headers?: Record<string, string>;
  /** A ReadableStream is a response still being written (server-sent events, flushHeaders) */
  body?: string | Uint8Array | ReadableStream<Uint8Array> | object;
  contentType?: string;
}

export type RequestHandler = (req: VirtualRequest) => Promise<VirtualResponse> | VirtualResponse;
/** Takes a raw connection to the port (a WebSocket upgrade starts with its HTTP request) */
export type ConnectHandler = (conn: ByteChannel) => void;

interface RegisteredServer {
  port: number;
  handler: RequestHandler;
  connect?: ConnectHandler;
  name?: string;
  iframe?: HTMLIFrameElement;
  resourceInterceptorScript?: string;
  navigationScript?: string;
}

/**
 * IframeServer - A virtual server that renders content in iframes
 *
 * Unlike service workers, this approach:
 * - Works on file:// protocol
 * - Has no caching issues
 * - Is compatible with linkedom for testing
 * - Supports immediate cleanup (just remove the iframe)
 */
class IframeServerManager {
  private servers: Map<number, RegisteredServer> = new Map();
  private defaultContainer: HTMLElement | null = null;
  private resourceProxySetup = false;
  private portListeners = new Set<(port: number, up: boolean) => void>();

  /** Called when a server starts (up) or stops on a port; returns an unsubscribe */
  onPortChange(cb: (port: number, up: boolean) => void): () => void {
    this.portListeners.add(cb);
    return () => { this.portListeners.delete(cb); };
  }
  private emitPort(port: number, up: boolean): void {
    // (page code: its timers aren't the in-page node script's that listened, when one did)
    withPageTimers(() => { for (const cb of this.portListeners) { try { cb(port, up); } catch {} } });
  }

  /**
   * Set the default container where iframes will be spawned
   */
  setDefaultContainer(container: HTMLElement): void {
    this.defaultContainer = container;
  }

  /**
   * Register a server handler on a virtual port
   */
  serve(port: number, handler: RequestHandler, name?: string, opts?: { connect?: ConnectHandler }): () => void {
    if (this.servers.has(port)) {
      throw new Error(`Port ${port} already in use`);
    }

    this.servers.set(port, { port, handler, name, connect: opts?.connect });
    console.log(`[IframeServer] Server "${name || 'unnamed'}" listening on port ${port}`);
    this.emitPort(port, true);

    // Return cleanup function
    return () => this.close(port);
  }

  /**
   * A raw connection to the server on `port` (what a WebSocket upgrade needs):
   * the caller's end of a byte pipe whose other end the server takes.
   */
  connect(port: number): ByteChannel {
    const server = this.servers.get(port);
    if (!server) throw new Error(`ECONNREFUSED: no server listening on port ${port}`);
    if (!server.connect) throw new Error(`ECONNREFUSED: the server on port ${port} takes no connections`);
    const [mine, theirs] = bytePipe();
    server.connect(theirs);
    return mine;
  }

  /**
   * Fetch content from a virtual server
   */
  async fetch(port: number, path: string = '/', options?: Partial<VirtualRequest>): Promise<VirtualResponse> {
    const server = this.servers.get(port);
    if (!server) {
      return { status: 404, body: `No server listening on port ${port}` };
    }

    // Strip hash fragment and parse query string from path
    const hashIndex = path.indexOf('#');
    const pathWithoutHash = hashIndex >= 0 ? path.substring(0, hashIndex) : path;
    let pathname = pathWithoutHash;
    let query: Record<string, string> = {};
    const queryIndex = pathWithoutHash.indexOf('?');
    if (queryIndex >= 0) {
      pathname = pathWithoutHash.substring(0, queryIndex);
      const params = new URLSearchParams(pathWithoutHash.substring(queryIndex + 1));
      params.forEach((value, key) => {
        query[key] = value;
      });
    }

    // Every HTTP/1.1 request names its host; a browser's fetch (a preview, the
    // service worker's) can't set it. vite 6+ refuses requests whose Host it
    // doesn't allow ("This host (undefined) is not allowed": Astro's dev server)
    const headers: Record<string, string> = { ...(options?.headers || {}) };
    if (!Object.keys(headers).some((k) => k.toLowerCase() === 'host')) headers.host = `localhost:${port}`;
    const request: VirtualRequest = {
      method: options?.method || 'GET',
      path: pathname,
      headers,
      body: options?.body || null,
      query,
    };

    try {
      return await server.handler(request);
    } catch (err) {
      return {
        status: 500,
        body: err instanceof Error ? err.message : 'Internal server error',
      };
    }
  }

  /**
   * Create an iframe that displays content from a virtual server
   *
   * @param port - Virtual port to connect to
   * @param container - Where to append the iframe (uses default if not specified)
   * @param options - Iframe configuration options
   */
  async createIframe(
    port: number,
    container?: HTMLElement,
    options?: {
      path?: string;
      width?: string;
      height?: string;
      style?: Partial<CSSStyleDeclaration>;
    }
  ): Promise<HTMLIFrameElement> {
    const targetContainer = container || this.defaultContainer;
    if (!targetContainer) {
      throw new Error('No container specified and no default container set');
    }

    const server = this.servers.get(port);
    if (!server) {
      throw new Error(`No server listening on port ${port}`);
    }

    // Fetch the content
    const path = options?.path || '/';
    const response = await this.fetch(port, path);

    // Create iframe
    const iframe = document.createElement('iframe');
    iframe.setAttribute('data-virtual-port', String(port));
    iframe.setAttribute('data-virtual-path', path);

    // Apply styles
    iframe.style.border = 'none';
    iframe.style.background = '#fff';
    iframe.style.width = options?.width || '100%';
    iframe.style.height = options?.height || '400px';
    // iOS Safari requires explicit visibility styles for iframes to render
    iframe.style.visibility = 'visible';
    iframe.style.opacity = '1';
    iframe.style.display = 'block';
    if (options?.style) {
      Object.assign(iframe.style, options.style);
    }

    // Convert response body to HTML string
    let html: string;
    if (typeof response.body === 'string') {
      html = response.body;
    } else if (response.body instanceof Uint8Array) {
      html = new TextDecoder().decode(response.body);
    } else if (response.body && typeof response.body === 'object') {
      // JSON response - wrap in HTML
      html = `<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>JSON</title></head>
<body><pre>${JSON.stringify(response.body, null, 2)}</pre></body>
</html>`;
    } else {
      html = '<!DOCTYPE html><html><body></body></html>';
    }

    // Setup resource proxy listener (once per page)
    this.ensureResourceProxy();

    // Resource interceptor script - MUST run first to catch resource loads
    // This intercepts fetch, XHR, and dynamically added script/link/img tags
    const resourceInterceptorScript = `
<script>
(function() {
  var PORT = ${port};
  var pendingResources = new Map();
  var resourceId = 0;

  // Listen for resource responses from parent
  window.addEventListener('message', function(e) {
    if (e.data && e.data.type === 'vfs-resource-response' && e.data.id) {
      var pending = pendingResources.get(e.data.id);
      if (pending) {
        pendingResources.delete(e.data.id);
        pending.resolve(e.data);
      }
    }
  });

  // Request resource from parent
  function fetchFromParent(url, options) {
    return new Promise(function(resolve, reject) {
      var id = 'res_' + (++resourceId);
      pendingResources.set(id, { resolve: resolve, reject: reject });
      window.parent.postMessage({
        type: 'vfs-fetch',
        id: id,
        port: PORT,
        url: url,
        method: (options && options.method) || 'GET',
        headers: options && options.headers,
        body: options && options.body
      }, '*');
      // Timeout after 30s
      setTimeout(function() {
        if (pendingResources.has(id)) {
          pendingResources.delete(id);
          reject(new Error('Resource fetch timeout: ' + url));
        }
      }, 30000);
    });
  }

  // Override fetch
  var originalFetch = window.fetch;
  window.fetch = function(url, options) {
    var urlStr = typeof url === 'string' ? url : url.toString();
    if (urlStr.startsWith('/') || urlStr.startsWith('./') || urlStr.startsWith('../')) {
      return fetchFromParent(urlStr, options).then(function(data) {
        return new Response(data.body, {
          status: data.status || 200,
          headers: data.headers || {}
        });
      });
    }
    return originalFetch.apply(this, arguments);
  };

  // Override XMLHttpRequest
  var OrigXHR = window.XMLHttpRequest;
  window.XMLHttpRequest = function() {
    var xhr = new OrigXHR();
    var openArgs = null;
    var origOpen = xhr.open;
    xhr.open = function(method, url) {
      openArgs = { method: method, url: url };
      if (url.startsWith('/') || url.startsWith('./') || url.startsWith('../')) {
        // Will intercept in send()
      }
      return origOpen.apply(xhr, arguments);
    };
    var origSend = xhr.send;
    xhr.send = function(body) {
      if (openArgs && (openArgs.url.startsWith('/') || openArgs.url.startsWith('./') || openArgs.url.startsWith('../'))) {
        fetchFromParent(openArgs.url, { method: openArgs.method, body: body }).then(function(data) {
          Object.defineProperty(xhr, 'status', { value: data.status || 200 });
          Object.defineProperty(xhr, 'responseText', { value: data.body || '' });
          Object.defineProperty(xhr, 'response', { value: data.body || '' });
          Object.defineProperty(xhr, 'readyState', { value: 4 });
          if (xhr.onload) xhr.onload();
          if (xhr.onreadystatechange) xhr.onreadystatechange();
        }).catch(function(err) {
          if (xhr.onerror) xhr.onerror(err);
        });
        return;
      }
      return origSend.apply(xhr, arguments);
    };
    return xhr;
  };

  // Intercept dynamically added elements
  function loadResourceViaParent(el, attr, type) {
    var url = el.getAttribute(attr);
    if (!url || url.startsWith('data:') || url.startsWith('blob:') || url.startsWith('http://') || url.startsWith('https://')) {
      return;
    }
    el.removeAttribute(attr);
    fetchFromParent(url, { method: 'GET' }).then(function(data) {
      if (type === 'css') {
        var style = document.createElement('style');
        style.textContent = data.body || '';
        el.parentNode.replaceChild(style, el);
      } else if (type === 'js') {
        el.textContent = data.body || '';
      } else if (type === 'img') {
        el.src = 'data:image/png;base64,' + btoa(data.body || '');
      }
    }).catch(function(err) {
      console.error('Failed to load resource:', url, err);
    });
  }

  // MutationObserver for dynamic elements
  var observer = new MutationObserver(function(mutations) {
    mutations.forEach(function(m) {
      m.addedNodes.forEach(function(node) {
        if (node.nodeType !== 1) return;
        if (node.tagName === 'SCRIPT' && node.src) loadResourceViaParent(node, 'src', 'js');
        if (node.tagName === 'LINK' && node.rel === 'stylesheet') loadResourceViaParent(node, 'href', 'css');
        if (node.tagName === 'IMG' && node.src) loadResourceViaParent(node, 'src', 'img');
      });
    });
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });

  // Load deferred resources (converted from href/src to data-vfs-href/data-vfs-src)
  function loadDeferredResources() {
    // Load deferred stylesheets
    document.querySelectorAll('link[data-vfs-href]').forEach(function(link) {
      var href = link.getAttribute('data-vfs-href');
      link.removeAttribute('data-vfs-href');
      fetchFromParent(href, { method: 'GET' }).then(function(data) {
        var style = document.createElement('style');
        style.textContent = data.body || '';
        link.parentNode.replaceChild(style, link);
      }).catch(function(err) {
        console.error('Failed to load stylesheet:', href, err);
      });
    });

    // Load deferred scripts
    document.querySelectorAll('script[data-vfs-src]').forEach(function(script) {
      var src = script.getAttribute('data-vfs-src');
      script.removeAttribute('data-vfs-src');
      fetchFromParent(src, { method: 'GET' }).then(function(data) {
        var newScript = document.createElement('script');
        newScript.textContent = data.body || '';
        script.parentNode.replaceChild(newScript, script);
      }).catch(function(err) {
        console.error('Failed to load script:', src, err);
      });
    });

    // Recursively resolve ES module imports and convert to blob URLs
    var blobCache = {};  // Cache: original path -> blob URL
    var pendingModules = {};  // Prevent circular dependency infinite loops

    function resolveModulePath(base, relative) {
      if (relative.startsWith('/')) return relative;
      var baseParts = base.split('/').slice(0, -1);
      var relParts = relative.split('/');
      for (var i = 0; i < relParts.length; i++) {
        if (relParts[i] === '..') baseParts.pop();
        else if (relParts[i] !== '.') baseParts.push(relParts[i]);
      }
      return '/' + baseParts.filter(Boolean).join('/');
    }

    function extractImports(code) {
      var imports = [];
      // Match: import ... from "..." or import ... from '...'
      // Also match: import "..." or import '...' (side-effect imports)
      // Also match: export ... from "..."
      // Capture paths starting with ./ ../ or / (but not http:// https://)
      var regex = /(?:import|export)\\s+(?:[^'"]*\\s+from\\s+)?['"]([^'"]+)['"]|import\\s*\\(\\s*['"]([^'"]+)['"]\\s*\\)/g;
      var match;
      while ((match = regex.exec(code)) !== null) {
        var path = match[1] || match[2];
        if (path && (path.startsWith('./') || path.startsWith('../') || (path.startsWith('/') && !path.startsWith('//')))) {
          imports.push(path);
        }
      }
      return imports;
    }

    function loadModuleRecursive(modulePath) {
      // Return cached blob URL if available
      if (blobCache[modulePath]) {
        return Promise.resolve(blobCache[modulePath]);
      }
      // Prevent circular dependencies
      if (pendingModules[modulePath]) {
        return pendingModules[modulePath];
      }

      var promise = fetchFromParent(modulePath, { method: 'GET' }).then(function(data) {
        var code = data.body || '';
        var imports = extractImports(code);

        if (imports.length === 0) {
          // No imports - just create blob URL
          var blob = new Blob([code], { type: 'application/javascript' });
          var blobUrl = URL.createObjectURL(blob);
          blobCache[modulePath] = blobUrl;
          return blobUrl;
        }

        // Recursively resolve all imports
        var importPromises = imports.map(function(imp) {
          var resolvedPath = resolveModulePath(modulePath, imp);
          return loadModuleRecursive(resolvedPath).then(function(blobUrl) {
            return { original: imp, blobUrl: blobUrl };
          });
        });

        return Promise.all(importPromises).then(function(resolved) {
          // Rewrite imports to use blob URLs via simple string replacement
          var rewrittenCode = code;
          resolved.forEach(function(r) {
            // Replace both single and double quoted versions
            rewrittenCode = rewrittenCode.split('"' + r.original + '"').join('"' + r.blobUrl + '"');
            rewrittenCode = rewrittenCode.split("'" + r.original + "'").join("'" + r.blobUrl + "'");
          });

          var blob = new Blob([rewrittenCode], { type: 'application/javascript' });
          var blobUrl = URL.createObjectURL(blob);
          blobCache[modulePath] = blobUrl;
          return blobUrl;
        });
      });

      pendingModules[modulePath] = promise;
      return promise;
    }

    // Load deferred ES module scripts using recursive blob URL resolution
    document.querySelectorAll('script[data-vfs-module-src]').forEach(function(script) {
      var src = script.getAttribute('data-vfs-module-src');
      script.removeAttribute('data-vfs-module-src');
      loadModuleRecursive(src).then(function(blobUrl) {
        var newScript = document.createElement('script');
        newScript.type = 'module';
        newScript.src = blobUrl;
        script.parentNode.replaceChild(newScript, script);
      }).catch(function(err) {
        console.error('Failed to load module:', src, err);
      });
    });
  }

  // Run when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', loadDeferredResources);
  } else {
    loadDeferredResources();
  }
})();
</script>`;

    // Navigation helper script (end of body) — includes reload listener + link/form interception
    const navigationScript = `
<script>
(function() {
  // Auto-reload: listen for shiro-reload from parent (build --watch)
  window.addEventListener('message', function(e) {
    if (e.data && e.data.type === 'shiro-reload') {
      location.reload();
    }
  });

  // Intercept link clicks for virtual navigation
  document.addEventListener('click', function(e) {
    const link = e.target.closest('a[href]');
    if (link && link.href) {
      const href = link.getAttribute('href');
      // Only intercept relative and same-origin links
      if (href && !href.startsWith('http://') && !href.startsWith('https://') && !href.startsWith('//')) {
        e.preventDefault();
        window.parent.postMessage({
          type: 'virtual-navigate',
          port: ${port},
          path: href
        }, '*');
      }
    }
  });

  // Intercept form submissions
  document.addEventListener('submit', function(e) {
    const form = e.target;
    if (form.tagName === 'FORM') {
      e.preventDefault();
      const formData = new FormData(form);
      const data = {};
      formData.forEach((value, key) => data[key] = value);
      window.parent.postMessage({
        type: 'virtual-submit',
        port: ${port},
        path: form.getAttribute('action') || '/',
        method: form.method || 'GET',
        data: data
      }, '*');
    }
  });
})();
</script>
`;

    // Cache scripts for navigateIframe to reuse
    server.resourceInterceptorScript = resourceInterceptorScript;
    server.navigationScript = navigationScript;

    // Process HTML: rewrite resource URLs, inject interceptor + navigation scripts
    html = this.prepareHtmlForIframe(html, resourceInterceptorScript, navigationScript, port);

    // Use srcdoc for same-origin access
    iframe.srcdoc = html;

    // Track the iframe
    server.iframe = iframe;

    // Append to container
    targetContainer.appendChild(iframe);

    // Set up message listener for navigation
    const messageHandler = async (event: MessageEvent) => {
      if (event.source !== iframe.contentWindow) return;

      if (event.data?.type === 'virtual-navigate' && event.data?.port === port) {
        await this.navigateIframe(port, event.data.path);
      } else if (event.data?.type === 'virtual-submit' && event.data?.port === port) {
        // Handle form submission
        const formResponse = await this.fetch(port, event.data.path, {
          method: event.data.method,
          body: JSON.stringify(event.data.data),
        });
        // Reload iframe with response
        if (typeof formResponse.body === 'string') {
          let responseHtml = formResponse.body;
          if (responseHtml.includes('</body>')) {
            responseHtml = responseHtml.replace('</body>', navigationScript + '</body>');
          }
          iframe.srcdoc = responseHtml;
        }
      }
    };

    window.addEventListener('message', messageHandler);

    // Store cleanup handler
    (iframe as any)._messageHandler = messageHandler;

    return iframe;
  }

  /**
   * Process HTML for display in a virtual server iframe.
   * Rewrites resource URLs, injects resource interceptor and navigation scripts.
   */
  private prepareHtmlForIframe(html: string, resourceInterceptorScript: string, navigationScript: string, port?: number): string {
    // WebSocket, EventSource and streamed fetch/XHR to the in-tab servers (preview-streams.ts)
    if (port !== undefined) resourceInterceptorScript += previewStreamsScript(port);
    // Rewrite relative href/src to data-vfs-* so the browser doesn't try to load them directly
    html = html.replace(/<link([^>]*)\shref=(["'])([^"']+)\2/gi, (match, attrs, quote, href) => {
      if (href.startsWith('/') || href.startsWith('./') || href.startsWith('../')) {
        return `<link${attrs} data-vfs-href=${quote}${href}${quote}`;
      }
      return match;
    });
    html = html.replace(/<script([^>]*)\ssrc=(["'])([^"']+)\2/gi, (match, attrs, quote, src) => {
      if (src.startsWith('/') || src.startsWith('./') || src.startsWith('../')) {
        if (attrs.includes('type="module"') || attrs.includes("type='module'")) {
          return `<script${attrs} data-vfs-module-src=${quote}${src}${quote}`;
        }
        return `<script${attrs} data-vfs-src=${quote}${src}${quote}`;
      }
      return match;
    });

    // Inject resource interceptor at START of head
    if (html.includes('<head>')) {
      html = html.replace('<head>', '<head>' + resourceInterceptorScript);
    } else if (html.includes('<html>')) {
      html = html.replace('<html>', '<html><head>' + resourceInterceptorScript + '</head>');
    } else {
      html = resourceInterceptorScript + html;
    }

    // Inject navigation script before closing body/html tag
    if (html.includes('</body>')) {
      html = html.replace('</body>', navigationScript + '</body>');
    } else if (html.includes('</html>')) {
      html = html.replace('</html>', navigationScript + '</html>');
    } else {
      html += navigationScript;
    }

    return html;
  }

  /**
   * Navigate an existing iframe to a new path
   */
  async navigateIframe(port: number, path: string): Promise<void> {
    const server = this.servers.get(port);
    if (!server?.iframe) {
      throw new Error(`No iframe for port ${port}`);
    }
    // A service-worker preview (preview-sw-host.ts) is a document at a URL
    if (server.iframe.hasAttribute('data-preview-sw')) {
      const { previewUrl } = await import('./preview-sw-host');
      const url = await previewUrl(port, path);
      if (url) { server.iframe.setAttribute('data-virtual-path', path); server.iframe.src = url; return; }
    }

    const response = await this.fetch(port, path);
    let html: string;

    if (typeof response.body === 'string') {
      html = response.body;
    } else if (response.body instanceof Uint8Array) {
      html = new TextDecoder().decode(response.body);
    } else {
      html = `<pre>${JSON.stringify(response.body, null, 2)}</pre>`;
    }

    // Process HTML with cached resource proxy + navigation scripts
    if (server.resourceInterceptorScript && server.navigationScript) {
      html = this.prepareHtmlForIframe(html, server.resourceInterceptorScript, server.navigationScript, port);
    }

    // Update iframe path attribute
    server.iframe.setAttribute('data-virtual-path', path);
    server.iframe.srcdoc = html;
  }

  /**
   * Broadcast a reload message to served iframes.
   * If port is given, only reload that port's iframe; otherwise reload all.
   */
  broadcastReload(port?: number): void {
    const targets = port !== undefined
      ? [this.servers.get(port)].filter(Boolean)
      : Array.from(this.servers.values());
    for (const server of targets) {
      if (server?.iframe?.contentWindow && server.iframe.hasAttribute('data-preview-sw')) {
        try { server.iframe.contentWindow.location.reload(); } catch { /* navigated away */ }
      } else if (server?.iframe?.contentWindow) {
        server.iframe.contentWindow.postMessage({ type: 'shiro-reload' }, '*');
      }
    }
  }

  /**
   * Close a server and remove its iframe
   */
  close(port: number): void {
    const server = this.servers.get(port);
    if (server) {
      // Remove message handler
      if (server.iframe) {
        const handler = (server.iframe as any)._messageHandler;
        if (handler) {
          window.removeEventListener('message', handler);
        }
        server.iframe.remove();
      }

      this.servers.delete(port);
      console.log(`[IframeServer] Server on port ${port} closed`);
      this.emitPort(port, false);
    }
  }

  /**
   * List all active servers
   */
  list(): { port: number; name?: string; hasIframe: boolean }[] {
    return Array.from(this.servers.values()).map(s => ({
      port: s.port,
      name: s.name,
      hasIframe: !!s.iframe,
    }));
  }

  /**
   * Check if a port is in use
   */
  isPortInUse(port: number): boolean {
    return this.servers.has(port);
  }

  /**
   * Setup the resource proxy message listener (called once)
   * This handles vfs-fetch messages from iframes and serves resources from the virtual server
   */
  ensureResourceProxy(): void {
    if (this.resourceProxySetup) return;
    this.resourceProxySetup = true;
    installStreamProxy(this);

    window.addEventListener('message', async (event: MessageEvent) => {
      if (event.data?.type !== 'vfs-fetch') return;

      const { id, port, url, method, headers, body } = event.data;
      const source = event.source as Window;

      try {
        // Fetch from the virtual server
        const response = await this.fetch(port, url, {
          method: method || 'GET',
          headers: headers || {},
          body: body || null,
        });

        // Convert response body to string
        let responseBody: string;
        if (typeof response.body === 'string') {
          responseBody = response.body;
        } else if (response.body instanceof Uint8Array) {
          responseBody = new TextDecoder().decode(response.body);
        } else if (response.body instanceof ReadableStream) {
          responseBody = await new Response(response.body).text();
        } else if (response.body) {
          responseBody = JSON.stringify(response.body);
        } else {
          responseBody = '';
        }

        // Send response back to iframe
        source.postMessage({
          type: 'vfs-resource-response',
          id: id,
          status: response.status || 200,
          headers: response.headers || {},
          body: responseBody,
        }, '*');

      } catch (err) {
        // Send error response
        source.postMessage({
          type: 'vfs-resource-response',
          id: id,
          status: 500,
          body: `Error fetching resource: ${err}`,
        }, '*');
      }
    });

    console.log('[IframeServer] Resource proxy enabled');
  }

  /**
   * Get server info for a port
   */
  getServer(port: number): RegisteredServer | undefined {
    return this.servers.get(port);
  }

  /**
   * Clean up all servers
   */
  cleanup(): void {
    console.log('[IframeServer] cleanup() called, closing', this.servers.size, 'servers');
    for (const [port] of this.servers) {
      this.close(port);
    }
    console.log('[IframeServer] All servers cleaned up');
  }
}

// Singleton instance — reuse window global to survive Vite chunk duplication.
// When iframe-server.ts appears in both the main bundle and a lazy chunk,
// both evaluations share the same IframeServerManager via the window global.
export const iframeServer: IframeServerManager =
  (typeof window !== 'undefined' && (window as any).__iframeServer?.serve)
    ? (window as any).__iframeServer
    : new IframeServerManager();

/**
 * Create a static file server from the virtual filesystem
 *
 * @param fs - FileSystem instance
 * @param rootDir - Root directory to serve from
 * @param options - Server options
 */
export function createStaticServer(
  fs: { readFile: (path: string) => Promise<Uint8Array | string>; stat: (path: string) => Promise<{ isDirectory(): boolean } | null> },
  rootDir: string,
  options?: {
    index?: string[];  // Default index files to look for
    mimeTypes?: Record<string, string>;
  }
): RequestHandler {
  const indexFiles = options?.index || ['index.html', 'index.htm'];
  const defaultMimeTypes: Record<string, string> = {
    '.html': 'text/html',
    '.htm': 'text/html',
    '.css': 'text/css',
    '.js': 'text/javascript',
    '.mjs': 'text/javascript',
    '.json': 'application/json',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.gif': 'image/gif',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon',
    '.woff': 'font/woff',
    '.woff2': 'font/woff2',
    '.ttf': 'font/ttf',
    '.txt': 'text/plain',
    '.md': 'text/markdown',
    ...options?.mimeTypes,
  };

  return async (req: VirtualRequest): Promise<VirtualResponse> => {
    let filePath = rootDir + (req.path === '/' ? '' : req.path);

    // Check if path is a directory
    try {
      const stat = await fs.stat(filePath);
      if (stat?.isDirectory()) {
        // Try index files
        for (const index of indexFiles) {
          const indexPath = filePath + (filePath.endsWith('/') ? '' : '/') + index;
          try {
            const indexStat = await fs.stat(indexPath);
            if (indexStat && !indexStat.isDirectory()) {
              filePath = indexPath;
              break;
            }
          } catch {
            // Index file doesn't exist, continue
          }
        }
      }
    } catch {
      // Path doesn't exist
    }

    // Try extensionless HTML fallback (e.g. /auth → /auth.html)
    const lastSegment = filePath.substring(filePath.lastIndexOf('/') + 1);
    if (!lastSegment.includes('.')) {
      try {
        const htmlPath = filePath + '.html';
        const htmlStat = await fs.stat(htmlPath);
        if (htmlStat && !htmlStat.isDirectory()) {
          filePath = htmlPath;
        }
      } catch { /* no .html fallback */ }
    }

    try {
      const content = await fs.readFile(filePath);

      // Determine content type
      const ext = filePath.substring(filePath.lastIndexOf('.'));
      const contentType = defaultMimeTypes[ext] || 'application/octet-stream';

      return {
        status: 200,
        contentType,
        headers: { 'Content-Type': contentType },
        body: content,
      };
    } catch (err) {
      return {
        status: 404,
        contentType: 'text/html',
        body: `<!DOCTYPE html>
<html>
<head><title>404 Not Found</title></head>
<body>
<h1>404 Not Found</h1>
<p>The requested path "${req.path}" was not found.</p>
</body>
</html>`,
      };
    }
  };
}

/**
 * Express-like router for virtual servers
 */
export function createRouter() {
  const routes: {
    method: string;
    pattern: RegExp;
    keys: string[];
    handler: (req: VirtualRequest & { params: Record<string, string> }) => Promise<VirtualResponse> | VirtualResponse;
  }[] = [];

  function addRoute(method: string, path: string, handler: typeof routes[0]['handler']) {
    // Convert Express-style path to regex
    const keys: string[] = [];
    const pattern = new RegExp(
      '^' + path.replace(/:(\w+)/g, (_, key) => {
        keys.push(key);
        return '([^/]+)';
      }) + '$'
    );
    routes.push({ method, pattern, keys, handler });
  }

  const router = {
    get: (path: string, handler: typeof routes[0]['handler']) => addRoute('GET', path, handler),
    post: (path: string, handler: typeof routes[0]['handler']) => addRoute('POST', path, handler),
    put: (path: string, handler: typeof routes[0]['handler']) => addRoute('PUT', path, handler),
    delete: (path: string, handler: typeof routes[0]['handler']) => addRoute('DELETE', path, handler),
    all: (path: string, handler: typeof routes[0]['handler']) => {
      addRoute('GET', path, handler);
      addRoute('POST', path, handler);
      addRoute('PUT', path, handler);
      addRoute('DELETE', path, handler);
    },

    async handle(req: VirtualRequest): Promise<VirtualResponse> {
      for (const route of routes) {
        if (route.method !== req.method && route.method !== '*') continue;

        const match = req.path.match(route.pattern);
        if (match) {
          const params: Record<string, string> = {};
          route.keys.forEach((key, i) => {
            params[key] = match[i + 1];
          });
          return route.handler({ ...req, params });
        }
      }

      return { status: 404, body: 'Not Found' };
    },

    serve(port: number, name?: string): () => void {
      return iframeServer.serve(port, (req) => router.handle(req), name || `router:${port}`);
    },
  };

  return router;
}

// Export for window global
if (typeof window !== 'undefined') {
  (window as any).__iframeServer = iframeServer;
  (window as any).__createStaticServer = createStaticServer;
  (window as any).__createRouter = createRouter;
}
